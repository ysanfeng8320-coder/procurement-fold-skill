#!/usr/bin/env bash
# WorkBuddy 一键安装：把 procurement-fold 装到 ~/.workbuddy/skills/
# 用法（粘贴到 WorkBuddy 对话框也可）：
#   curl -fsSL https://raw.githubusercontent.com/ysanfeng8320-coder/procurement-fold-skill/main/install-workbuddy.sh | bash
set -euo pipefail

DEST="${HOME}/.workbuddy/skills/procurement-fold"
REPO_URL="${REPO_URL:-https://github.com/ysanfeng8320-coder/procurement-fold-skill.git}"
ZIP_URL="${ZIP_URL:-https://codeload.github.com/ysanfeng8320-coder/procurement-fold-skill/zip/refs/heads/main}"
TMP="$(mktemp -d)"
cleanup() { rm -rf "$TMP"; }
trap cleanup EXIT

mkdir -p "${HOME}/.workbuddy/skills"

echo "==> 安装 procurement-fold → ${DEST}"

if command -v git >/dev/null 2>&1; then
  if git clone --depth 1 "$REPO_URL" "$TMP/repo" 2>/dev/null; then
    SRC="$TMP/repo/skills/procurement-fold"
  fi
fi

if [[ -z "${SRC:-}" || ! -f "${SRC:-}/SKILL.md" ]]; then
  echo "==> git clone 失败，改用 zip 下载"
  ZIP="$TMP/repo.zip"
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL "$ZIP_URL" -o "$ZIP"
  elif command -v wget >/dev/null 2>&1; then
    wget -qO "$ZIP" "$ZIP_URL"
  else
    echo "需要 git、curl 或 wget 之一" >&2
    exit 1
  fi
  unzip -q "$ZIP" -d "$TMP/unz"
  SRC="$(find "$TMP/unz" -type d -path '*/skills/procurement-fold' | head -1)"
fi

if [[ ! -f "$SRC/SKILL.md" ]]; then
  echo "未找到 skills/procurement-fold/SKILL.md" >&2
  exit 1
fi

rm -rf "$DEST"
mkdir -p "$(dirname "$DEST")"
cp -R "$SRC" "$DEST"

echo "==> 完成"
echo "    $DEST/SKILL.md"
ls -la "$DEST/SKILL.md"
echo ""
echo "在 WorkBuddy 里说：用 procurement-fold"
