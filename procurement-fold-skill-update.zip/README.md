# procurement-fold-skill

政府采购 **结构折叠** Skill：商业咨询问答 → 资料投喂 → 简易报告 →（自备 API Key 后）场景拟合 / 名单 / 电话补全。

## WorkBuddy（对话框粘贴安装）

把下面整段发给 WorkBuddy（**不依赖** `install-workbuddy.sh`，仓库现有内容即可）：

```text
帮我安装 procurement-fold 技能：用 git clone（或等价下载）拉取
https://github.com/ysanfeng8320-coder/procurement-fold-skill
把其中的 skills/procurement-fold 完整复制到 ~/.workbuddy/skills/procurement-fold
（目录已存在则先删掉再复制），最后确认 ~/.workbuddy/skills/procurement-fold/SKILL.md 存在。
```

等价终端命令：

```bash
mkdir -p ~/.workbuddy/skills
TMP=$(mktemp -d)
git clone --depth 1 https://github.com/ysanfeng8320-coder/procurement-fold-skill.git "$TMP/repo"
rm -rf ~/.workbuddy/skills/procurement-fold
cp -R "$TMP/repo/skills/procurement-fold" ~/.workbuddy/skills/procurement-fold
rm -rf "$TMP"
test -f ~/.workbuddy/skills/procurement-fold/SKILL.md && echo OK
```

可选（仓库根目录已有 `install-workbuddy.sh` 之后再用）：

```text
帮我执行：curl -fsSL https://raw.githubusercontent.com/ysanfeng8320-coder/procurement-fold-skill/main/install-workbuddy.sh | bash
```

## Codex / Cursor / Claude 等

```bash
npx -y skills add ysanfeng8320-coder/procurement-fold-skill -g --all
```

只装到 Codex：

```bash
npx -y skills add ysanfeng8320-coder/procurement-fold-skill -g -a codex
```

## 装完怎么用

对 Agent 说：

```text
用 procurement-fold
```

Skill 会先做商业咨询问答（一次一题），再引导上传产品/公司介绍，再出简易报告。  
**本包不附带知了网 / 世舶 API Key。** 无 Key 也能做问答与简易报告；完整招标拉数、场景拟合、电话补全需要自行配置：

```bash
export ZHILIAO_API_KEY=...
export SHIBO_API_KEY=...
```

完整数据流水线（`kg_engine/fold`）仍在 `procurement-intelligence` 仓库。仅安装本 Skill 时，按 `SKILL.md` 做咨询与简易报告，不要假装已跑通大样本拟合。

## 仓库结构

```text
skills/procurement-fold/   ← 被 skills CLI / WorkBuddy 安装的 Skill（必须有 SKILL.md）
install-workbuddy.sh       ← WorkBuddy 一键安装脚本
README.md
```

## 从 monorepo 同步

```bash
./scripts/sync-from-monorepo.sh
```

## 许可证

仅供你授权的对象使用；请勿附带任何第三方 API Key 一并分发。
