#!/usr/bin/env bash
# WorkBuddy / CodeBuddy 一键安装：skill + kg_engine（档位 B 可跑；Key 自备）
# 粘贴到 WorkBuddy：
#   curl -fsSL https://raw.githubusercontent.com/ysanfeng8320-coder/procurement-fold-skill/main/install-workbuddy.sh | bash
set -euo pipefail

REPO_URL="${REPO_URL:-https://github.com/ysanfeng8320-coder/procurement-fold-skill.git}"
ZIP_URL="${ZIP_URL:-https://codeload.github.com/ysanfeng8320-coder/procurement-fold-skill/zip/refs/heads/main}"
TMP="$(mktemp -d)"
cleanup() { rm -rf "$TMP"; }
trap cleanup EXIT

# Prefer CodeBuddy path (WorkBuddy 现网常用)，同时装 WorkBuddy 路径
TARGETS=()
for d in "${HOME}/.codebuddy/skills" "${HOME}/.workbuddy/skills"; do
  TARGETS+=("$d")
done

echo "==> 下载 procurement-fold-skill"
if command -v git >/dev/null 2>&1 && git clone --depth 1 "$REPO_URL" "$TMP/repo" 2>/dev/null; then
  ROOT="$TMP/repo"
else
  echo "==> git clone 失败，改用 zip"
  ZIP="$TMP/repo.zip"
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL "$ZIP_URL" -o "$ZIP"
  else
    wget -qO "$ZIP" "$ZIP_URL"
  fi
  unzip -q "$ZIP" -d "$TMP/unz"
  ROOT="$(find "$TMP/unz" -maxdepth 1 -type d -name 'procurement-fold-skill*' | head -1)"
fi

SKILL_SRC="$ROOT/skills/procurement-fold"
ENGINE_SRC="$ROOT/kg_engine"
if [[ ! -f "$SKILL_SRC/SKILL.md" ]]; then
  echo "缺少 skills/procurement-fold/SKILL.md" >&2
  exit 1
fi
if [[ ! -f "$ENGINE_SRC/fold/run_v2.py" ]]; then
  echo "缺少 kg_engine/fold（完整流水线需要引擎，请确认仓库已包含 kg_engine/）" >&2
  exit 1
fi

install_one() {
  local base="$1"
  local dest="$base/procurement-fold"
  mkdir -p "$base"
  rm -rf "$dest"
  mkdir -p "$dest"
  # skill 文件铺到 skill 根（WorkBuddy 要求 SKILL.md 在此）
  rsync -a --delete \
    --exclude '.DS_Store' --exclude '__pycache__' --exclude '*.pyc' \
    "$SKILL_SRC/" "$dest/"
  # 引擎嵌进 skill 根 → bundled 布局
  rsync -a --delete \
    --exclude '.DS_Store' --exclude '__pycache__' --exclude '*.pyc' \
    --exclude 'fold_runs' \
    "$ENGINE_SRC/" "$dest/kg_engine/"
  mkdir -p "$dest/scout_data" "$dest/fold_runs"
  echo "    installed → $dest"
  test -f "$dest/SKILL.md"
  test -f "$dest/kg_engine/fold/scene_fit.py"
}

for base in "${TARGETS[@]}"; do
  echo "==> 安装到 $base"
  install_one "$base"
done

echo ""
echo "==> 依赖检查"
python3 -c "import yaml,requests; print('  pyyaml+requests OK')" 2>/dev/null \
  || echo "  请执行: pip3 install pyyaml requests"

echo ""
echo "==> 自检（以 CodeBuddy 路径为准，若无则 WorkBuddy）"
DOC=""
for p in \
  "${HOME}/.codebuddy/skills/procurement-fold/scripts/doctor.py" \
  "${HOME}/.workbuddy/skills/procurement-fold/scripts/doctor.py"
do
  if [[ -f "$p" ]]; then DOC="$p"; break; fi
done
if [[ -n "$DOC" ]]; then
  python3 "$DOC" || true
fi

echo ""
echo "装完后在 WorkBuddy 说：用 procurement-fold"
echo "档位 B 需要自备 Key："
echo "  export ZHILIAO_API_KEY=..."
echo "  export SHIBO_API_KEY=..."
