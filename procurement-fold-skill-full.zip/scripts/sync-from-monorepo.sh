#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
# When this folder lives at monorepo/publish/procurement-fold-skill
DEFAULT_SRC="$(cd "$ROOT/../.." && pwd)/skills/procurement-fold"
SRC="${MONOREPO_SKILL:-$DEFAULT_SRC}"
DST="$ROOT/skills/procurement-fold"
if [[ ! -f "$SRC/SKILL.md" ]]; then
  echo "missing source: $SRC/SKILL.md" >&2
  exit 1
fi
mkdir -p "$DST"
rsync -a --delete \
  --exclude '.DS_Store' \
  --exclude '__pycache__' \
  --exclude '*.pyc' \
  "$SRC/" "$DST/"
echo "synced -> $DST"
