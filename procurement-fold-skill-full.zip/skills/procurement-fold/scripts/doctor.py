#!/usr/bin/env python3
"""procurement-fold 环境自检 — 支持 monorepo 与 skill 内嵌引擎两种布局。"""
from __future__ import annotations

import os
import sys

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def ok(msg: str) -> None:
    print(f"  ✓ {msg}")


def bad(msg: str) -> None:
    print(f"  ✗ {msg}")


def detect_repo() -> tuple[str, str]:
    """Return (repo_or_skill_root, mode)."""
    # Bundled: skill dir contains kg_engine/ + product_packs/
    if os.path.isdir(os.path.join(SKILL_DIR, "kg_engine", "fold")) and os.path.isdir(
        os.path.join(SKILL_DIR, "product_packs")
    ):
        return SKILL_DIR, "bundled"
    # Monorepo: ../../ from skills/procurement-fold
    mono = os.path.normpath(os.path.join(SKILL_DIR, "..", ".."))
    if os.path.isdir(os.path.join(mono, "kg_engine", "fold")):
        return mono, "monorepo"
    return SKILL_DIR, "missing"


def main() -> int:
    repo, mode = detect_repo()
    print(f"MODE = {mode}")
    print(f"ROOT = {repo}")
    print(f"SKILL = {SKILL_DIR}")
    errors = 0

    def need(path: str, label: str) -> None:
        nonlocal errors
        p = path if os.path.isabs(path) else os.path.join(repo, path)
        if os.path.exists(p):
            ok(label)
        else:
            bad(f"缺少 {label}: {p}")
            errors += 1

    need("kg_engine", "kg_engine/")
    need("kg_engine/fold/run_v2.py", "fold.run_v2")
    need("kg_engine/fold/scene_fit.py", "fold.scene_fit")
    need("kg_engine/fold/phone_complete.py", "fold.phone_complete")
    need("kg_engine/fold/acquisition_gate.py", "fold.acquisition_gate")
    need("kg_engine/phone_enricher.py", "phone_enricher")
    need("kg_engine/collector.py", "collector")

    if mode == "bundled":
        need("SKILL.md", "SKILL.md")
        need("config/acquisition_gate.yaml", "acquisition_gate.yaml")
        need("product_packs/seal_control/lexicon.yaml", "product seal_control")
        need("species_packs/court/species.yaml", "species court")
    else:
        need("skills/procurement-fold/SKILL.md", "SKILL.md")
        need("skills/procurement-fold/config/acquisition_gate.yaml", "acquisition_gate.yaml")
        need("skills/procurement-fold/product_packs/seal_control/lexicon.yaml", "product seal_control")
        need("skills/procurement-fold/species_packs/court/species.yaml", "species court")

    scout = os.path.join(repo, "scout_data")
    os.makedirs(scout, exist_ok=True)
    n = len([x for x in os.listdir(scout) if x.endswith(".json")])
    ok(f"scout_data/ ({n} json，可空)")

    try:
        import yaml  # noqa: F401
        ok("PyYAML")
    except ImportError:
        bad("未安装 PyYAML（pip install pyyaml）")
        errors += 1

    try:
        import requests  # noqa: F401
        ok("requests")
    except ImportError:
        bad("未安装 requests（pip install requests）")
        errors += 1

    sys.path.insert(0, os.path.join(repo, "kg_engine"))
    try:
        from fold.pack_loader import load_pack
        from fold.species_loader import load_species
        from fold.paths import layout

        lay = layout()
        print(f"  · paths.mode = {lay['mode']}")
        load_pack("seal_control")
        load_species("court")
        ok("load_pack(seal_control) + load_species(court)")
    except Exception as e:
        bad(f"引擎加载失败: {e}")
        errors += 1

    fold_runs = os.path.join(repo, "fold_runs")
    os.makedirs(fold_runs, exist_ok=True)
    ok("fold_runs/ 可写")

    has_zl = bool(os.environ.get("ZHILIAO_API_KEY") or os.environ.get("ZLBX_API_KEY"))
    has_sb = bool(os.environ.get("SHIBO_API_KEY") or os.environ.get("GOVBID_API_KEY"))
    if has_zl or has_sb:
        ok(f"API Key 已配置（知了={'是' if has_zl else '否'} / 世舶={'是' if has_sb else '否'}）")
    else:
        bad("未设置 ZHILIAO_API_KEY / SHIBO_API_KEY（档位 B 拉数需要自备 Key）")
        # not counted as hard error for doctor exit — skill can still do Q&A

    print()
    if errors:
        print(f"FAILED ({errors} issues). 修复后再跑完整流水线。")
        return 1
    print("OK — 环境可用。无 Key 时可问答+简易报告；有 Key 可采数/拟合/名单/电话。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
