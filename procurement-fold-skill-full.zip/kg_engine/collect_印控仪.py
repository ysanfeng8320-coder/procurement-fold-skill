"""
印控仪全量数据采集脚本
采集陕西+甘肃所有相关关键词的全量招投标数据
"""
import json, os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from collector import UnifiedCollector

KW_LIST = ['印控仪', '智能印章', '盖章机', '印控台', '电子印章']
PROVINCES = {'陕西': '610000', '甘肃': '620000'}
PAGE_SIZE = 50

c = UnifiedCollector()
total_files = []

for kw in KW_LIST:
    for region, code in PROVINCES.items():
        # 探测总数
        test_result = c.collect_one_page(kw, code, page=1, page_size=1)
        total = test_result.get('total', 0)
        if total == 0:
            print(f"[SKIP] {kw}_{region}: 0条")
            continue
        
        pages = max(1, math.ceil(total / PAGE_SIZE))
        print(f"[COLLECT] {kw}_{region}: {total}条, {pages}页")
        
        for p in range(1, pages + 1):
            result = c.collect_one_page(kw, code, page=p, page_size=PAGE_SIZE)
            fpath = c.save(result, kw, region, page=p)
            total_files.append(fpath)
            records = len(result.get('records', []))
            print(f"  page {p}/{pages}: {records}条 → {fpath}")

print(f"\n=== 采集完成 ===")
print(f"共 {len(total_files)} 个文件")
for f in total_files:
    print(f"  {f}")
