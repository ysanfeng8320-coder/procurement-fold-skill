"""
知识图谱 Ontology 定义
实体类型、关系类型、属性结构
"""
from dataclasses import dataclass, field, asdict
from typing import Optional
from enum import Enum

# ========== 实体类型 ==========

class EntityType(str, Enum):
    COMPANY = "company"           # 公司/单位（采购方、供应商）
    PROJECT = "project"           # 项目（招标项目）
    PRODUCT = "product"           # 产品/品类
    PERSON = "person"             # 联系人
    REGION = "region"             # 地区
    INDUSTRY = "industry"         # 行业/系统（法院、公安、纪委...）
    BID_RECORD = "bid_record"     # 中标记录（事件节点）

# ========== 关系类型 ==========

class RelationType(str, Enum):
    # 显式关系（直接从数据中提取）
    ISSUES = "issues"             # 采购方 → 发布 → 项目
    WON_BY = "won_by"             # 项目 → 中标 → 供应商
    BELONGS_TO = "belongs_to"     # 单位 → 属于 → 行业系统
    LOCATED_IN = "located_in"     # 单位 → 位于 → 地区
    REQUIRES = "requires"         # 项目 → 需要 → 产品品类
    CONTACT_OF = "contact_of"     # 联系人 → 属于 → 单位

    # 隐式关系(通过推理/统计发现)
    COOPERATES_WITH = "cooperates_with"   # 单位A → 与 → 单位B（多次合作）
    COMPETES_WITH = "competes_with"       # 单位A → 与 → 单位B竞争同一客户群
    SIMILAR_TO = "similar_to"             # 单位A → 相似于 → 单位B（同类型客户）
    ASSOCIATED_PRODUCT = "associated_product"  # 产品A → 关联 → 产品B（同一单位常同时采购）
    POTENTIAL_NEED = "potential_need"     # 单位 → 可能需要 → 产品（推理结果）
    CAN_SUPPLY = "can_supply"            # 供应商 → 可以供应 → 产品（推理结果）


# ========== 数据结构 ==========

@dataclass
class Entity:
    """实体"""
    id: str
    type: EntityType
    name: str
    properties: dict = field(default_factory=dict)

@dataclass
class Relation:
    """关系"""
    source_id: str
    target_id: str
    type: RelationType
    properties: dict = field(default_factory=dict)

@dataclass
class Graph:
    """整个图谱"""
    entities: dict  # id → Entity
    relations: list  # list of Relation


# ========== 实体ID生成规则 ==========

def entity_id(etype: EntityType, name: str) -> str:
    """生成实体唯一ID"""
    import hashlib
    raw = f"{etype.value}:{name.strip().lower()}"
    return hashlib.md5(raw.encode()).hexdigest()[:16]

def company_id(name: str) -> str:
    return entity_id(EntityType.COMPANY, name)

def project_id(pid: int) -> str:
    return f"proj_{pid}"

def product_id(name: str) -> str:
    return entity_id(EntityType.PRODUCT, name)

def region_id(code: str) -> str:
    return f"region_{code}"

def industry_id(name: str) -> str:
    return entity_id(EntityType.INDUSTRY, name)

def person_key(name: str, phone: str) -> str:
    """联系人去重key"""
    return entity_id(EntityType.PERSON, f"{name}:{phone}")
