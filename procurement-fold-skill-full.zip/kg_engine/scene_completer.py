"""
场景完备性覆盖引擎（v0.2）

从场景推理生成预期实体清单，与图谱已有数据交叉匹配，
输出三份清单：已购 / 在数据中未购 / 数据盲区。

v0.2 改进：
  - 行政区划数据从 data/admin_regions.json 加载（不再硬编码）
  - SCENE_RULES 使用模板化命名规则（支持任意省份）
  - 支持陕西(610000)和甘肃(620000)
"""
import json, os, re, logging
from collections import defaultdict
from typing import Optional
from pathlib import Path

from graph_store import GraphStore
from schema import EntityType, RelationType, company_id

LOG = logging.getLogger(__name__)
KG_DIR = os.path.dirname(os.path.abspath(__file__))
REGIONS_FILE = os.path.join(KG_DIR, "data", "admin_regions.json")


# ========== 行政区划加载 ==========

def load_admin_regions() -> dict:
    """加载行政区划数据"""
    if os.path.exists(REGIONS_FILE):
        with open(REGIONS_FILE) as f:
            return json.load(f)
    LOG.warning(f"行政区划文件不存在: {REGIONS_FILE}")
    return {}


# ========== 场景命名规则（模板化） ==========

def _generate_entity_names(pattern: str, **kwargs) -> str:
    """模板替换：把 {province}、{city}、{district} 等占位符替换为实际值"""
    result = pattern
    for k, v in kwargs.items():
        result = result.replace("{" + k + "}", v)
    return result


SCENE_RULES = {
    "法院系统": {
        "depth": "full",
        "certainty": 1.0,
        "city_patterns": [
            "{province}{city_short}市中级人民法院",
            "{province}{city}中级人民法院",
            "{city}市中级人民法院",
            "{city}中级人民法院",
        ],
        "district_patterns": [
            "{district}人民法院",
            "{city}{district}人民法院",
            "{city_short}{district}人民法院",
        ],
    },
    "检察院系统": {
        "depth": "full",
        "certainty": 0.9,
        "city_patterns": [
            "{province}{city_short}市人民检察院",
            "{province}{city}人民检察院",
            "{city}市人民检察院",
            "{city}人民检察院",
        ],
        "district_patterns": [
            "{district}人民检察院",
        ],
    },
    "公安系统": {
        "depth": "partial",
        "certainty": 0.8,
        "city_patterns": [],
        "district_patterns": [
            "{district}公安局",
            "{city}市公安局{district_short}分局",
        ],
    },
}


def _city_short(name: str) -> str:
    """获取城市的简称（去掉"市/州/自治州"后缀）"""
    for suffix in ["回族自治州","藏族自治州","自治州","市","地区","盟"]:
        if name.endswith(suffix):
            return name[:-len(suffix)]
    return name


def _district_short(name: str) -> str:
    """区县的简称（去掉常见后缀）"""
    for suffix in ["区","县","市"]:
        if name.endswith(suffix):
            return name[:-len(suffix)]
    return name


# ========== 场景完备性分析器 ==========

class SceneCompleter:
    """
    场景完备性覆盖引擎。
    
    逻辑：
      1. 根据场景类型+省份代码，从行政区划数据生成预期实体清单
      2. 与图谱已有采购数据交叉匹配
      3. 输出三份清单：
         - 已购目标品类（purchased_already）
         - 在数据中但未购（not_purchased）
         - 数据盲区——从未出现在采购数据中（blind_spot）
    """
    
    def __init__(self, store: GraphStore = None):
        self.store = store or GraphStore()
        self.regions = load_admin_regions()
        self._load_contacts()
        self._load_known_buyers()
    
    def _load_contacts(self):
        cf = os.path.join(KG_DIR, "data", "contacts.json")
        self._contacts = {}
        if os.path.exists(cf):
            with open(cf) as f:
                self._contacts = json.load(f)
    
    def _load_known_buyers(self):
        """加载图谱中所有已知采购方名称"""
        self._known_buyer_names = set()
        for e in self.store.graph.entities.values():
            if e.type == EntityType.COMPANY and e.properties.get("type") == "buyer":
                self._known_buyer_names.add(e.name)
    
    def _phone(self, name: str) -> str:
        return self._contacts.get(name, "待确认")
    
    def _fuzzy_match(self, entity_name: str) -> Optional[str]:
        """在已建库单位中模糊匹配"""
        if entity_name in self._known_buyer_names:
            return entity_name
        # 前6字匹配
        prefix = entity_name[:6]
        for known in self._known_buyer_names:
            if known.startswith(prefix):
                return known
        return None
    
    def supported_provinces(self) -> list:
        """当前行政区划数据支持哪些省份"""
        return [
            {"code": code, "name": info["name"]}
            for code, info in self.regions.items()
        ]
    
    def generate_expected_entities(self, scene: str, province_code: str) -> list:
        """
        根据场景类型和省份代码，用行政推理生成预期单位名单。
        
        返回: [(单位名, 类型, 确定性), ...]
        """
        if province_code not in self.regions:
            raise ValueError(
                f"省份代码 {province_code} 不在行政区划数据中。"
                f"当前支持: {self.supported_provinces()}"
            )
        
        if scene not in SCENE_RULES:
            raise ValueError(f"场景 '{scene}' 不在支持的场景列表中: {list(SCENE_RULES.keys())}")
        
        prov_info = self.regions[province_code]
        prov_name = prov_info["name"]
        rule = SCENE_RULES[scene]
        
        entities = []
        
        for city_info in prov_info["cities"]:
            city_name = city_info["name"]
            city_short = _city_short(city_name)
            districts = city_info.get("districts", [])
            
            # 市级单位
            for pattern in rule.get("city_patterns", []):
                name = _generate_entity_names(
                    pattern,
                    province=prov_name,
                    city=city_name,
                    city_short=city_short,
                )
                entities.append((name, f"市级{scene}", rule["certainty"]))
            
            # 区县级单位
            for district in districts:
                d_short = _district_short(district)
                for pattern in rule.get("district_patterns", []):
                    name = _generate_entity_names(
                        pattern,
                        province=prov_name,
                        city=city_name,
                        city_short=city_short,
                        district=district,
                        district_short=d_short,
                    )
                    entities.append((name, f"区县级{scene}", rule["certainty"]))
        
        return entities
    
    def analyze(self, scene: str, province_code: str,
                target_product: str = None) -> dict:
        """
        执行场景完备性分析。
        
        返回:
          {
            "scene": str,
            "province": str,
            "total_expected": n,
            "purchased_already": [(name, phone, matched_name), ...],
            "not_purchased": [(name, phone, matched_name), ...],
            "blind_spot": [(name, phone, None), ...],
            "data_available": bool,  # 行政区划数据是否可用
          }
        """
        # 检查行政区划数据是否可用
        if province_code not in self.regions:
            return {
                "scene": scene,
                "province": province_code,
                "total_expected": 0,
                "purchased_already": [],
                "not_purchased": [],
                "blind_spot": [],
                "error": f"行政区划数据未覆盖省份代码 {province_code}。当前支持: {self.supported_provinces()}",
                "data_available": False,
            }
        
        if scene not in SCENE_RULES:
            return {
                "scene": scene,
                "province": province_code,
                "total_expected": 0,
                "purchased_already": [],
                "not_purchased": [],
                "blind_spot": [],
                "error": f"场景 '{scene}' 不支持。当前支持: {list(SCENE_RULES.keys())}",
                "data_available": True,
            }
        
        # 生成预期单位名单
        expected = self.generate_expected_entities(scene, province_code)
        
        purchased = []
        not_purchased = []
        blind = []
        
        for entity_name, entity_type, certainty in expected:
            matched = self._fuzzy_match(entity_name)
            phone = self._phone(entity_name) if matched else "待确认"
            phone = phone if phone != "待确认" else self._phone(matched or "")
            
            if matched is None:
                # 数据盲区
                blind.append((entity_name, phone, None))
            else:
                # 在数据中 → 检查是否买了目标品类（支持同义词族）
                bought = False
                if target_product:
                    from scope import resolve_family
                    _, family = resolve_family(target_product)
                    family_set = set(family) | {target_product}
                    cid = company_id(matched)
                    for r, proj in self.store.get_neighbors(cid, RelationType.ISSUES):
                        for r2, prod in self.store.get_neighbors(proj.id, RelationType.REQUIRES):
                            if prod.type == EntityType.PRODUCT and prod.name in family_set:
                                bought = True
                                break
                        if bought:
                            break
                
                if bought:
                    purchased.append((entity_name, phone, matched))
                else:
                    not_purchased.append((entity_name, phone, matched))
        
        return {
            "scene": scene,
            "province": province_code,
            "province_name": self.regions[province_code]["name"],
            "total_expected": len(expected),
            "purchased_already": purchased,
            "not_purchased": not_purchased,
            "blind_spot": blind,
            "data_available": True,
        }
    
    def format_report(self, result: dict) -> str:
        """将分析结果格式化为可读文本"""
        if result.get("error"):
            return f"⚠️ {result['error']}"
        
        lines = [
            f"场景完备性覆盖 — {result['scene']} / {result.get('province_name', result.get('province', ''))}",
            f"预期单位总数: {result['total_expected']}",
            f"",
            f"✅ 已购目标品类: {len(result['purchased_already'])}家",
        ]
        for name, phone, matched in result["purchased_already"][:10]:
            p = f" ☎ {phone}" if phone and phone != "待确认" else ""
            lines.append(f"  {name}{p}")
        if len(result["purchased_already"]) > 10:
            lines.append(f"  ...共{len(result['purchased_already'])}家")
        
        lines.append(f"\n🔔 在数据中但未购: {len(result['not_purchased'])}家")
        for name, phone, matched in result["not_purchased"][:15]:
            p = f" ☎ {phone}" if phone and phone != "待确认" else ""
            lines.append(f"  {name}{p}")
        if len(result["not_purchased"]) > 15:
            lines.append(f"  ...共{len(result['not_purchased'])}家")
        
        lines.append(f"\n❌ 数据盲区（从未出现在采购数据）: {len(result['blind_spot'])}家")
        for name, phone, _ in result["blind_spot"][:10]:
            lines.append(f"  {name}")
        if len(result["blind_spot"]) > 10:
            lines.append(f"  ...共{len(result['blind_spot'])}家")
        
        return "\n".join(lines)


# ========== 测试 ==========

if __name__ == "__main__":
    from graph_store import GraphStore
    
    store = GraphStore()
    sc = SceneCompleter(store)
    
    print("=== 支持省份 ===")
    for p in sc.supported_provinces():
        print(f"  {p['code']} = {p['name']}")
    
    print("\n=== 甘肃法院场景 ===")
    r = sc.analyze("法院系统", "620000", target_product="装订机")
    print(sc.format_report(r))
    
    print("\n=== 陕西法院场景 ===")
    r = sc.analyze("法院系统", "610000", target_product="装订机")
    print(sc.format_report(r))
    
    print("\n=== 不支持省份的降级测试 ===")
    r = sc.analyze("法院系统", "110000", target_product="装订机")
    print(sc.format_report(r))
