"""
验证模块
用独立验证集评估推理引擎的准确率。

核心逻辑：
  阶段二用A档数据（200-300条）训练出买家画像
  阶段三用B档数据（50-100条，不重叠）验证：
    1. 画像命中率：验证集中有多少单位被预测清单覆盖
    2. 画像稳定性：验证集行业分布 vs 训练集行业分布的偏差
    3. 新发现率：验证集中有多少单位是训练集没见过的品类/行业
"""
import json, os, random
from collections import Counter, defaultdict
from graph_store import GraphStore
from schema import EntityType, RelationType
from feature_matcher import FeatureMatcher
from matrix_ops import MatrixOps

KG_DIR = os.path.dirname(os.path.abspath(__file__))


class Validator:
    """训练-验证评估器"""
    
    def __init__(self, store: GraphStore = None):
        self.store = store or GraphStore()
        self.matcher = FeatureMatcher(self.store)
        self.matrix = MatrixOps(self.store)
    
    def evaluate(self, target_product: str, 
                 train_ids: set, valid_ids: set) -> dict:
        """
        评估特征拟合的准确率
        
        参数：
          target_product: 目标品类
          train_ids: 训练集项目ID集合
          valid_ids: 验证集项目ID集合（与训练集不重叠）
        
        返回：
          {
            "命中率": X,           # 验证集中被预测清单覆盖的比例
            "准确率": X,           # 预测清单中被验证集命中的比例
            "画像偏差": X,         # 行业分布变化
            "新品类发现率": X,     # 验证集带来的新品类占比
            "可信度": "高/中/低",
            "细节": {...}
          }
        """
        # 确保两个ID集不重叠
        overlap = train_ids & valid_ids
        assert not overlap, f"训练集和验证集有{len(overlap)}个重叠项目"
        
        # ========== 步骤1：用训练集构建画像 ==========
        profile = self.matcher.build_profile(target_product)
        
        # ========== 步骤2：用训练集做预测 ==========
        prospects = self.matcher.rank_prospects(
            target_product, top_n=50, min_score=30
        )
        predicted_buyers = set()
        for p in prospects.get("prospects", []):
            name = p.get("name", "")
            # 用company_id规范化
            from schema import company_id
            predicted_buyers.add(company_id(name))
        
        if not predicted_buyers:
            return {
                "命中率": 0,
                "准确率": 0,
                "画像偏差": 1.0,
                "新品类发现率": 0,
                "可信度": "无数据",
                "细节": {"错误": "训练集预测结果为空"},
            }
        
        # ========== 步骤3：在验证集中检查命中 ==========
        # 找验证集项目对应的采购方
        valid_buyers = set()
        valid_industries = Counter()
        valid_products = set()
        
        for vid in valid_ids:
            proj_eid = f"proj_{vid}"
            proj = self.store.graph.entities.get(proj_eid)
            if not proj or proj.type != EntityType.PROJECT:
                continue
            
            # 找采购方
            for r in self.store.graph.relations:
                if r.type == RelationType.ISSUES and r.target_id == proj_eid:
                    bid = r.source_id
                    valid_buyers.add(bid)
                    buyer = self.store.graph.entities.get(bid)
                    if buyer:
                        inds = buyer.properties.get("industries", [])
                        for i in inds:
                            valid_industries[i] += 1
                
                if r.type == RelationType.REQUIRES and r.source_id == proj_eid:
                    prod = self.store.graph.entities.get(r.target_id)
                    if prod and prod.type == EntityType.PRODUCT:
                        valid_products.add(prod.name)
        
        # 命中率：验证集中有多少采购方被预测清单覆盖
        hit_count = len(predicted_buyers & valid_buyers)
        hit_rate = hit_count / max(len(valid_buyers), 1)
        
        # 准确率：预测清单中有多少被验证集命中
        precision = hit_count / max(len(predicted_buyers), 1)
        
        # ========== 步骤4：画像偏差 ==========
        # 训练集的行业分布
        train_industries = Counter()
        train_buyer_ids = set()
        for tid in train_ids:
            proj_eid = f"proj_{tid}"
            for r in self.store.graph.relations:
                if r.type == RelationType.ISSUES and r.target_id == proj_eid:
                    train_buyer_ids.add(r.source_id)
                    buyer = self.store.graph.entities.get(r.source_id)
                    if buyer:
                        inds = buyer.properties.get("industries", [])
                        for i in inds:
                            train_industries[i] += 1
        
        # 计算行业分布的Jensen-Shannon散度（简化版：看top3行业是否一致）
        train_top3 = set(ind for ind, _ in train_industries.most_common(3))
        valid_top3 = set(ind for ind, _ in valid_industries.most_common(3))
        industry_divergence = 1 - len(train_top3 & valid_top3) / max(len(train_top3 | valid_top3), 1)
        
        # ========== 步骤5：新品类发现率 ==========
        train_products = set()
        for tid in train_ids:
            proj_eid = f"proj_{tid}"
            for r in self.store.graph.relations:
                if r.type == RelationType.REQUIRES and r.source_id == proj_eid:
                    prod = self.store.graph.entities.get(r.target_id)
                    if prod and prod.type == EntityType.PRODUCT:
                        train_products.add(prod.name)
        
        new_products = valid_products - train_products
        new_product_rate = len(new_products) / max(len(valid_products), 1) if valid_products else 0
        
        # ========== 步骤6：可信度判断 ==========
        if precision >= 0.3 and industry_divergence < 0.5:
            confidence = "高"
        elif precision >= 0.15 and industry_divergence < 0.7:
            confidence = "中"
        elif precision >= 0.1:
            confidence = "低"
        else:
            confidence = "不可用"
        
        return {
            "目标品类": target_product,
            "训练集项目数": len(train_ids),
            "验证集项目数": len(valid_ids),
            "训练集采购方数": len(train_buyer_ids),
            "验证集采购方数": len(valid_buyers),
            "预测清单数": len(predicted_buyers),
            "命中数": hit_count,
            "命中率": round(hit_rate, 3),
            "准确率": round(precision, 3),
            "画像偏差": round(industry_divergence, 3),
            "新品类发现率": round(new_product_rate, 3),
            "可信度": confidence,
        }


def split_train_valid(all_ids: set, valid_ratio: float = 0.2, 
                       seed: int = 42) -> tuple:
    """
    将项目ID集合随机分割为训练集和验证集
    valid_ratio: 验证集占比（默认20%）
    """
    ids_list = list(all_ids)
    random.seed(seed)
    random.shuffle(ids_list)
    
    n_valid = max(1, int(len(ids_list) * valid_ratio))
    valid_ids = set(ids_list[:n_valid])
    train_ids = set(ids_list[n_valid:])
    
    return train_ids, valid_ids


if __name__ == "__main__":
    from builder import load_records_from_file, collect_scout_files
    import glob
    
    print("=== 验证模块测试 ===")
    
    # 从信号屏蔽器数据构建训练集/验证集
    all_ids = set()
    for fpath, cat in collect_scout_files():
        records = load_records_from_file(fpath)
        for r in records:
            if isinstance(r, dict) and r.get("id"):
                all_ids.add(r["id"])
    
    print(f"总项目数: {len(all_ids)}")
    
    train_ids, valid_ids = split_train_valid(all_ids, valid_ratio=0.2)
    print(f"训练集: {len(train_ids)}, 验证集: {len(valid_ids)}")
    
    store = GraphStore()
    v = Validator(store)
    result = v.evaluate("信号屏蔽器", train_ids, valid_ids)
    
    print("\n评估结果:")
    for k, v in result.items():
        print(f"  {k}: {v}")
