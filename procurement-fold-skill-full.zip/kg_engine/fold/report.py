"""Write fold_runs artifacts and markdown reports.

Outputs:
  - report.md       销售/老板主报告（默认打开这个）
  - report_tech.md  工程师明细（hit_tier / IF-THEN / 原始字段）
"""
from __future__ import annotations

import json
import os
from collections import Counter, defaultdict
from datetime import datetime
from typing import Any, Dict, List


def _write_json(path: str, obj: Any):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def write_run(
    run_dir: str,
    structured: List[dict],
    rule_cards: List[dict],
    leads: List[dict],
    meta: Dict,
    pack_id: str,
) -> str:
    os.makedirs(run_dir, exist_ok=True)

    jsonl = os.path.join(run_dir, "structured_records.jsonl")
    with open(jsonl, "w", encoding="utf-8") as f:
        for rec in structured:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    _write_json(os.path.join(run_dir, "rule_cards.json"), rule_cards)
    _write_json(os.path.join(run_dir, "leads.json"), leads)

    run_meta = {
        "run_id": os.path.basename(run_dir),
        "pack_id": pack_id,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        **meta,
        "counts": {
            "structured": len(structured),
            "rule_cards": len(rule_cards),
            "leads": len(leads),
            "leads_a": sum(
                1 for x in leads
                if x.get("lead_type") == "similar_unbought"
                or "结构相似" in (x.get("gap_detail") or "")
            ),
            "leads_b": sum(1 for x in leads if x.get("lead_type") == "assoc_gap"),
            "actionable": sum(1 for x in leads if x.get("actionable")),
        },
    }
    _write_json(os.path.join(run_dir, "run_meta.json"), run_meta)

    sales = render_sales_report(run_meta, rule_cards, leads, structured)
    tech = render_tech_report(run_meta, rule_cards, leads, structured)

    sales_path = os.path.join(run_dir, "report.md")
    tech_path = os.path.join(run_dir, "report_tech.md")
    with open(sales_path, "w", encoding="utf-8") as f:
        f.write(sales)
    with open(tech_path, "w", encoding="utf-8") as f:
        f.write(tech)
    # 兼容旧习惯
    with open(os.path.join(run_dir, "report_销售版.md"), "w", encoding="utf-8") as f:
        f.write(sales)
    return sales_path


def _group_leads(leads: List[dict]) -> Dict[str, List[dict]]:
    groups = defaultdict(list)
    for x in leads:
        name = x.get("buyer") or ""
        sys = x.get("buyer_system") or "其他"
        if any(k in name for k in ("电信", "移动", "联通", "中移")):
            groups["运营商/集成商"].append(x)
        elif sys in ("法院系统", "检察院系统") or "政法" in name:
            groups["政法系统"].append(x)
        elif sys == "教育系统" or any(k in name for k in ("大学", "医院", "教育")):
            groups["教育/医疗"].append(x)
        elif any(k in name for k in ("银行", "保险")):
            groups["金融"].append(x)
        elif sys == "信访系统" or "信访" in name:
            groups["信访/社工切口"].append(x)
        elif sys in (
            "政务服务系统", "机关/党委", "纪检监察系统",
            "组织/社工系统", "基层治理/村居",
        ):
            groups["政府/党委/政务"].append(x)
        else:
            groups["企业及其他"].append(x)
    return groups


def render_sales_report(meta: dict, rule_cards: list, leads: list, structured: list) -> str:
    ingest = meta.get("ingest") or {}
    counts = meta.get("counts") or {}
    pack = meta.get("pack_id") or ""
    discovery = meta.get("discovery_regions") or []
    action = meta.get("action_regions") or []

    strong = [r for r in structured if r.get("hit_tier") in ("target", "near")]
    related = [r for r in structured if r.get("hit_tier") == "related"]
    systems = Counter(r.get("buyer_system") for r in strong)
    lead_region = Counter(x.get("region") for x in leads)
    lead_sys = Counter(x.get("buyer_system") for x in leads)
    groups = _group_leads(leads)

    # pick business-facing rule highlights
    surges = [c for c in rule_cards if c.get("type") == "temporal_surge"][:4]
    coocs = [c for c in rule_cards if c.get("type") == "cooccurrence"][:4]

    lines: List[str] = []
    lines.append(f"# 市场机会报告（销售版）— {pack}")
    lines.append("")
    lines.append("**给谁看**：销售负责人 / 老板  ")
    lines.append(f"**落地省份**：{'、'.join(action) or '未指定'}  ")
    lines.append(f"**规律学习省份**：{'、'.join(discovery) or '未指定'}  ")
    lines.append(f"**生成时间**：{meta.get('created_at')}  ")
    lines.append(f"**运行编号**：`{meta.get('run_id')}`  ")
    lines.append(
        f"**数据来源**：本地 {ingest.get('local_count')} 条 + API {ingest.get('api_used')}/{ingest.get('api_budget')} 条；"
        f"近 {meta.get('max_age_years', 3)} 年有效 {counts.get('structured')} 条"
        f"（过滤前 {meta.get('structured_before_date_filter', counts.get('structured'))} 条）。数字均来自本次运行，未编造。"
    )
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 一句话结论")
    lines.append("")
    actionable = counts.get("actionable") or 0
    gap_n = counts.get("leads_b") or 0
    if gap_n:
        phone_note = (
            f"但可用电话仅 {actionable} 家，本周应优先走集成商/运营商转介绍。"
            if actionable == 0
            else f"其中 {actionable} 家可直接电话跟进。"
        )
        lines.append(
            f"已筛出 **{len(leads)}** 家落地区机会，核心是「已有电子印章/用印、未见印控硬件」的关联缺口"
            f"（约 {gap_n} 家）。{phone_note}"
        )
    else:
        lines.append(f"本次输出名单 {len(leads)} 家；关联缺口信号不足，建议补采集或调整产品包词典后再跑。")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 1. 数据汇总")
    lines.append("")
    lines.append("| 项目 | 数量 |")
    lines.append("|------|------|")
    lines.append(f"| 分析公告总数 | {counts.get('structured')} |")
    lines.append(f"| 明确像印控硬件（强相关） | {len(strong)} |")
    lines.append(f"| 电子印章等关联品 | {len(related)} |")
    lines.append(f"| 归纳出的市场规律 | {counts.get('rule_cards')} |")
    lines.append(f"| 落地区可跟进名单 | {len(leads)} |")
    lines.append(f"| 名单中有可用电话 | {actionable} |")
    lines.append("")
    lines.append("### 谁在买印控硬件？（强相关公告的买方类型）")
    lines.append("")
    lines.append("| 买方类型 | 公告数 |")
    lines.append("|----------|--------|")
    for k, v in systems.most_common(12):
        lines.append(f"| {k} | {v} |")
    lines.append("")
    lines.append("### 名单落在哪些省 / 哪些类型？")
    lines.append("")
    lines.append("| 省份 | 名单家数 |")
    lines.append("|------|----------|")
    for k, v in lead_region.most_common():
        lines.append(f"| {k} | {v} |")
    lines.append("")
    lines.append("| 名单单位类型 | 家数 |")
    lines.append("|--------------|------|")
    for k, v in lead_sys.most_common():
        lines.append(f"| {k} | {v} |")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 2. 关键发现")
    lines.append("")
    if surges:
        lines.append("### 发现 A：短期标讯是否抬头")
        lines.append("")
        for c in surges[:3]:
            sup = c.get("support") or {}
            lines.append(
                f"- {c.get('then')}（样本 n={sup.get('n')}，基线={sup.get('baseline')}）"
            )
        lines.append("")
        lines.append("**销售含义**：热度抬头时，缺口名单要提速；若落地区同步抬头，优先级上调。")
        lines.append("")
    if coocs:
        lines.append("### 发现 B：谁更常买、哪里有缺口")
        lines.append("")
        for c in coocs:
            lines.append(f"- {c.get('then')}")
        lines.append("")
        lines.append("**销售含义**：优先打「已有关联软件/电子印章、还没上硬件印控」的单位；按高占比系统分配精力。")
        lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 3. 本周行动建议")
    lines.append("")
    lines.append("1. **先打关联缺口，不先扫陌生门。**")
    lines.append("2. **没电话就走渠道**：集成商、电信/移动/联通项目经理、现有政企关系转介绍。")
    lines.append("3. **话术主线**：电子印章/用印软件已经有了，物理章还在裸奔 → 用印宝/印控台/盖章机补合规闭环。")
    lines.append("4. **按类型排期**：政务服务 → 信访/政法新切口 → 运营商（客户兼渠道）→ 金融 → 教育医疗。")
    lines.append("5. **先别做**：没有联系人就派无效外呼；把小样本涌现当成已经放量。")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 4. 高潜力客户名单（按类型）")
    lines.append("")
    order = [
        "政府/党委/政务", "信访/社工切口", "政法系统",
        "运营商/集成商", "金融", "教育/医疗", "企业及其他",
    ]
    for gname in order:
        items = groups.get(gname) or []
        if not items:
            continue
        lines.append(f"### {gname}（{len(items)}）")
        lines.append("")
        lines.append("| 单位 | 省 | 建议动作 | 证据（最近） |")
        lines.append("|------|----|----------|--------------|")
        for x in items:
            ev = (x.get("evidence") or [{}])[0]
            title = (ev.get("title") or "")[:40]
            date = (ev.get("date") or "")[:10]
            kw = ev.get("matched_keyword") or ""
            action = "走集成商/补电话" if not x.get("actionable") else f"直联 {x.get('contact')}"
            ev_cell = f"{title}（{date}）" + (f" · 命中「{kw}」" if kw else "")
            lines.append(
                f"| {x.get('buyer')} | {x.get('region')} | {action} | {ev_cell} |"
            )
        lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 5. 说明")
    lines.append("")
    lines.append("- 本报告面向销售/老板；工程师字段见同目录 `report_tech.md`。")
    lines.append("- 由统计/图规则折叠生成，未使用神经网络模型。")
    lines.append("- 严禁把本报告中的机会名单理解成“已确认预算”或“必然成交”。")
    lines.append("")
    return "\n".join(lines)


def render_tech_report(meta: dict, rule_cards: list, leads: list, structured: list) -> str:
    """Engineer-facing detail (former default)."""
    lines = []
    lines.append(f"# Procurement Fold 技术明细 — `{meta.get('pack_id')}`")
    lines.append("")
    lines.append(f"- run_id: `{meta.get('run_id')}`")
    lines.append(f"- 时间: {meta.get('created_at')}")
    ingest = meta.get("ingest") or {}
    lines.append(f"- 结构化记录: {meta.get('counts', {}).get('structured')}")
    lines.append(f"- 本地条数: {ingest.get('local_count')} / API 消耗: {ingest.get('api_used')}/{ingest.get('api_budget')}")
    lines.append(f"- 规律卡片: {meta.get('counts', {}).get('rule_cards')}")
    lines.append(
        f"- 名单: A={meta.get('counts', {}).get('leads_a')} "
        f"B={meta.get('counts', {}).get('leads_b')} "
        f"可行动={meta.get('counts', {}).get('actionable')}"
    )
    lines.append("")
    tiers = Counter(r.get("hit_tier") for r in structured)
    systems = Counter(r.get("buyer_system") for r in structured if r.get("hit_tier") in ("target", "near"))
    lines.append("## 结构快照")
    lines.append("")
    lines.append("| hit_tier | n |")
    lines.append("|----------|---|")
    for k, v in tiers.most_common():
        lines.append(f"| {k} | {v} |")
    lines.append("")
    lines.append("强命中系统分布（target/near）:")
    for k, v in systems.most_common(10):
        lines.append(f"- {k}: {v}")
    lines.append("")
    lines.append("## 规律卡片")
    lines.append("")
    for c in rule_cards:
        lines.append(f"### `{c['id']}` · {c['type']} · {c['confidence']}")
        lines.append(f"- IF: {c.get('if')}")
        lines.append(f"- THEN: {c.get('then')}")
        sup = c.get("support") or {}
        lines.append(f"- support: n={sup.get('n')} baseline={sup.get('baseline')} regions={sup.get('regions')}")
        lines.append(f"- action: {c.get('action_hint')}")
        lines.append("")
    lines.append("## 名单原始字段")
    lines.append("")
    for lead in leads:
        lines.append(
            f"### [{lead.get('priority')}] {lead.get('buyer')}（{lead.get('region')} · {lead.get('buyer_system')}）"
        )
        lines.append(f"- lead_type: `{lead.get('lead_type')}` actionable={lead.get('actionable')}")
        lines.append(f"- gap: {lead.get('gap_detail')}")
        lines.append(f"- action: {lead.get('suggested_action')}")
        lines.append(f"- rules: {', '.join(lead.get('matched_rules') or [])}")
        for ev in (lead.get("evidence") or [])[:2]:
            lines.append(f"  - [{ev.get('hit_tier')}] {ev.get('title')} ({ev.get('date')})")
        lines.append("")
    return "\n".join(lines)


# backward-compatible alias
def render_report(meta: dict, rule_cards: list, leads: list, structured: list) -> str:
    return render_sales_report(meta, rule_cards, leads, structured)


def write_run_v2(
    run_dir: str,
    structured: List[dict],
    events: List[dict],
    sequences: Dict[str, List[dict]],
    scores: List[dict],
    leads: List[dict],
    meta: Dict,
    species,
    packs: list,
) -> str:
    os.makedirs(run_dir, exist_ok=True)

    with open(os.path.join(run_dir, "structured_records.jsonl"), "w", encoding="utf-8") as f:
        for rec in structured:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    with open(os.path.join(run_dir, "events.jsonl"), "w", encoding="utf-8") as f:
        for e in events:
            f.write(json.dumps(e, ensure_ascii=False) + "\n")

    _write_json(os.path.join(run_dir, "unit_sequences.json"), sequences)
    _write_json(os.path.join(run_dir, "portfolio_scores.json"), scores)
    _write_json(os.path.join(run_dir, "leads.json"), leads)

    run_meta = {
        "run_id": os.path.basename(run_dir),
        "created_at": datetime.now().isoformat(timespec="seconds"),
        **meta,
        "counts": {
            "structured": len(structured),
            "events": len(events),
            "units": len(sequences),
            "leads": len(leads),
            "actionable": sum(1 for x in leads if x.get("actionable")),
            "portfolio_products": len(scores),
        },
    }
    _write_json(os.path.join(run_dir, "run_meta.json"), run_meta)

    sales = render_sales_report_v2(run_meta, scores, leads, events, species, packs)
    tech = render_tech_report_v2(run_meta, scores, leads, events, sequences)

    sales_path = os.path.join(run_dir, "report.md")
    with open(sales_path, "w", encoding="utf-8") as f:
        f.write(sales)
    with open(os.path.join(run_dir, "report_tech.md"), "w", encoding="utf-8") as f:
        f.write(tech)
    with open(os.path.join(run_dir, "report_销售版.md"), "w", encoding="utf-8") as f:
        f.write(sales)
    return sales_path


def render_sales_report_v2(meta, scores, leads, events, species, packs) -> str:
    ingest = meta.get("ingest") or {}
    counts = meta.get("counts") or {}
    action = meta.get("action_regions") or []
    discovery = meta.get("discovery_regions") or []
    lines: List[str] = []
    lines.append(f"# 市场机会报告（销售版）— 物种：{species.display_name}")
    lines.append("")
    lines.append("**给谁看**：销售负责人 / 老板  ")
    lines.append(f"**客户物种**：{species.display_name}（`{species.species_id}`）  ")
    lines.append(f"**货盘**：{', '.join(p.display_name for p in packs)}  ")
    lines.append(f"**落地省份**：{'、'.join(action)}  ")
    lines.append(f"**规律学习省份**：{'、'.join(discovery)}  ")
    lines.append(f"**时间窗**：近 {meta.get('max_age_years', 3)} 年  ")
    lines.append(f"**生成时间**：{meta.get('created_at')}  ")
    lines.append(f"**运行编号**：`{meta.get('run_id')}`  ")
    lines.append(
        f"**数据**：物种命中 {meta.get('structured_after_date_filter')} 条单位公告；"
        f"采购事件 {counts.get('events')}；序列单位 {counts.get('units')}；"
        f"API {ingest.get('api_used')}/{ingest.get('api_budget')}。数字来自本次运行。"
    )
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 一句话结论")
    lines.append("")
    if scores:
        top = scores[0]
        lines.append(
            f"在「{species.display_name}」物种下，货盘中相对最值得推的是"
            f"**{top.get('display_name')}**（机会{top.get('band')}，分 {top.get('score')}）。"
            f"落地区缺口名单 {len(leads)} 家，可用电话 {counts.get('actionable', 0)} 家。"
        )
    else:
        lines.append("本物种近窗内有效采购事件不足，暂无法对货盘打分。请加大 API 或放宽地区后重跑。")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 1. 货盘机会对照")
    lines.append("")
    lines.append("| 产品 | 相对机会 | 分数 | 主要依据 |")
    lines.append("|------|----------|------|----------|")
    for s in scores:
        why = "；".join((s.get("rationale") or [])[:2])
        lines.append(f"| {s.get('display_name')} | {s.get('band')} | {s.get('score')} | {why} |")
    lines.append("")
    lines.append("> 分数为物种内相对可能性（0–100），不是精确成交概率。")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 2. 关键发现")
    lines.append("")
    # simple product frequency among events
    prod_c = Counter(e.get("product_name") for e in events if e.get("hit_tier") in ("target", "near", "related"))
    if prod_c:
        lines.append("### 纵向：本物种近窗采购痕迹")
        lines.append("")
        for name, n in prod_c.most_common(8):
            lines.append(f"- {name}：{n} 条事件")
        lines.append("")
    lines.append("### 横向：跨地跟风（逻辑）")
    lines.append("")
    lines.append(
        f"发现区（{'、'.join(discovery)}）同类单位若已出现某产品，"
        f"落地区（{'、'.join(action)}）同物种未覆盖单位优先跟进——详见名单。"
    )
    lines.append("")
    if species.industry_notes:
        lines.append("### 物种行业笔记（先验）")
        lines.append("")
        for n in species.industry_notes[:5]:
            lines.append(f"- {n}")
        lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 3. 本周行动建议")
    lines.append("")
    lines.append(f"1. 只打「{species.display_name}」物种，不和其他局混谈。")
    if scores:
        lines.append(f"2. 货盘优先推：{scores[0].get('display_name')}（{scores[0].get('band')}）。")
    lines.append("3. 名单以关联缺口为主；无电话走集成商/运营商。")
    lines.append("4. 话术：兄弟单位/外省同类已上什么 → 你们还缺什么。")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 4. 落地区缺口名单")
    lines.append("")
    if not leads:
        lines.append("暂无落地区缺口名单（近窗内该物种关联命中不足，或均已强相关覆盖）。")
        lines.append("")
    else:
        lines.append("| 单位 | 省 | 层级 | 缺口产品 | 建议 | 证据 |")
        lines.append("|------|----|------|----------|------|------|")
        pack_name = {p.pack_id: p.canonical_product for p in packs}
        for x in leads:
            gaps = "、".join(pack_name.get(g, g) for g in (x.get("gap_products") or []))
            ev = (x.get("evidence") or [{}])[0]
            evs = f"{(ev.get('title') or '')[:36]}（{(ev.get('date') or '')[:10]}）"
            if ev.get("matched_keyword"):
                evs += f" ·「{ev.get('matched_keyword')}」"
            if ev.get("note"):
                evs = f"{ev.get('note')}；{evs}"
            act = "直联" if x.get("actionable") else "走集成商/补电话"
            lt = x.get("lead_type")
            if lt == "assoc_gap":
                ltype = "关联缺口"
            elif lt == "peer_gap":
                ltype = "同省跟风缺口"
            elif lt == "already_bought":
                ltype = "已购参照"
            else:
                ltype = "跨地跟风"
            lines.append(
                f"| {x.get('buyer')} | {x.get('region')} | {x.get('level') or '-'} | {ltype}/{gaps} | {act} | {evs} |"
            )
        lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 5. 说明")
    lines.append("")
    lines.append("- v2 物种优先：提问必须带物种；产品是货盘评分对象。")
    lines.append("- 近 N 年 + 标题真实命中；工程师明细见 `report_tech.md`。")
    lines.append("")
    return "\n".join(lines)


def render_tech_report_v2(meta, scores, leads, events, sequences) -> str:
    lines = []
    lines.append(f"# Fold v2 技术明细 — `{meta.get('species_id')}`")
    lines.append("")
    lines.append(json.dumps(meta.get("counts"), ensure_ascii=False, indent=2))
    lines.append("")
    lines.append("## portfolio_scores")
    lines.append("")
    lines.append("```json")
    lines.append(json.dumps(scores, ensure_ascii=False, indent=2))
    lines.append("```")
    lines.append("")
    lines.append(f"## sequences（{len(sequences)} units，仅列出前 10）")
    lines.append("")
    for i, (k, seq) in enumerate(list(sequences.items())[:10]):
        lines.append(f"### {k}（{len(seq)} events）")
        for e in seq[-5:]:
            lines.append(
                f"- {e.get('date')} [{e.get('hit_tier')}] {e.get('product_name')} "
                f"«{e.get('matched_keyword')}» {(e.get('title') or '')[:50]}"
            )
        lines.append("")
    return "\n".join(lines)
