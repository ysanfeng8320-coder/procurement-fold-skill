"""Structure: product-anchored soft labels (no universal taxonomy)."""
from __future__ import annotations

import re
from datetime import datetime, timedelta
from typing import List, Optional, Tuple

from .pack_loader import ProductPack


def _amount_bucket(wan: float) -> str:
    if wan <= 0:
        return "unknown"
    if wan < 1:
        return "<1万"
    if wan < 5:
        return "1-5万"
    if wan < 10:
        return "5-10万"
    if wan < 30:
        return "10-30万"
    if wan < 100:
        return "30-100万"
    return ">100万"


def parse_publish_date(publish_time: str) -> Optional[datetime]:
    if not publish_time:
        return None
    s = str(publish_time).strip()
    for fmt, n in (("%Y-%m-%d %H:%M:%S", 19), ("%Y-%m-%d", 10), ("%Y/%m/%d", 10), ("%Y%m%d", 8)):
        try:
            return datetime.strptime(s[:n], fmt)
        except Exception:
            pass
    m = re.search(r"(20\d{2})[-/](\d{1,2})[-/](\d{1,2})", s)
    if m:
        return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    m = re.search(r"(20\d{2})[-/](\d{1,2})", s)
    if m:
        return datetime(int(m.group(1)), int(m.group(2)), 1)
    return None


def _year_month(publish_time: str) -> Optional[str]:
    dt = parse_publish_date(publish_time)
    return dt.strftime("%Y-%m") if dt else None


def hit_tier(text: str, pack: ProductPack) -> Tuple[str, Optional[str]]:
    """Return (tier, matched_keyword). Title/text must itself contain the keyword."""
    t = text or ""
    for kw in sorted(pack.target, key=len, reverse=True):
        if kw and kw in t:
            return "target", kw
    for kw in sorted(pack.near, key=len, reverse=True):
        if kw and kw in t:
            return "near", kw
    for kw in sorted(pack.related, key=len, reverse=True):
        if kw and kw in t:
            return "related", kw
    for kw in sorted(pack.confuse, key=len, reverse=True):
        if kw and kw in t:
            return "confuse", kw
    return "none", None


def classify_system(buyer: str, title: str, pack: ProductPack) -> str:
    blob = f"{buyer} {title}"
    for sys_name, kws in pack.systems.items():
        for kw in kws:
            if kw and kw in blob:
                return sys_name
    return "其他"


def structure_records(records: List[dict], pack: ProductPack) -> List[dict]:
    out = []
    for rec in records:
        title = rec.get("title") or ""
        buyers = rec.get("buyers") or []
        buyer = buyers[0] if buyers else ""
        # 只认标题真实命中；禁止用文件名 keyword_hint 把钢琴/办公家具等抬成 related
        tier, matched_kw = hit_tier(title, pack)
        sys_name = classify_system(buyer, title, pack)
        pub = rec.get("publish_time") or ""
        ym = _year_month(pub)
        structured = {
            **rec,
            "buyer": buyer,
            "hit_tier": tier,
            "matched_keyword": matched_kw,
            "buyer_system": sys_name,
            "year_month": ym,
            "amount_bucket": _amount_bucket(float(rec.get("money_wan") or 0)),
            "is_high_value_system": sys_name in (pack.high_value_systems or []),
        }
        out.append(structured)
    return out


def filter_recent(records: List[dict], max_age_years: float = 3.0, now: Optional[datetime] = None) -> List[dict]:
    """Keep records with publish_time within max_age_years. Drop undated for act/fold."""
    now = now or datetime.now()
    cutoff = now - timedelta(days=int(365.25 * max_age_years))
    kept = []
    for r in records:
        dt = parse_publish_date(r.get("publish_time") or "")
        if not dt:
            continue
        if dt >= cutoff:
            kept.append(r)
    return kept


def filter_date_range(
    records: List[dict],
    begin_date: Optional[str] = None,
    end_date: Optional[str] = None,
) -> List[dict]:
    """Keep records with publish_time in [begin_date, end_date] inclusive (YYYY-MM-DD)."""
    begin = parse_publish_date(begin_date) if begin_date else None
    end = parse_publish_date(end_date) if end_date else None
    if end:
        end = end.replace(hour=23, minute=59, second=59)
    kept = []
    for r in records:
        dt = parse_publish_date(r.get("publish_time") or "")
        if not dt:
            continue
        if begin and dt < begin:
            continue
        if end and dt > end:
            continue
        kept.append(r)
    return kept
