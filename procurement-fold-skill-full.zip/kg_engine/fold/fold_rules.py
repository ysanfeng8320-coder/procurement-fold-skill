"""Fold: prior constraints + cooccurrence + temporal surge → rule cards."""
from __future__ import annotations

from collections import Counter, defaultdict
from typing import Dict, List, Optional, Tuple

from .pack_loader import ProductPack


STRONG = {"target", "near"}


def _conf(n: int, min_support: int) -> str:
    if n >= max(min_support * 3, 9):
        return "high"
    if n >= min_support:
        return "medium"
    return "low"


def fold_rules(
    structured: List[dict],
    pack: ProductPack,
    discovery_regions: List[str],
    windows_months: Optional[List[int]] = None,
    min_support: int = 3,
) -> List[dict]:
    windows_months = windows_months or [1, 2]
    cards: List[dict] = []

    discovery = [r for r in structured if r.get("geo_role") == "discovery" or r.get("region") in discovery_regions]
    # If discovery empty, learn from all non-confuse (still transferable hypothesis, lower confidence)
    learn = discovery if discovery else [r for r in structured if r.get("hit_tier") != "confuse"]
    learn_strong = [r for r in learn if r.get("hit_tier") in STRONG]

    # --- prior cards from pack ---
    for i, ctext in enumerate(pack.constraints, 1):
        # light corroboration: keyword overlap with systems in data
        support_n = 0
        regions = sorted({r.get("region") for r in learn_strong if r.get("region")})
        # heuristic corroboration by system mentions in constraint text
        for r in learn_strong:
            sys_name = r.get("buyer_system") or ""
            if sys_name != "其他" and any(k in ctext for k in sys_name.replace("系统", "").split("/")):
                support_n += 1
            elif "纪委" in ctext and r.get("buyer_system") == "纪检监察系统":
                support_n += 1
            elif "公安" in ctext and r.get("buyer_system") == "公安系统":
                support_n += 1
            elif ("杭州" in ctext or "合肥" in ctext or "浙江" in ctext or "安徽" in ctext) and r.get("region") in ("浙江", "安徽"):
                support_n += 1
            elif "电子印章" in ctext and r.get("hit_tier") == "related":
                support_n += 1
            elif "分散" in ctext and r.get("buyer_system") in ("公安系统", "基层治理/村居"):
                support_n += 1

        cards.append({
            "id": f"prior_{i:02d}",
            "type": "prior",
            "if": f"产品包约束成立：{ctext[:40]}…",
            "then": ctext,
            "support": {"n": support_n, "baseline": None, "regions": regions[:8]},
            "counterexamples": [],
            "confidence": _conf(support_n, min_support) if support_n else "low",
            "action_hint": "在落地区扫描匹配该约束的系统/缺口单位",
            "sources": ["prior", "bids"] if support_n else ["prior"],
        })

    # --- system cooccurrence among strong hits ---
    sys_counter = Counter(r.get("buyer_system") or "其他" for r in learn_strong)
    total_strong = len(learn_strong) or 1
    for sys_name, n in sys_counter.most_common(12):
        if sys_name == "其他" or n < min_support:
            continue
        share = n / total_strong
        # counterexamples: high-value systems with near-zero in discovery
        cards.append({
            "id": f"cooc_sys_{sys_name}",
            "type": "cooccurrence",
            "if": f"公告命中{pack.canonical_product}族（target/near）",
            "then": f"买方系统更可能是「{sys_name}」（发现区占比 {share:.0%}，n={n}）",
            "support": {
                "n": n,
                "baseline": round(share, 3),
                "regions": sorted({r.get("region") for r in learn_strong if r.get("buyer_system") == sys_name and r.get("region")}),
            },
            "counterexamples": [],
            "confidence": _conf(n, min_support),
            "action_hint": f"落地区优先扫描「{sys_name}」中未见本品强命中的单位",
            "sources": ["bids"],
        })

    # --- related vs target gap pattern ---
    buyers_related = defaultdict(list)
    buyers_target = set()
    for r in learn:
        b = r.get("buyer")
        if not b:
            continue
        if r.get("hit_tier") in STRONG:
            buyers_target.add(b)
        if r.get("hit_tier") == "related" and r.get("matched_keyword"):
            buyers_related[b].append(r)
    gap_buyers = [b for b in buyers_related if b not in buyers_target]
    if len(gap_buyers) >= min_support:
        cards.append({
            "id": "cooc_assoc_gap",
            "type": "cooccurrence",
            "if": "单位出现电子印章/用印等关联命中，但无印控硬件强命中",
            "then": f"存在关联缺口机会（发现区样本 {len(gap_buyers)} 家）",
            "support": {"n": len(gap_buyers), "baseline": None, "regions": discovery_regions},
            "counterexamples": list(buyers_target)[:5],
            "confidence": _conf(len(gap_buyers), min_support),
            "action_hint": "落地区导出 assoc_gap 名单",
            "sources": ["bids", "prior"],
        })

    # --- temporal surge ---
    for w in windows_months:
        surge_cards = _detect_surges(learn, window=w, min_support=min_support, pack=pack)
        cards.extend(surge_cards)

    # Keep at most 8 most recent surge cards (by month in id)
    surges = [c for c in cards if c["type"] == "temporal_surge"]
    others = [c for c in cards if c["type"] != "temporal_surge"]

    def surge_month(c):
        # id like surge_prod_2m_2026-05
        parts = c["id"].split("_")
        for p in reversed(parts):
            if len(p) == 7 and p[4] == "-":
                return p
        return "0000-00"

    surges.sort(key=lambda c: surge_month(c), reverse=True)
    cards = surges[:8] + others

    # sort: surge/cooc with higher support first, priors keep order at end-ish
    def sort_key(c):
        typ = {"temporal_surge": 0, "cooccurrence": 1, "diffusion": 2, "prior": 3}.get(c["type"], 9)
        conf = {"high": 0, "medium": 1, "low": 2}.get(c["confidence"], 9)
        return (typ, conf, -(c.get("support") or {}).get("n") or 0)

    cards.sort(key=sort_key)
    return cards


def _detect_surges(records: List[dict], window: int, min_support: int, pack: ProductPack) -> List[dict]:
    # month -> system -> count (strong hits)
    by_month_sys = defaultdict(Counter)
    by_month_prod = Counter()
    months = []
    for r in records:
        ym = r.get("year_month")
        if not ym:
            continue
        months.append(ym)
        if r.get("hit_tier") in STRONG:
            by_month_sys[ym][r.get("buyer_system") or "其他"] += 1
            by_month_prod[ym] += 1
    if not months:
        return []

    uniq_months = sorted(set(months))
    cards = []

    def window_sum(series: Dict[str, int], end_idx: int, w: int) -> int:
        total = 0
        for j in range(max(0, end_idx - w + 1), end_idx + 1):
            total += series.get(uniq_months[j], 0)
        return total

    # product-level surge
    prod_series = {m: by_month_prod.get(m, 0) for m in uniq_months}
    for i, m in enumerate(uniq_months):
        if i < 3:
            continue
        cur = window_sum(prod_series, i, window)
        # baseline: previous 3 months average * window
        prev_vals = [prod_series.get(uniq_months[j], 0) for j in range(max(0, i - window - 2), i - window + 1)]
        if not prev_vals:
            continue
        baseline = sum(prev_vals) / max(len(prev_vals), 1)
        if cur >= min_support and baseline >= 0 and cur >= max(baseline * 2, baseline + min_support):
            cards.append({
                "id": f"surge_prod_{window}m_{m}",
                "type": "temporal_surge",
                "if": f"近{window}个月（截至 {m}）{pack.canonical_product}族强命中相对基线抬升",
                "then": f"品类涌现：窗口计数={cur}，基线≈{baseline:.1f}",
                "support": {"n": cur, "baseline": round(baseline, 2), "regions": []},
                "counterexamples": [],
                "confidence": _conf(cur, min_support),
                "action_hint": "检查落地区同期是否抬头；抬头则抬高名单优先级",
                "sources": ["bids"],
            })

    # system-level surge
    systems = set()
    for c in by_month_sys.values():
        systems.update(c.keys())
    for sys_name in systems:
        if sys_name == "其他":
            continue
        series = {m: by_month_sys[m].get(sys_name, 0) for m in uniq_months}
        for i, m in enumerate(uniq_months):
            if i < 3:
                continue
            cur = window_sum(series, i, window)
            prev_vals = [series.get(uniq_months[j], 0) for j in range(max(0, i - window - 2), i - window + 1)]
            if not prev_vals:
                continue
            baseline = sum(prev_vals) / max(len(prev_vals), 1)
            if cur >= min_support and cur >= max(baseline * 2, baseline + min_support):
                cards.append({
                    "id": f"surge_sys_{sys_name}_{window}m_{m}",
                    "type": "temporal_surge",
                    "if": f"近{window}个月「{sys_name}」{pack.canonical_product}族标讯抬升（截至 {m}）",
                    "then": f"系统涌现：窗口={cur}，基线≈{baseline:.1f}",
                    "support": {"n": cur, "baseline": round(baseline, 2), "regions": []},
                    "counterexamples": [],
                    "confidence": _conf(cur, min_support),
                    "action_hint": f"落地区扫描同系统未购单位，优先级 P0/P1",
                    "sources": ["bids"],
                })
    return cards
