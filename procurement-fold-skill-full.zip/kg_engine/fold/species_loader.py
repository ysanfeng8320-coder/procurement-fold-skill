"""Load Species Pack."""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional

try:
    import yaml
except ImportError:
    yaml = None

from .paths import layout as _layout

SPECIES_ROOT = _layout()["species_root"]


@dataclass
class SpeciesPack:
    species_id: str
    display_name: str
    search_keywords: List[str]
    include_name_keywords: List[str]
    exclude_name_keywords: List[str] = field(default_factory=list)
    bridge_prefixes: List[str] = field(default_factory=list)
    level_rules: Dict[str, List[str]] = field(default_factory=dict)
    industry_notes: List[str] = field(default_factory=list)
    pack_dir: str = ""


def _load_yaml(path: str) -> dict:
    with open(path, encoding="utf-8") as f:
        text = f.read()
    if yaml is None:
        raise RuntimeError("需要 PyYAML")
    return yaml.safe_load(text) or {}


def load_species(species_id: str, root: Optional[str] = None) -> SpeciesPack:
    d = os.path.join(root or SPECIES_ROOT, species_id)
    data = _load_yaml(os.path.join(d, "species.yaml"))
    notes = []
    notes_path = os.path.join(d, "industry_notes.md")
    if os.path.exists(notes_path):
        with open(notes_path, encoding="utf-8") as f:
            for line in f:
                m = re.match(r"^\s*\d+\.\s+(.+)$", line)
                if m:
                    notes.append(m.group(1).strip())
    return SpeciesPack(
        species_id=data.get("species_id", species_id),
        display_name=data.get("display_name", species_id),
        search_keywords=list(data.get("search_keywords") or []),
        include_name_keywords=list(data.get("include_name_keywords") or []),
        exclude_name_keywords=list(data.get("exclude_name_keywords") or []),
        bridge_prefixes=list(data.get("bridge_prefixes") or data.get("search_keywords") or [])[:3],
        level_rules=dict(data.get("level_rules") or {}),
        industry_notes=notes,
        pack_dir=d,
    )


def match_species(buyer: str, title: str, species: SpeciesPack) -> bool:
    """以采购单位名为准；标题里出现公安但买方是集成商的不算本物种。"""
    name = buyer or ""
    if not name:
        return False
    if any(ex and ex in name for ex in species.exclude_name_keywords):
        return False
    return any(inc and inc in name for inc in species.include_name_keywords)


def infer_level(buyer: str, species: SpeciesPack) -> str:
    name = buyer or ""
    for level, kws in (species.level_rules or {}).items():
        for kw in kws or []:
            if kw and kw in name:
                return level
    return "其他"
