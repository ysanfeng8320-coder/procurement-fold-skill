#!/usr/bin/env python3
"""场景拟合卡：给定品类，按系统打「份额 × 密度 × 客单价」拟合分。

不是共现排序。复印纸式高共现低利润会被利润筛压低；
「10 家才 1 台」会被密度筛压低。
"""
from __future__ import annotations

import json
import os
import sys
from collections import Counter, defaultdict
from datetime import datetime
from statistics import median
from typing import Dict, List, Optional, Tuple

KG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO_DIR = os.path.dirname(KG_DIR)
if KG_DIR not in sys.path:
    sys.path.insert(0, KG_DIR)

from fold.pack_loader import load_pack
from fold.species_loader import load_species, SPECIES_ROOT, match_species
from fold.ingest import load_local_records
from fold.structure import hit_tier, _year_month
from fold.year_curve_forecast import (
    SPECIES_NAME,
    DEFAULT_UNIT_QIAN,
    wan_to_qian,
    price_tier,
    parse_qty,
)

ACTION = ["陕西", "甘肃"]
ALL_REGIONS = ACTION + [
    "安徽", "浙江", "北京", "上海", "江苏", "山东", "河南", "四川",
    "湖北", "湖南", "广东", "全国",
]

SERVICE_DROP = (
    "物业", "保洁", "食堂", "维保", "运维服务", "劳务派遣", "保安服务",
    "绿化养护", "餐饮服务", "会议服务", "印刷服务", "刻章服务",
)

SEARCH_KWS = {
    "seal_control": ["印控仪", "智能印章", "盖章机", "用印宝", "电子印章", "印控台", "印章柜", "用印柜"],
    "binding_machine": ["装订机", "胶装机", "财务装订机"],
    "shredder": ["碎纸机", "保密碎纸机"],
    "copier": ["复印机", "多功能一体机", "复合机"],
}


def list_species():
    out = []
    for name in sorted(os.listdir(SPECIES_ROOT)):
        p = os.path.join(SPECIES_ROOT, name, "species.yaml")
        if os.path.isfile(p):
            out.append(load_species(name))
    return out


def is_service(title: str) -> bool:
    return any(k in (title or "") for k in SERVICE_DROP)


def margin_label(unit_qian: float) -> Tuple[str, float]:
    """粗利润潜力（非真实毛利）：按客单价带打分 0–100。"""
    if unit_qian <= 0:
        return "金额未知", 20.0
    if unit_qian < 3:
        return "低客单（类似耗材/复印纸带）", 10.0
    if unit_qian < 8:
        return "偏低客单", 35.0
    if unit_qian < 15:
        return "机关常用带", 55.0
    if unit_qian < 50:
        return "高客单设备带（接近你装订机贵价逻辑）", 85.0
    return "项目级大单", 70.0  # 大但不一定是单品可复制


def density_label(qty_per_buyer: float) -> Tuple[str, float]:
    """密度：每家买方平均台数。10院1台 → 0.1 → 弱拟合。"""
    if qty_per_buyer <= 0:
        return "无密度", 0.0
    if qty_per_buyer < 0.4:
        return "极稀（约 ≥3 家才凑 1 台量级）", 15.0
    if qty_per_buyer < 0.8:
        return "偏稀（接近 10 家 1 台感）", 30.0
    if qty_per_buyer < 1.5:
        return "一单一台为主", 55.0
    if qty_per_buyer < 5:
        return "小批量（一家数台）", 75.0
    return "批量密（一家可到几十上百台）", 95.0


def load_product_events(product_id: str) -> List[dict]:
    pack = load_pack(product_id)
    species_list = list_species()
    kws = SEARCH_KWS.get(product_id) or (pack.search_keywords or pack.target or [])[:8]
    if product_id not in DEFAULT_UNIT_QIAN:
        DEFAULT_UNIT_QIAN[product_id] = {
            "court": 20.0, "procuratorate": 20.0, "police": 15.0,
            "agriculture": 10.0, "other": 15.0,
        }

    events: List[dict] = []
    seen = set()
    recs, used_files = load_local_records(kws, ALL_REGIONS)

    for r in recs:
        title = r.get("title") or ""
        if is_service(title):
            continue
        tier, _kw = hit_tier(title, pack)
        if tier in ("none", "confuse"):
            # 文件名强相关且标题含本品词才留
            if not any(k in title for k in (pack.target or [])[:4]):
                continue
            tier = "related"
        buyers = r.get("buyers") or []
        buyer = buyers[0] if buyers else ""
        winners = r.get("winners") or []
        key = f"{r.get('source_id')}|{title[:60]}|{buyer}"
        if key in seen:
            continue
        seen.add(key)

        sp_id = "other"
        for sp in species_list:
            if match_species(buyer, title, sp):
                sp_id = sp.species_id
                break

        money_qian = wan_to_qian(r.get("money_wan") or 0)
        qty, qmethod = parse_qty(title, money_qian, product_id, sp_id, tier)
        unit = round(money_qian / qty, 2) if money_qian and qty else 0.0
        if not unit:
            unit = DEFAULT_UNIT_QIAN[product_id].get(sp_id, 15.0)
        ym = _year_month(r.get("publish_time") or "")
        year = int(ym[:4]) if ym and len(ym) >= 4 and ym[:4].isdigit() else None
        events.append({
            "product_id": product_id,
            "product": pack.canonical_product,
            "buyer": buyer,
            "winners": winners,
            "region": r.get("region"),
            "species_id": sp_id,
            "species": SPECIES_NAME.get(sp_id, "其他单位"),
            "title": title,
            "money_qian": money_qian,
            "qty": qty,
            "qty_method": qmethod,
            "unit_qian": unit,
            "price_tier": price_tier(money_qian if money_qian else unit),
            "ym": ym,
            "year": year,
            "date": r.get("publish_time") or "",
            "hit_tier": tier,
            "source": "local",
        })

    # fold volume pool if present
    vol_path = os.path.join(REPO_DIR, "fold_runs", "20260711_155538_volume", "volume_result.json")
    if os.path.exists(vol_path):
        vol = json.load(open(vol_path, encoding="utf-8"))
        for l in (vol.get("leads_by_product") or {}).get(product_id) or []:
            title = l.get("title") or ""
            if is_service(title):
                continue
            buyer = l.get("buyer") or ""
            sp_id = l.get("species_id") or "other"
            key = f"vol|{buyer}|{title[:50]}|{l.get('date')}"
            if key in seen:
                continue
            seen.add(key)
            money_qian = wan_to_qian(l.get("money_wan") or 0)
            if not money_qian:
                money_qian = DEFAULT_UNIT_QIAN[product_id].get(sp_id, 15.0)
            qty, qmethod = parse_qty(title, money_qian, product_id, sp_id, "target")
            unit = round(money_qian / qty, 2) if money_qian and qty else money_qian
            ym = _year_month(l.get("date") or "")
            year = int(ym[:4]) if ym and len(ym) >= 4 and ym[:4].isdigit() else 2025
            events.append({
                "product_id": product_id,
                "product": pack.canonical_product,
                "buyer": buyer,
                "winners": l.get("winners") or [],
                "region": l.get("region"),
                "species_id": sp_id,
                "species": SPECIES_NAME.get(sp_id, "其他单位"),
                "title": title,
                "money_qian": money_qian,
                "qty": qty,
                "qty_method": qmethod,
                "unit_qian": unit,
                "price_tier": price_tier(money_qian if money_qian else unit),
                "ym": ym,
                "year": year,
                "date": l.get("date") or "",
                "hit_tier": "target",
                "source": "volume_2025",
            })

    return events, used_files


def score_species(events: List[dict], product_id: str) -> dict:
    total_qty = sum(e["qty"] for e in events) or 1
    total_deals = len(events)
    by = defaultdict(list)
    for e in events:
        by[e["species_id"]].append(e)

    rows = []
    for sid, subset in by.items():
        buyers = [e["buyer"] for e in subset if e.get("buyer")]
        uniq = sorted(set(buyers))
        qty = sum(e["qty"] for e in subset)
        deals = len(subset)
        val = sum(e["money_qian"] for e in subset)
        units = [e["unit_qian"] for e in subset if e.get("unit_qian")]
        unit_p50 = median(units) if units else DEFAULT_UNIT_QIAN.get(product_id, {}).get(sid, 15.0)
        share = qty / total_qty
        qty_per_buyer = (qty / len(uniq)) if uniq else 0.0
        orgs_per_unit = (len(uniq) / qty) if qty else 0.0

        m_lab, m_score = margin_label(float(unit_p50))
        d_lab, d_score = density_label(qty_per_buyer)
        share_score = min(100.0, share * 100.0 * 1.2)  # 份额越高越好，略放大

        # 样本太少降权
        sample_pen = 1.0
        if deals < 3:
            sample_pen = 0.55
        elif deals < 8:
            sample_pen = 0.8

        fit = round((0.30 * share_score + 0.35 * d_score + 0.35 * m_score) * sample_pen, 1)

        # 赢家
        wcount = Counter()
        for e in subset:
            for w in e.get("winners") or []:
                if w:
                    wcount[w] += 1

        tiers = Counter(e["price_tier"] for e in subset)
        rows.append({
            "species_id": sid,
            "species": SPECIES_NAME.get(sid, sid),
            "deals": deals,
            "qty": qty,
            "unique_buyers": len(uniq),
            "qty_per_buyer": round(qty_per_buyer, 2),
            "orgs_per_unit": round(orgs_per_unit, 2),
            "share_pct": round(share * 100, 1),
            "value_qian": round(val, 1),
            "unit_p50_qian": round(float(unit_p50), 2),
            "main_tier": max(tiers.items(), key=lambda x: x[1])[0] if tiers else "金额未知",
            "margin_label": m_lab,
            "density_label": d_lab,
            "share_score": round(share_score, 1),
            "density_score": round(d_score, 1),
            "margin_score": round(m_score, 1),
            "sample_penalty": sample_pen,
            "fit_score": fit,
            "top_winners": [{"name": n, "deals": c} for n, c in wcount.most_common(8)],
            "sample_buyers": uniq[:8],
        })

    rows.sort(key=lambda x: (-x["fit_score"], -x["qty"]))
    return {
        "total_deals": total_deals,
        "total_qty": total_qty if isinstance(total_qty, int) else int(total_qty),
        "rows": rows,
    }


FINER_RULES = [
    ("公安/派出所", ["公安", "派出所", "交警", "警务", "看守所"]),
    ("纪检监察", ["纪委", "纪检", "监察委", "监委"]),
    ("政务服务", ["政务", "行政审批", "一网通办", "政务大厅"]),
    ("银行/金融", ["银行", "农信", "农商", "信用社", "保险"]),
    ("法院", ["法院"]),
    ("检察院", ["检察"]),
    ("教育", ["学校", "大学", "学院", "教育局"]),
    ("医院", ["医院", "卫生院", "卫生健康"]),
    ("政府机关", ["人民政府", "管委会", "办公厅", "市委", "县委", "省委", "街道", "乡镇"]),
    ("企业/集成商买方", ["公司", "集团", "有限"]),
]


def finer_tag(buyer: str, title: str) -> str:
    s = (buyer or "") + (title or "")
    for name, kws in FINER_RULES:
        if any(k in s for k in kws):
            return name
    return "未归类"


def finer_breakdown(events: List[dict]) -> List[dict]:
    buckets = defaultdict(list)
    for e in events:
        buckets[finer_tag(e.get("buyer") or "", e.get("title") or "")].append(e)
    rows = []
    for name, subset in buckets.items():
        units = [e["unit_qian"] for e in subset if e.get("unit_qian")]
        buyers = sorted({e["buyer"] for e in subset if e.get("buyer")})
        qty = sum(e["qty"] for e in subset)
        rows.append({
            "label": name,
            "deals": len(subset),
            "qty": qty,
            "unique_buyers": len(buyers),
            "qty_per_buyer": round(qty / len(buyers), 2) if buyers else 0,
            "unit_p50_qian": round(float(median(units)), 2) if units else 0,
            "value_qian": round(sum(e["money_qian"] for e in subset), 1),
        })
    rows.sort(key=lambda x: -x["deals"])
    return rows


def verdict(rows: List[dict]) -> List[str]:
    tips = []
    if not rows:
        return ["样本为空，无法判断。"]
    top = rows[0]
    tips.append(
        f"当前最高拟合：{top['species']}（拟合 {top['fit_score']}）——"
        f"份额 {top['share_pct']}% · 密度 {top['density_label']} · {top['margin_label']}。"
    )
    court = next((r for r in rows if r["species_id"] == "court"), None)
    proc = next((r for r in rows if r["species_id"] == "procuratorate"), None)
    police = next((r for r in rows if r["species_id"] == "police"), None)

    for r in (court, proc):
        if not r:
            continue
        if r["fit_score"] < 40:
            tips.append(
                f"{r['species']}：有出现但拟合偏低（{r['fit_score']}）。"
                f"约 {r['orgs_per_unit']} 家买方才对应 1 台量级；客单中位 {r['unit_p50_qian']} 千元。"
                "更像「能卖但不密」，不宜当主战场。"
            )
        elif r["density_score"] < 40 and r["margin_score"] >= 70:
            tips.append(
                f"{r['species']}：客单够高，但密度偏稀——接近「10 家才 1 台」的弱拟合。"
            )

    if police:
        if police["qty_per_buyer"] >= 5 and police["fit_score"] >= (court["fit_score"] if court else 0):
            tips.append(
                f"公安局密度更高（{police['qty_per_buyer']} 台/买方），若客单可接受，"
                "可能比法检更适合做批量货；需再核对是否真是印控仪而非安防杂项。"
            )
        elif police["deals"] < 3:
            tips.append("公安样本过少，密度结论暂不可靠。")

    other = next((r for r in rows if r["species_id"] == "other"), None)
    if other and other["share_pct"] >= 40:
        tips.append(
            f"「其他单位」份额 {other['share_pct']}%——系统外场景（政务/企业/银行等）很大，"
            "不要只盯法检；下一步应拆 finer 系统词。"
        )
    return tips


def render_html(
    product_id: str,
    pack_name: str,
    scored: dict,
    tips: List[str],
    n_files: int,
    finer: Optional[List[dict]] = None,
) -> str:
    rows = scored["rows"]

    def tr(r):
        wins = "；".join(f"{w['name']}({w['deals']})" for w in r["top_winners"][:5]) or "—"
        return (
            f"<tr><td>{r['species']}</td>"
            f"<td class='num'><b>{r['fit_score']}</b></td>"
            f"<td class='num'>{r['share_pct']}%</td>"
            f"<td class='num'>{r['deals']}</td>"
            f"<td class='num'>{r['qty']}</td>"
            f"<td class='num'>{r['unique_buyers']}</td>"
            f"<td class='num'>{r['qty_per_buyer']}</td>"
            f"<td class='num'>{r['orgs_per_unit']}</td>"
            f"<td class='num'>{r['unit_p50_qian']}</td>"
            f"<td>{r['main_tier']}</td>"
            f"<td>{r['density_label']}</td>"
            f"<td>{r['margin_label']}</td>"
            f"<td class='small'>{wins}</td></tr>"
        )

    tip_html = "".join(f"<li>{t}</li>" for t in tips)
    body_rows = "".join(tr(r) for r in rows) or "<tr><td colspan='13'>无数据</td></tr>"

    # detail blocks
    details = []
    for r in rows:
        if r["deals"] == 0:
            continue
        buyers = "、".join(r["sample_buyers"]) or "—"
        details.append(
            f"<div class='card'><h3>{r['species']} · 拟合 {r['fit_score']}</h3>"
            f"<p>份额分 {r['share_score']} · 密度分 {r['density_score']} · 客单分 {r['margin_score']}"
            f"{' · 样本降权×'+str(r['sample_penalty']) if r['sample_penalty']<1 else ''}</p>"
            f"<p class='small'>样本买方：{buyers}</p></div>"
        )

    return f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"/>
<title>场景拟合卡 · {pack_name}</title>
<style>
body{{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC",sans-serif;
  margin:24px;background:#f4f7f6;color:#1a2b2b;}}
h1{{font-size:22px;margin:0 0 6px}}
.meta{{color:#5a6f6f;font-size:13px;margin-bottom:16px}}
.panel{{background:#fff;border:1px solid #d5e0de;border-radius:10px;padding:16px;margin-bottom:16px}}
table{{width:100%;border-collapse:collapse;font-size:13px}}
th,td{{border-bottom:1px solid #e6eeec;padding:8px 6px;text-align:left;vertical-align:top}}
th{{background:#eef5f3;font-weight:600}}
.num{{text-align:right;font-variant-numeric:tabular-nums}}
.small{{font-size:12px;color:#4a5c5c}}
.card{{background:#f8fbfa;border:1px solid #e0ebe8;border-radius:8px;padding:10px 12px;margin:8px 0}}
.card h3{{margin:0 0 6px;font-size:15px}}
ul{{margin:8px 0 0 18px;line-height:1.6}}
.badge{{display:inline-block;background:#1f5c57;color:#fff;padding:2px 8px;border-radius:4px;font-size:12px}}
</style></head><body>
<h1>场景拟合卡 · {pack_name}</h1>
<p class="meta">金额单位=千元 · 已排除物业/服务类标题 · 本地文件约 {n_files} 个命中 ·
样本 {scored['total_deals']} 笔 / {scored['total_qty']} 台 ·
<span class="badge">拟合 = 30%份额 + 35%密度 + 35%客单</span>（样本&lt;8 笔降权）</p>

<div class="panel">
<h2 style="font-size:16px;margin:0 0 8px">结论</h2>
<ul>{tip_html}</ul>
</div>

<div class="panel">
<h2 style="font-size:16px;margin:0 0 8px">系统拟合排行</h2>
<table>
<thead><tr>
<th>系统</th><th>拟合分</th><th>份额</th><th>笔数</th><th>台数</th><th>买方数</th>
<th>台/买方</th><th>家/台</th><th>单价中位(千)</th><th>主价位带</th>
<th>密度读法</th><th>客单读法</th><th>中标商(Top)</th>
</tr></thead>
<tbody>{body_rows}</tbody>
</table>
<p class="small" style="margin-top:10px">「家/台」≈ 多少家买方才摊到 1 台；越大越稀（你说的「10 个法院才一台」）。</p>
</div>

<div class="panel">
<h2 style="font-size:16px;margin:0 0 8px">更细场景拆解（含「其他单位」内部）</h2>
<table>
<thead><tr><th>场景粗分</th><th>笔数</th><th>台数</th><th>买方数</th><th>台/买方</th><th>单价中位(千)</th><th>采购额(千)</th></tr></thead>
<tbody>
{''.join(
    f"<tr><td>{r['label']}</td><td class='num'>{r['deals']}</td><td class='num'>{r['qty']}</td>"
    f"<td class='num'>{r['unique_buyers']}</td><td class='num'>{r['qty_per_buyer']}</td>"
    f"<td class='num'>{r['unit_p50_qian']}</td><td class='num'>{r['value_qian']}</td></tr>"
    for r in (finer or [])
) or '<tr><td colspan="7">无</td></tr>'}
</tbody>
</table>
<p class="small">若公安/纪检在此表几乎为 0，说明本机印控仪样本里还没出现「一局上百台」结构——不能拿装订机法检逻辑硬套。</p>
</div>

<div class="panel">
<h2 style="font-size:16px;margin:0 0 8px">分项拆解</h2>
{''.join(details)}
</div>
</body></html>"""


def main():
    product_id = sys.argv[1] if len(sys.argv) > 1 else "seal_control"
    pack = load_pack(product_id)
    print(f"LOAD {product_id} …")
    events, used_files = load_product_events(product_id)
    print(f"EVENTS {len(events)} from ~{len(used_files)} files")
    scored = score_species(events, product_id)
    tips = verdict(scored["rows"])
    finer = finer_breakdown(events)
    # 公安缺失时显式提示
    police_finer = next((x for x in finer if x["label"].startswith("公安")), None)
    if not police_finer or police_finer["deals"] == 0:
        tips.append(
            "本机印控仪样本中几乎没有公安买方——无法验证「一局采购100台×4千」假设；需单独补公安关键词/额度拉取。"
        )
    for t in tips:
        print("·", t)
    for r in scored["rows"]:
        print(
            f"  {r['species']}: fit={r['fit_score']} share={r['share_pct']}% "
            f"deals={r['deals']} qty={r['qty']} buyers={r['unique_buyers']} "
            f"qty/buyer={r['qty_per_buyer']} unit_p50={r['unit_p50_qian']}千"
        )
    print("FINER:")
    for r in finer[:12]:
        print(
            f"  {r['label']}: deals={r['deals']} qty={r['qty']} "
            f"buyers={r['unique_buyers']} unit_p50={r['unit_p50_qian']}千"
        )

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = os.path.join(REPO_DIR, "fold_runs", f"{ts}_scene_fit_{product_id}")
    os.makedirs(out_dir, exist_ok=True)
    html = render_html(
        product_id,
        pack.display_name or pack.canonical_product,
        scored,
        tips,
        len(used_files),
        finer=finer,
    )
    html_path = os.path.join(out_dir, "report.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)
    payload = {
        "product_id": product_id,
        "n_events": len(events),
        "scored": scored,
        "finer": finer,
        "tips": tips,
        "generated_at": ts,
    }
    with open(os.path.join(out_dir, "scene_fit.json"), "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    print("DONE", html_path)
    return html_path


if __name__ == "__main__":
    main()
