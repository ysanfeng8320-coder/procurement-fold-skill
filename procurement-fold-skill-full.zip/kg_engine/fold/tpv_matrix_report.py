#!/usr/bin/env python3
"""TPV matrix: product tabs × species tabs, all local gov-procurement data.

Same 3 panels (train 2025 → predict 2026 → validate 2026), filterable by
品类 + 系统. Includes every product pack + scout keywords on disk.
"""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime
from typing import Dict, List, Optional

KG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO_DIR = os.path.dirname(KG_DIR)
if KG_DIR not in sys.path:
    sys.path.insert(0, KG_DIR)

from fold.pack_loader import load_pack, PACK_ROOT
from fold.species_loader import load_species, SPECIES_ROOT, match_species, infer_level
from fold.ingest import load_local_records
from fold.structure import hit_tier, _year_month
from fold.year_curve_forecast import (
    SPECIES_NAME,
    DEFAULT_UNIT_QIAN,
    wan_to_qian,
    price_tier,
    parse_qty,
)
from fold.train_predict_validate import train_model, predict_2026, validate

ACTION = ["陕西", "甘肃"]
ALL_REGIONS = ACTION + [
    "安徽", "浙江", "北京", "上海", "江苏", "山东", "河南", "四川",
    "湖北", "湖南", "广东", "全国", "甘肃", "陕西",
]

# filename keyword → pack_id
FILE_KW_TO_PACK = {
    "碎纸机": "shredder",
    "复印机": "copier",
    "装订机": "binding_machine",
    "印控仪": "seal_control",
    "智能印章": "seal_control",
    "盖章机": "seal_control",
    "印控台": "seal_control",
    "电子印章": "seal_control",
    "信号屏蔽器": "signal_shield",
    "塑胶跑道": "rubber_track",
}

SEARCH_KWS = {
    "shredder": ["碎纸机", "保密碎纸机", "办公碎纸机"],
    "copier": ["复印机", "多功能一体机", "复合机", "数码复印机"],
    "binding_machine": ["装订机", "胶装机", "财务装订机"],
    "seal_control": ["印控仪", "智能印章", "盖章机", "用印宝", "电子印章", "印控台"],
    "signal_shield": ["信号屏蔽器", "手机信号屏蔽"],
    "rubber_track": ["塑胶跑道", "塑胶场地"],
}


def list_pack_ids() -> List[str]:
    ids = []
    for name in sorted(os.listdir(PACK_ROOT)):
        if os.path.isdir(os.path.join(PACK_ROOT, name)) and os.path.exists(
            os.path.join(PACK_ROOT, name, "lexicon.yaml")
        ):
            ids.append(name)
    return ids


def list_species_ids() -> List[str]:
    ids = []
    for name in sorted(os.listdir(SPECIES_ROOT)):
        if os.path.isdir(os.path.join(SPECIES_ROOT, name)) and os.path.exists(
            os.path.join(SPECIES_ROOT, name, "species.yaml")
        ):
            ids.append(name)
    return ids + ["other"]  # synthetic


def load_universe_events() -> List[dict]:
    pack_ids = list_pack_ids()
    packs = {pid: load_pack(pid) for pid in pack_ids}
    species_list = [load_species(s) for s in list_species_ids() if s != "other"]
    events: List[dict] = []
    seen = set()

    # 1) all local scout via keywords
    for pid, kws in SEARCH_KWS.items():
        if pid not in packs:
            continue
        pack = packs[pid]
        recs, _ = load_local_records(kws, ALL_REGIONS)
        for r in recs:
            title = r.get("title") or ""
            tier, kw = hit_tier(title, pack)
            if tier in ("none", "confuse"):
                # still keep if filename keyword strongly implies product and title contains it
                if not any(k in title for k in (pack.target or [])[:3]):
                    continue
                tier, kw = "related", (pack.target or ["?"])[0]
            buyers = r.get("buyers") or []
            buyer = buyers[0] if buyers else ""
            key = f"local|{pid}|{r.get('source_id')}|{title[:50]}|{buyer}"
            if key in seen:
                continue
            seen.add(key)
            sp_id = "other"
            for sp in species_list:
                if match_species(buyer, title, sp):
                    sp_id = sp.species_id
                    break
            money_qian = wan_to_qian(r.get("money_wan") or 0)
            qty, qmethod = parse_qty(title, money_qian, pid, sp_id, tier)
            unit = round(money_qian / qty, 2) if money_qian and qty else 0.0
            # ensure default unit map has new products
            if pid not in DEFAULT_UNIT_QIAN:
                DEFAULT_UNIT_QIAN[pid] = {
                    "court": 5.0, "procuratorate": 5.0, "police": 5.0,
                    "agriculture": 5.0, "other": 5.0,
                }
            ym = _year_month(r.get("publish_time") or "")
            year = int(ym[:4]) if ym and len(ym) >= 4 and ym[:4].isdigit() else None
            month = int(ym.split("-")[1]) if ym and "-" in ym else None
            events.append({
                "product_id": pid,
                "product": pack.canonical_product,
                "buyer": buyer,
                "region": r.get("region"),
                "species_id": sp_id,
                "species": SPECIES_NAME.get(sp_id, "其他单位"),
                "title": title,
                "money_qian": money_qian,
                "qty": qty,
                "qty_method": qmethod,
                "unit_qian": unit or DEFAULT_UNIT_QIAN[pid].get(sp_id, 5.0),
                "price_tier": price_tier(money_qian if money_qian else unit),
                "ym": ym,
                "year": year,
                "month": month,
                "date": r.get("publish_time") or "",
                "source": "local",
                "hit_tier": tier,
            })

    # 2) volume pool 2025
    vol_path = os.path.join(REPO_DIR, "fold_runs", "20260711_155538_volume", "volume_result.json")
    if os.path.exists(vol_path):
        vol = json.load(open(vol_path, encoding="utf-8"))
        for pid, leads in (vol.get("leads_by_product") or {}).items():
            if pid not in packs:
                continue
            pack = packs[pid]
            if pid not in DEFAULT_UNIT_QIAN:
                DEFAULT_UNIT_QIAN[pid] = {
                    "court": 5.0, "procuratorate": 5.0, "police": 5.0,
                    "agriculture": 5.0, "other": 5.0,
                }
            for l in leads:
                buyer = l.get("buyer") or ""
                title = l.get("evidence_title") or ""
                key = f"vol|{pid}|{l.get('region')}|{buyer}|{title[:40]}"
                if key in seen:
                    continue
                seen.add(key)
                sp_id = l.get("species_id") or "other"
                money_qian = 0.0
                for e in events:
                    if e["product_id"] == pid and e["buyer"] == buyer and e["money_qian"] > 0:
                        money_qian = e["money_qian"]
                        break
                if money_qian <= 0:
                    money_qian = DEFAULT_UNIT_QIAN[pid].get(sp_id, 5.0)
                    qty, qmethod = 1, "default_unit_fill"
                    unit = money_qian
                else:
                    qty, qmethod = parse_qty(title, money_qian, pid, sp_id, "target")
                    unit = round(money_qian / qty, 2) if qty else money_qian
                ym = _year_month(l.get("date") or "")
                year = int(ym[:4]) if ym and len(ym) >= 4 and ym[:4].isdigit() else 2025
                month = int(ym.split("-")[1]) if ym and "-" in ym else None
                events.append({
                    "product_id": pid,
                    "product": pack.canonical_product,
                    "buyer": buyer,
                    "region": l.get("region"),
                    "species_id": sp_id,
                    "species": SPECIES_NAME.get(sp_id, "其他单位"),
                    "title": title,
                    "money_qian": money_qian,
                    "qty": qty,
                    "qty_method": qmethod,
                    "unit_qian": unit,
                    "price_tier": price_tier(money_qian if money_qian else unit),
                    "ym": ym,
                    "year": year,
                    "month": month,
                    "date": l.get("date") or "",
                    "source": "volume_2025",
                    "hit_tier": "target",
                })
    return events


def filter_events(
    events: List[dict],
    product_id: Optional[str],
    species_id: Optional[str],
) -> List[dict]:
    out = events
    if product_id and product_id != "all":
        out = [e for e in out if e.get("product_id") == product_id]
    if species_id and species_id != "all":
        out = [e for e in out if e.get("species_id") == species_id]
    return out


def split_year(events: List[dict]):
    e25 = [e for e in events if e.get("source") == "volume_2025" or e.get("year") == 2025]
    e26 = [e for e in events if e.get("year") == 2026]
    return e25, e26


def build_cell(events: List[dict], product_id: str, species_id: str, label: str) -> dict:
    e25, e26 = split_year(events)
    # train_model expects product_id on events; for "all" use synthetic
    pid_for_model = product_id if product_id != "all" else (events[0]["product_id"] if events else "shredder")
    # ensure DEFAULT map
    if pid_for_model not in DEFAULT_UNIT_QIAN:
        DEFAULT_UNIT_QIAN[pid_for_model] = {
            "court": 5.0, "procuratorate": 5.0, "police": 5.0,
            "agriculture": 5.0, "other": 5.0,
        }
    if not e25 and not e26:
        return {
            "key": f"{product_id}|{species_id}",
            "label": label,
            "product_id": product_id,
            "species_id": species_id,
            "empty": True,
            "n_2025": 0,
            "n_2026": 0,
            "train": None,
            "predict": None,
            "validate": None,
        }
    # If no 2025, still build empty-ish train from nothing
    if e25:
        model = train_model(e25, pid_for_model)
        model["total_qty"] = sum(int(model["monthly"][str(m)]["qty"]) for m in range(1, 13))
        pred = predict_2026(model)
        val = validate(pred, e26, model)
    else:
        model = {
            "product_id": pid_for_model,
            "n_events": 0,
            "total_qty": 0,
            "total_value_qian": 0,
            "monthly": {str(m): {"deals": 0, "qty": 0, "value_qian": 0, "unit_p50_qian": None, "mom_growth_pct": None} for m in range(1, 13)},
            "share": {str(m): 0 for m in range(1, 13)},
            "season_index": {str(m): 0 for m in range(1, 13)},
            "peak_month": 1,
            "species": [],
            "unit_p50_qian": 5.0,
            "tier_dist": {},
            "push_months": [],
        }
        pred = predict_2026(model)
        val = validate(pred, e26, model)
        val["verdict"] = "该组合无2025训练样本，无法做可靠预测验证"

    return {
        "key": f"{product_id}|{species_id}",
        "label": label,
        "product_id": product_id,
        "species_id": species_id,
        "empty": False,
        "n_2025": len(e25),
        "n_2026": len(e26),
        "train": model,
        "predict": pred,
        "validate": val,
    }


def write_html(path: str, payload: dict):
    products = payload["products"]  # [{id,name}]
    species = payload["species"]    # [{id,name}]
    cells = payload["cells"]        # key -> cell
    default_p = payload["default_product"]
    default_s = payload["default_species"]

    prod_tabs = "".join(
        f"<button class='tab ptab {'active' if p['id']==default_p else ''}' data-pid='{p['id']}'>{p['name']}</button>"
        for p in products
    )
    sp_tabs = "".join(
        f"<button class='tab stab {'active' if s['id']==default_s else ''}' data-sid='{s['id']}'>{s['name']}</button>"
        for s in species
    )

    html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>预测系统 · 品类×系统</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<style>
:root{{--ink:#1a1f2e;--muted:#5c6578;--line:#e2e6ef;--bg:#f2f0ea;--paper:#fffcf7;--a:#0d5c63;--b:#8a4b08;--c:#3d4f7c}}
body{{margin:0;font-family:"PingFang SC","Noto Sans SC",sans-serif;color:var(--ink);background:var(--bg)}}
.wrap{{max-width:1220px;margin:0 auto;padding:24px 14px 70px}}
h1{{font-family:"Songti SC",serif;font-size:1.8rem;margin:0 0 6px}}
.sub{{color:var(--muted);font-size:13px}}
.row-label{{font-size:12px;color:var(--muted);margin:10px 0 4px}}
.tabs{{display:flex;flex-wrap:wrap;gap:6px}}
.tab{{border:1px solid var(--line);background:var(--paper);padding:7px 11px;border-radius:4px;cursor:pointer;font-size:12px}}
.tab.active{{background:var(--a);color:#fff;border-color:var(--a)}}
.stab.active{{background:var(--c);border-color:var(--c)}}
.flow{{display:grid;grid-template-columns:1fr auto 1fr auto 1fr;gap:8px;align-items:center;margin:14px 0;font-size:12px}}
.flow .box{{background:var(--paper);border:1px solid var(--line);padding:8px;border-radius:4px;text-align:center}}
.panel{{background:var(--paper);border:1px solid var(--line);border-radius:4px;padding:14px;margin:0 0 14px}}
.panel h2{{font-family:"Songti SC",serif;font-size:1.15rem;margin:0 0 6px;padding-bottom:6px;border-bottom:2px solid var(--a)}}
.panel.p2 h2{{border-color:var(--b)}}
.panel.p3 h2{{border-color:var(--c)}}
.desc{{font-size:12px;color:var(--muted);margin:0 0 10px}}
.stats{{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:6px;margin:6px 0 10px}}
.stat{{border:1px solid var(--line);padding:7px;border-radius:4px}}
.stat b{{display:block;font-size:1.1rem}}
.stat span{{font-size:10px;color:var(--muted)}}
.charts{{display:grid;gap:10px}}
@media(min-width:960px){{.charts.two{{grid-template-columns:1fr 1fr}}}}
.chart-box{{border:1px solid var(--line);padding:8px;border-radius:4px}}
.chart-box h3{{margin:0 0 6px;font-size:12px;color:var(--a)}}
table{{width:100%;border-collapse:collapse;font-size:11px}}
th,td{{padding:5px 6px;border-bottom:1px solid var(--line);text-align:left;white-space:nowrap}}
th{{background:#eef2f0;color:var(--muted);font-size:10px}}
.num{{text-align:right;font-variant-numeric:tabular-nums}}
tr.overlap{{background:#f3faf7}}
.callout{{border-left:3px solid var(--c);background:#eef1f8;padding:8px 10px;margin:8px 0;font-size:12px}}
.callout.ok{{border-color:#1b5e3b;background:#e3f2ea}}
.callout.warn{{border-color:#8a4b08;background:#f8ead8}}
.scroll{{overflow-x:auto}}
.badge{{display:inline-block;background:#e8f3f3;padding:2px 8px;border-radius:3px;font-size:11px;margin-right:4px}}
.empty{{padding:24px;text-align:center;color:var(--muted)}}
</style></head><body>
<div class="wrap">
<h1>预测系统 · 品类 × 系统</h1>
<p class="sub">训练(2025) → 预测(2026，仅用2025逻辑) → 验证(2026实测) · 金额=<b>千元</b>
· 事件总数 <b>{payload['n_events']}</b>
· 当前：<b id="curLabel">-</b></p>

<div class="row-label">品类</div>
<div class="tabs" id="ptabs">{prod_tabs}</div>
<div class="row-label">系统</div>
<div class="tabs" id="stabs">{sp_tabs}</div>

<div class="flow">
  <div class="box"><b>① 2025 训练实绩</b><br/>价格·增长·分布</div>
  <div class="arrow">→</div>
  <div class="box"><b>② 2026 预测</b><br/>不偷看实测</div>
  <div class="arrow">→</div>
  <div class="box"><b>③ 2026 验证</b><br/>预测 vs 实测</div>
</div>

<div id="emptyBox" class="panel empty" style="display:none">该品类×系统组合暂无足够数据</div>

<section class="panel p1" id="panel1">
  <h2>① 2025 训练实绩</h2>
  <p class="desc">当前筛选下的训练样本：哪个月旺、什么价、哪个系统份额（若已锁定系统则看该系统内月分布）。</p>
  <div class="stats" id="tStats"></div>
  <div class="charts two">
    <div class="chart-box"><h3>月度台数与季节指数</h3><canvas id="c1a" height="190"></canvas></div>
    <div class="chart-box"><h3>分布率% 与 环比%</h3><canvas id="c1b" height="190"></canvas></div>
    <div class="chart-box"><h3>采购额(千元)</h3><canvas id="c1c" height="190"></canvas></div>
    <div class="chart-box"><h3>单价中位(千元/台)</h3><canvas id="c1d" height="190"></canvas></div>
  </div>
  <div class="scroll" style="margin-top:10px"><table>
    <thead><tr><th>月</th><th>台数</th><th>分布率%</th><th>季节指数</th><th>采购额(千)</th><th>单价中位(千)</th><th>环比%</th></tr></thead>
    <tbody id="trainMonthBody"></tbody>
  </table></div>
  <div class="scroll" style="margin-top:10px"><table>
    <thead><tr><th>系统</th><th>台数</th><th>份额</th><th>单价中位(千)</th><th>主价位带</th><th>采购额(千)</th></tr></thead>
    <tbody id="trainSpBody"></tbody>
  </table></div>
</section>

<section class="panel p2" id="panel2">
  <h2>② 2026 预测（纯2025逻辑）</h2>
  <p class="desc">不使用任何2026实测。预测台数 = 2025总台数 × 2025月份额。</p>
  <div class="callout" id="pHint"></div>
  <div class="stats" id="pStats"></div>
  <div class="charts two">
    <div class="chart-box"><h3>2026预测台数</h3><canvas id="c2a" height="190"></canvas></div>
    <div class="chart-box"><h3>2026预测分布率%</h3><canvas id="c2b" height="190"></canvas></div>
  </div>
  <div class="scroll"><table>
    <thead><tr><th>月</th><th>预测台数</th><th>预测分布率%</th><th>预测采购额(千)</th><th>季节指数</th></tr></thead>
    <tbody id="predMonthBody"></tbody>
  </table></div>
</section>

<section class="panel p3" id="panel3">
  <h2>③ 2026 验证结果</h2>
  <p class="desc">用2026实测检验训练逻辑。重叠月上校准预测总量后再比台数。</p>
  <div class="callout warn" id="verdictBox"><b>验证结论：</b><span id="verdictText"></span></div>
  <div class="stats" id="vStats"></div>
  <div class="charts two">
    <div class="chart-box"><h3>校准预测 vs 实测</h3><canvas id="c3a" height="200"></canvas></div>
    <div class="chart-box"><h3>原始预测 vs 实测</h3><canvas id="c3b" height="200"></canvas></div>
  </div>
  <div class="scroll"><table>
    <thead><tr><th>月</th><th>原始预测</th><th>校准预测</th><th>实测</th><th>预测份额%</th><th>实测份额%</th><th>误差%</th><th>判定</th></tr></thead>
    <tbody id="valMonthBody"></tbody>
  </table></div>
</section>

<p class="sub">生成于 {payload['generated_at']} · 本机政府采购本地集合 + 成交池</p>
</div>
<script>
const CELLS = {json.dumps(cells, ensure_ascii=False, default=str)};
const months = Array.from({{length:12}},(_,i)=>(i+1)+'月');
let charts = [];
let curP = '{default_p}';
let curS = '{default_s}';

function destroyCharts(){{ charts.forEach(c=>c.destroy()); charts=[]; }}
function line(id, datasets, yTitle){{
  const c = new Chart(document.getElementById(id), {{
    type:'line', data:{{labels:months, datasets}},
    options:{{plugins:{{legend:{{position:'bottom'}}}},
      scales:{{y:{{title:{{display:true,text:yTitle}},beginAtZero:true}}, x:{{title:{{display:true,text:'月份'}}}}}}
  }});
  charts.push(c);
}}

function render(){{
  const key = curP + '|' + curS;
  const b = CELLS[key];
  const pName = document.querySelector(`.ptab[data-pid="${{curP}}"]`)?.textContent || curP;
  const sName = document.querySelector(`.stab[data-sid="${{curS}}"]`)?.textContent || curS;
  document.getElementById('curLabel').textContent = pName + ' × ' + sName;
  document.querySelectorAll('.ptab').forEach(el=>el.classList.toggle('active', el.dataset.pid===curP));
  document.querySelectorAll('.stab').forEach(el=>el.classList.toggle('active', el.dataset.sid===curS));

  const empty = !b || b.empty || (!b.n_2025 && !b.n_2026);
  document.getElementById('emptyBox').style.display = empty ? 'block' : 'none';
  document.getElementById('panel1').style.display = empty ? 'none' : 'block';
  document.getElementById('panel2').style.display = empty ? 'none' : 'block';
  document.getElementById('panel3').style.display = empty ? 'none' : 'block';
  if(empty) return;

  const t=b.train, p=b.predict, v=b.validate;
  document.getElementById('tStats').innerHTML = `
    <div class="stat"><b>${{t.total_qty}}</b><span>年台数</span></div>
    <div class="stat"><b>${{t.total_value_qian}}</b><span>采购额(千元)</span></div>
    <div class="stat"><b>${{t.peak_month}}月</b><span>峰值月</span></div>
    <div class="stat"><b>${{t.unit_p50_qian}}</b><span>单价中位(千)</span></div>
    <div class="stat"><b>${{(t.push_months||[]).map(m=>m+'月').join('、')||'-'}}</b><span>主推月</span></div>
    <div class="stat"><b>${{b.n_2025}}</b><span>2025事件数</span></div>`;
  document.getElementById('pHint').innerHTML = `主推 <b>${{(p.pred_push_months||[]).map(m=>m+'月').join('、')||'-'}}</b>；峰值月预测 <b>${{p.pred_peak_month}}月</b>`;
  document.getElementById('pStats').innerHTML = `
    <div class="stat"><b>${{p.pred_year_qty}}</b><span>预测年台数</span></div>
    <div class="stat"><b>${{p.pred_year_value_qian}}</b><span>预测采购额(千)</span></div>
    <div class="stat"><b>${{p.pred_unit_qian}}</b><span>预测单价(千)</span></div>`;
  document.getElementById('verdictText').textContent = v.verdict||'-';
  document.getElementById('verdictBox').className = 'callout ' + ((v.mape_calibrated_pct!=null && v.mape_calibrated_pct<=35)?'ok':'warn');
  document.getElementById('vStats').innerHTML = `
    <div class="stat"><b>${{v.peak_month_hit===true?'命中':(v.peak_month_hit===false?'未命中':'-')}}</b><span>峰值月</span></div>
    <div class="stat"><b>${{v.mape_calibrated_pct??'-'}}</b><span>重叠月MAPE%</span></div>
    <div class="stat"><b>${{(v.overlap_months||[]).map(m=>m+'月').join('、')||'无'}}</b><span>可验证月</span></div>
    <div class="stat"><b>${{v.actual_total_qty||0}}</b><span>2026实测台数</span></div>
    <div class="stat"><b>${{b.n_2026}}</b><span>2026事件数</span></div>`;

  let tr='';
  for(let m=1;m<=12;m++){{
    const cell=t.monthly[String(m)];
    tr += `<tr><td>${{m}}月</td><td class="num">${{cell.qty}}</td><td class="num">${{(t.share[String(m)]*100).toFixed(2)}}</td><td class="num">${{t.season_index[String(m)]}}</td><td class="num">${{cell.value_qian}}</td><td class="num">${{cell.unit_p50_qian??'-'}}</td><td class="num">${{cell.mom_growth_pct??'-'}}</td></tr>`;
  }}
  document.getElementById('trainMonthBody').innerHTML=tr;
  document.getElementById('trainSpBody').innerHTML=(t.species||[]).map(s=>`<tr><td>${{s.species}}</td><td class="num">${{s.qty}}</td><td class="num">${{s.share_pct}}%</td><td class="num">${{s.unit_p50_qian}}</td><td>${{s.main_tier}}</td><td class="num">${{s.value_qian}}</td></tr>`).join('') || '<tr><td colspan="6">（已锁定单一系统或无系统分布）</td></tr>';
  document.getElementById('predMonthBody').innerHTML=Array.from({{length:12}},(_,i)=>i+1).map(m=>{{
    const cell=p.months[String(m)];
    return `<tr><td>${{m}}月</td><td class="num">${{cell.pred_qty}}</td><td class="num">${{cell.pred_share_pct}}</td><td class="num">${{cell.pred_value_qian}}</td><td class="num">${{cell.season_index}}</td></tr>`;
  }}).join('');
  document.getElementById('valMonthBody').innerHTML=(v.month_rows||[]).map(r=>`<tr class="${{r.in_overlap?'overlap':''}}"><td>${{r.month}}月</td><td class="num">${{r.pred_qty_raw}}</td><td class="num">${{r.pred_qty_calibrated??'-'}}</td><td class="num">${{r.actual_qty??'-'}}</td><td class="num">${{r.pred_share_overlap_pct??'-'}}</td><td class="num">${{r.actual_share_overlap_pct??'-'}}</td><td class="num">${{r.error_pct??'-'}}</td><td>${{r.hit_band}}</td></tr>`).join('');

  destroyCharts();
  const qty25=Array.from({{length:12}},(_,i)=>t.monthly[String(i+1)].qty);
  const season=Array.from({{length:12}},(_,i)=>t.season_index[String(i+1)]);
  const share25=Array.from({{length:12}},(_,i)=>+(t.share[String(i+1)]*100).toFixed(2));
  const growth25=Array.from({{length:12}},(_,i)=>t.monthly[String(i+1)].mom_growth_pct||0);
  const val25=Array.from({{length:12}},(_,i)=>t.monthly[String(i+1)].value_qian);
  const unit25=Array.from({{length:12}},(_,i)=>t.monthly[String(i+1)].unit_p50_qian||0);
  const predQty=Array.from({{length:12}},(_,i)=>p.months[String(i+1)].pred_qty);
  const predShare=Array.from({{length:12}},(_,i)=>p.months[String(i+1)].pred_share_pct);
  const actQty=Array.from({{length:12}},(_,i)=>v.actual_monthly[String(i+1)].qty);
  const calQty=(v.month_rows||[]).map(r=>r.pred_qty_calibrated??0);
  line('c1a',[{{label:'台数',data:qty25,borderColor:'#0d5c63',tension:.25}},{{label:'季节指数',data:season,borderColor:'#8a4b08',borderDash:[4,3],tension:.25}}],'台数/指数');
  line('c1b',[{{label:'分布率%',data:share25,borderColor:'#0d5c63',tension:.25}},{{label:'环比%',data:growth25,borderColor:'#8a4b08',borderDash:[4,3],tension:.25}}],'%');
  line('c1c',[{{label:'采购额(千)',data:val25,borderColor:'#3d4f7c',tension:.25}}],'千元');
  line('c1d',[{{label:'单价中位(千)',data:unit25,borderColor:'#1b5e3b',tension:.25}}],'千元/台');
  line('c2a',[{{label:'预测台数',data:predQty,borderColor:'#8a4b08',tension:.25}}],'台数');
  line('c2b',[{{label:'预测分布率%',data:predShare,borderColor:'#8a4b08',tension:.25}}],'%');
  line('c3a',[{{label:'校准预测',data:calQty,borderColor:'#3d4f7c',tension:.25}},{{label:'实测',data:actQty,borderColor:'#0d5c63',tension:.25}}],'台数');
  line('c3b',[{{label:'原始预测',data:predQty,borderColor:'#8a4b08',borderDash:[4,3],tension:.25}},{{label:'实测',data:actQty,borderColor:'#0d5c63',tension:.25}}],'台数');
}}

document.getElementById('ptabs').addEventListener('click', e=>{{ const b=e.target.closest('.ptab'); if(!b) return; curP=b.dataset.pid; render(); }});
document.getElementById('stabs').addEventListener('click', e=>{{ const b=e.target.closest('.stab'); if(!b) return; curS=b.dataset.sid; render(); }});
render();
</script>
</body></html>"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)


def main():
    # extend default units for new packs
    DEFAULT_UNIT_QIAN["signal_shield"] = {
        "court": 8.0, "procuratorate": 8.0, "police": 10.0, "agriculture": 5.0, "other": 6.0,
    }
    DEFAULT_UNIT_QIAN["rubber_track"] = {
        "court": 500.0, "procuratorate": 500.0, "police": 500.0, "agriculture": 400.0, "other": 300.0,
    }

    events = load_universe_events()
    pack_ids = list_pack_ids()
    packs = {pid: load_pack(pid) for pid in pack_ids}
    products = [{"id": "all", "name": "全部品类"}] + [
        {"id": pid, "name": packs[pid].display_name} for pid in pack_ids
    ]
    species = (
        [{"id": "all", "name": "全部系统"}]
        + [{"id": sid, "name": SPECIES_NAME.get(sid, sid)} for sid in list_species_ids() if sid != "other"]
        + [{"id": "other", "name": "其他单位"}]
    )

    cells = {}
    for p in products:
        for s in species:
            subset = filter_events(events, p["id"], s["id"])
            # for product=all, annotate a stable product_id for model defaults
            if p["id"] == "all":
                for e in subset:
                    e.setdefault("_bundle", True)
            label = f"{p['name']} × {s['name']}"
            cell = build_cell(subset, p["id"], s["id"], label)
            cells[f"{p['id']}|{s['id']}"] = cell
            print(f"  {label}: n25={cell['n_2025']} n26={cell['n_2026']}")

    # default: 碎纸机 × 全部系统 if exists else first non-empty
    default_p, default_s = "shredder", "all"
    if f"{default_p}|{default_s}" not in cells or cells[f"{default_p}|{default_s}"].get("empty"):
        for k, c in cells.items():
            if not c.get("empty") and c.get("n_2025", 0) > 0:
                default_p, default_s = c["product_id"], c["species_id"]
                break

    run_id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_tpv_matrix"
    out_dir = os.path.join(REPO_DIR, "fold_runs", run_id)
    os.makedirs(out_dir, exist_ok=True)
    payload = {
        "products": products,
        "species": species,
        "cells": cells,
        "default_product": default_p,
        "default_species": default_s,
        "n_events": len(events),
        "generated_at": datetime.now().isoformat(timespec="seconds"),
    }
    with open(os.path.join(out_dir, "matrix_result.json"), "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2, default=str)
    html_path = os.path.join(out_dir, "report.html")
    write_html(html_path, payload)
    print("EVENTS", len(events))
    print("CELLS", len(cells))
    print("DEFAULT", default_p, default_s)
    print("DONE", html_path)
    return out_dir, html_path


if __name__ == "__main__":
    main()
