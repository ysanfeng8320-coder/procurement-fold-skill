"""Ingest: load local scout_data + optional API fill within budget."""
from __future__ import annotations

import json
import os
import re
import sys
from typing import Dict, List, Optional, Set, Tuple

KG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO_DIR = os.path.dirname(KG_DIR)
SCOUT_DIR = os.path.join(REPO_DIR, "scout_data")

if KG_DIR not in sys.path:
    sys.path.insert(0, KG_DIR)

PROVINCE_NAME_TO_CODE = {
    "北京": "110000",
    "天津": "120000",
    "河北": "130000",
    "山西": "140000",
    "内蒙古": "150000",
    "辽宁": "210000",
    "吉林": "220000",
    "黑龙江": "230000",
    "上海": "310000",
    "江苏": "320000",
    "浙江": "330000",
    "安徽": "340000",
    "福建": "350000",
    "江西": "360000",
    "山东": "370000",
    "河南": "410000",
    "湖北": "420000",
    "湖南": "430000",
    "广东": "440000",
    "广西": "450000",
    "海南": "460000",
    "重庆": "500000",
    "四川": "510000",
    "贵州": "520000",
    "云南": "530000",
    "西藏": "540000",
    "陕西": "610000",
    "甘肃": "620000",
    "青海": "630000",
    "宁夏": "640000",
    "新疆": "650000",
}
PROVINCE_CODE_TO_NAME = {v: k for k, v in PROVINCE_NAME_TO_CODE.items()}

# 买方/标题里常见地市 → 省（API 省码过滤常失效时用）
CITY_TO_PROVINCE = {
    "西安": "陕西", "宝鸡": "陕西", "咸阳": "陕西", "渭南": "陕西", "汉中": "陕西",
    "榆林": "陕西", "延安": "陕西", "安康": "陕西", "商洛": "陕西", "铜川": "陕西",
    "兰州": "甘肃", "天水": "甘肃", "酒泉": "甘肃", "嘉峪关": "甘肃", "金昌": "甘肃",
    "白银": "甘肃", "武威": "甘肃", "张掖": "甘肃", "平凉": "甘肃", "庆阳": "甘肃",
    "定西": "甘肃", "陇南": "甘肃", "玉门": "甘肃", "敦煌": "甘肃", "肃州": "甘肃",
    "合肥": "安徽", "芜湖": "安徽", "蚌埠": "安徽", "淮南": "安徽", "安庆": "安徽",
    "杭州": "浙江", "宁波": "浙江", "温州": "浙江", "嘉兴": "浙江", "绍兴": "浙江",
    "南京": "江苏", "苏州": "江苏", "无锡": "江苏", "徐州": "江苏", "新沂": "江苏",
    "济南": "山东", "青岛": "山东", "烟台": "山东", "潍坊": "山东",
    "成都": "四川", "绵阳": "四川", "德阳": "四川", "宜宾": "四川",
    "昆明": "云南", "大理": "云南", "弥渡": "云南", "曲靖": "云南",
    "南昌": "江西", "赣州": "江西", "信丰": "江西", "九江": "江西",
    "郑州": "河南", "洛阳": "河南", "开封": "河南",
    "武汉": "湖北", "长沙": "湖南", "广州": "广东", "深圳": "广东",
    "福州": "福建", "厦门": "福建", "贵阳": "贵州", "南宁": "广西",
    "乌鲁木齐": "新疆", "银川": "宁夏", "西宁": "青海", "拉萨": "西藏",
    "呼和浩特": "内蒙古", "沈阳": "辽宁", "大连": "辽宁", "长春": "吉林",
    "哈尔滨": "黑龙江", "石家庄": "河北", "太原": "山西", "海口": "海南",
}


def _infer_region(buyers: List[str], title: str, item: dict, region_hint: str = "") -> str:
    """Prefer buyer/title/API province over search-hint (API province filter is noisy)."""
    api_prov = str(item.get("province") or "").strip()
    if api_prov in PROVINCE_NAME_TO_CODE:
        return api_prov
    code = str(item.get("proviceCode") or item.get("provinceCode") or "")
    if code in PROVINCE_CODE_TO_NAME:
        return PROVINCE_CODE_TO_NAME[code]
    blob = " ".join(buyers) + " " + (title or "")
    # longer names first (内蒙古 before 古)
    for name in sorted(PROVINCE_NAME_TO_CODE.keys(), key=len, reverse=True):
        if name and name in blob:
            return name
    for city, prov in CITY_TO_PROVINCE.items():
        if city in blob:
            return prov
    return region_hint or ""


def _norm_money(raw) -> float:
    if raw is None:
        return 0.0
    if isinstance(raw, (int, float)):
        return float(raw)
    s = str(raw)
    m = re.search(r"([\d.]+)", s)
    if not m:
        return 0.0
    val = float(m.group(1))
    if "万" in s:
        return val
    if val > 10000:
        return val / 10000.0
    return val


def _standardize_record(item: dict, region_hint: str = "", keyword_hint: str = "") -> dict:
    buyers = item.get("partANameList") or []
    if isinstance(buyers, str):
        buyers = [buyers]
    winners = item.get("partBNameList") or []
    if isinstance(winners, str):
        winners = [winners]

    title = re.sub(r"<[^>]+>", "", str(item.get("title") or ""))
    buyer_list = [b for b in buyers if b]
    region = _infer_region(buyer_list, title, item, region_hint=region_hint)

    return {
        "source_id": item.get("id") or item.get("bid_id"),
        "title": title,
        "publish_time": item.get("publishTime") or item.get("pub_time") or "",
        "money_wan": _norm_money(item.get("projectMoney") or item.get("money_wan")),
        "region": region,
        "city": item.get("cityCode") or item.get("city") or "",
        "buyers": buyer_list,
        "winners": [w for w in winners if w],
        "has_file": item.get("hasFile") or item.get("exists_bid_file") or 0,
        "keyword_hint": keyword_hint,
        "_raw_source": item.get("_source") or "local",
        "province_raw": item.get("province") or "",
    }


def _load_scout_file(path: str) -> List[dict]:
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        inner = data.get("data")
        if isinstance(inner, dict) and isinstance(inner.get("data"), list):
            return inner["data"]
        if isinstance(inner, list):
            return inner
        for k in ("items", "records", "list"):
            if isinstance(data.get(k), list):
                return data[k]
    return []


def discover_local_files(keywords: List[str], regions: List[str]) -> List[str]:
    if not os.path.isdir(SCOUT_DIR):
        return []
    files = []
    for name in os.listdir(SCOUT_DIR):
        if not name.endswith(".json"):
            continue
        if "侦察" in name or "行动" in name or "deduped" in name:
            # still allow deduped
            if "deduped" not in name and not name.endswith(".json"):
                continue
        hit_kw = any(kw in name for kw in keywords)
        # filename may use product synonyms already in keywords
        if not hit_kw:
            continue
        hit_region = (not regions) or any(r in name for r in regions) or (
            # files like 印控仪_p1.json without region
            not any(r in name for r in PROVINCE_NAME_TO_CODE.keys())
        )
        # Prefer region-tagged files when regions specified
        if regions:
            if any(r in name for r in regions):
                files.append(os.path.join(SCOUT_DIR, name))
            elif not any(r in name for r in PROVINCE_NAME_TO_CODE.keys()):
                # unscoped — skip for region-specific ingest
                pass
        else:
            files.append(os.path.join(SCOUT_DIR, name))
    return sorted(set(files))


def load_local_records(
    keywords: List[str],
    regions: List[str],
) -> Tuple[List[dict], List[str]]:
    paths = discover_local_files(keywords, regions)
    out: List[dict] = []
    seen: Set[str] = set()
    used = []
    for path in paths:
        fname = os.path.basename(path)
        region_hint = ""
        for r in regions or list(PROVINCE_NAME_TO_CODE.keys()):
            if r in fname:
                region_hint = r
                break
        kw_hint = ""
        for kw in keywords:
            if kw in fname:
                kw_hint = kw
                break
        try:
            raw_items = _load_scout_file(path)
        except Exception:
            continue
        n_before = len(out)
        for item in raw_items:
            if not isinstance(item, dict):
                continue
            rec = _standardize_record(item, region_hint=region_hint, keyword_hint=kw_hint)
            # filter by region if present on record
            if regions and rec["region"] and rec["region"] not in regions:
                continue
            key = str(rec["source_id"] or "") + "|" + rec["title"]
            if key in seen:
                continue
            seen.add(key)
            out.append(rec)
        if len(out) > n_before:
            used.append(path)
    return out, used


def fetch_api_records(
    keywords: List[str],
    regions: List[str],
    budget: int,
    page_size: int = 50,
    begin_date: str = None,
    end_date: str = None,
) -> Tuple[List[dict], int, dict]:
    """Fetch until budget exhausted. Returns records, used_count, meta.
    begin_date/end_date: YYYY-MM-DD，走知了网真实时间窗。
    """
    if budget <= 0:
        return [], 0, {"skipped": True, "reason": "budget=0"}

    from collector import UnifiedCollector, PROVINCE_NAME_TO_CODE as C_MAP

    # extend collector map in-process
    for k, v in PROVINCE_NAME_TO_CODE.items():
        C_MAP[k] = v

    collector = UnifiedCollector()
    status = collector.status()
    records: List[dict] = []
    seen: Set[str] = set()
    used = 0
    meta = {
        "source": None, "status": status, "calls": [],
        "begin_date": begin_date, "end_date": end_date,
        "prefer_zhiliao": bool(begin_date or end_date),
    }

    # Round-robin regions; split budget across keywords so first kw cannot starve others
    seeds = list(dict.fromkeys(keywords))[:16]
    region_list = list(regions) if regions else ["全国"]
    region_budget = max(1, budget // max(len(region_list), 1))
    leftover = budget - region_budget * len(region_list)

    for ri, region in enumerate(region_list):
        if region == "全国":
            code = None
        else:
            code = PROVINCE_NAME_TO_CODE.get(region)
            if not code:
                continue
        allot = region_budget + (leftover if ri == len(region_list) - 1 else 0)
        used_region = 0
        kw_budget = max(1, allot // max(len(seeds), 1))
        kw_leftover = allot - kw_budget * len(seeds)
        for ki, kw in enumerate(seeds):
            if used >= budget or used_region >= allot:
                break
            kw_allot = kw_budget + (kw_leftover if ki == len(seeds) - 1 else 0)
            used_kw = 0
            page = 1
            while used < budget and used_region < allot and used_kw < kw_allot:
                size = min(page_size, budget - used, allot - used_region, kw_allot - used_kw)
                if size <= 0:
                    break
                try:
                    result = collector.collect_one_page(
                        kw, code, page=page, page_size=size,
                        begin_date=begin_date, end_date=end_date,
                        prefer_zhiliao=bool(begin_date or end_date),
                    )
                except Exception as e:
                    meta["calls"].append({"region": region, "kw": kw, "page": page, "error": str(e)})
                    break
                if result.get("error"):
                    meta["calls"].append({"region": region, "kw": kw, "page": page, "error": result["error"]})
                    break
                meta["source"] = result.get("source")
                batch = result.get("records") or []
                meta["calls"].append({
                    "region": region, "kw": kw, "page": page,
                    "got": len(batch), "total": result.get("total"),
                    "begin_date": begin_date, "end_date": end_date,
                })
                if not batch:
                    break
                for item in batch:
                    rec = _standardize_record(item, region_hint="" if region == "全国" else region, keyword_hint=kw)
                    # 全国检索时用 API 回填的 province
                    if not rec.get("region") and item.get("province"):
                        rec["region"] = item.get("province")
                    key = str(rec["source_id"] or "") + "|" + rec["title"]
                    if key in seen:
                        continue
                    seen.add(key)
                    records.append(rec)
                    used += 1
                    used_region += 1
                    used_kw += 1
                    if used >= budget or used_region >= allot or used_kw >= kw_allot:
                        break
                total = result.get("total") or 0
                if used >= budget or used_region >= allot or used_kw >= kw_allot or page * page_size >= total or len(batch) < size:
                    break
                page += 1
        if used >= budget:
            break

    return records, used, meta


def ingest(
    keywords: List[str],
    discovery_regions: List[str],
    action_regions: List[str],
    api_budget: int = 500,
    reuse_local: bool = True,
) -> dict:
    local_records: List[dict] = []
    local_files: List[str] = []
    all_regions = list(dict.fromkeys(list(discovery_regions) + list(action_regions)))

    if reuse_local:
        local_records, local_files = load_local_records(keywords, all_regions)

    # Dedup set for API fill
    have_regions = {r for r in (rec.get("region") for rec in local_records) if r}
    need_discovery = [r for r in discovery_regions if r not in have_regions or True]
    # Always allow API to supplement discovery regions (local often only 陕甘)
    api_regions = [r for r in discovery_regions if r not in action_regions or r not in have_regions]
    # Prefer fetching all discovery regions when local has none for them
    api_regions = []
    for r in discovery_regions:
        local_n = sum(1 for rec in local_records if rec.get("region") == r)
        if local_n < 20:
            api_regions.append(r)

    api_records, api_used, api_meta = [], 0, {"skipped": True}
    if api_budget > 0 and api_regions:
        api_records, api_used, api_meta = fetch_api_records(
            keywords, api_regions, budget=api_budget
        )

    # Also lightly top-up action regions if thin
    remain = max(0, api_budget - api_used)
    if remain > 0 and reuse_local:
        thin_action = []
        for r in action_regions:
            if sum(1 for rec in local_records if rec.get("region") == r) < 5:
                thin_action.append(r)
        if thin_action:
            extra, used2, meta2 = fetch_api_records(keywords, thin_action, budget=remain)
            api_records.extend(extra)
            api_used += used2
            api_meta["action_topup"] = meta2

    seen: Set[str] = set()
    merged: List[dict] = []
    for rec in local_records + api_records:
        key = str(rec["source_id"] or "") + "|" + rec["title"]
        if key in seen:
            continue
        seen.add(key)
        role = "discovery" if rec.get("region") in discovery_regions else (
            "action" if rec.get("region") in action_regions else "other"
        )
        rec["geo_role"] = role
        merged.append(rec)

    return {
        "records": merged,
        "meta": {
            "local_files": local_files,
            "local_count": len(local_records),
            "api_used": api_used,
            "api_budget": api_budget,
            "api_meta": api_meta,
            "merged_count": len(merged),
            "discovery_regions": discovery_regions,
            "action_regions": action_regions,
        },
    }
