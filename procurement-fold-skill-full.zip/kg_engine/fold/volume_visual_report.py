#!/usr/bin/env python3
"""Volume-first visual report: percentage bands + growth curves + 100+ buyer leads.

Fixes the false "1–2 leads" problem: high-volume products use 成交池 (unique buyers),
not only assoc_gap. Uses real 知了网 dated API.
"""
from __future__ import annotations

import json
import os
import sys
from collections import Counter, defaultdict
from datetime import datetime
from typing import Dict, List

KG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO_DIR = os.path.dirname(KG_DIR)
if KG_DIR not in sys.path:
    sys.path.insert(0, KG_DIR)

from collector import UnifiedCollector
from fold.pack_loader import load_pack
from fold.species_loader import load_species, match_species, infer_level
from fold.ingest import fetch_api_records
from fold.structure import filter_date_range, hit_tier, _year_month, _amount_bucket
from fold.portfolio import build_events, score_portfolio, build_unit_sequences, build_volume_leads

ACTION = ["陕西", "甘肃"]
SPECIES_IDS = ["court", "procuratorate", "police", "agriculture"]
PRODUCT_IDS = ["shredder", "copier", "binding_machine", "seal_control"]
BAND_LEGEND = "高 ≥60% ｜ 中 35%–59% ｜ 低 <35%（分值即百分制机会分）"


def market_totals(collector: UnifiedCollector, begin: str, end: str) -> dict:
    import time
    out = {}
    for kw in ["碎纸机", "复印机", "多功能一体机", "装订机", "印控仪",
               "法院碎纸机", "法院复印机", "检察院碎纸机", "检察院复印机"]:
        last_err = None
        for attempt in range(4):
            try:
                r = collector.collect_one_page(
                    kw, None, page=1, page_size=1,
                    begin_date=begin, end_date=end, prefer_zhiliao=True,
                )
                if r.get("error"):
                    raise RuntimeError(r["error"])
                out[kw] = r.get("total") or 0
                last_err = None
                break
            except Exception as e:
                last_err = e
                time.sleep(1.5 * (attempt + 1))
        if last_err is not None:
            print(f"  WARN market {kw}: {last_err}")
            out[kw] = out.get(kw, 0)
        time.sleep(0.3)
    return out


def pull_volume(begin: str, end: str, budget: int, label: str):
    packs = [load_pack(p) for p in PRODUCT_IDS]
    species_list = [load_species(s) for s in SPECIES_IDS]
    # Heavy on volume products + species bridges
    bridge = []
    for sp in species_list:
        for prefix in (sp.bridge_prefixes or [])[:2]:
            for pk in ["碎纸机", "复印机", "多功能一体机", "装订机", "印控仪"]:
                bridge.append(f"{prefix}{pk}")
    bridge = list(dict.fromkeys(bridge))
    product_kws = ["碎纸机", "保密碎纸机", "复印机", "数码复印机", "多功能一体机",
                   "复合机", "装订机", "胶装机", "印控仪", "智能印章"]

    b1 = int(budget * 0.55)
    b2 = int(budget * 0.30)
    b3 = budget - b1 - b2
    print(f"\n=== {label} {begin}→{end} budget={budget} ===")
    r1, u1, m1 = fetch_api_records(bridge[:28], ["全国"], budget=b1, begin_date=begin, end_date=end)
    print(f"  bridge used={u1} got={len(r1)}")
    r2, u2, m2 = fetch_api_records(product_kws, ["全国"], budget=b2, begin_date=begin, end_date=end)
    print(f"  product used={u2} got={len(r2)}")
    r3, u3, m3 = fetch_api_records(
        ["碎纸机", "复印机", "多功能一体机", "装订机"] + bridge[:12],
        ACTION, budget=b3, begin_date=begin, end_date=end,
    )
    print(f"  action used={u3} got={len(r3)}")
    merged = filter_date_range(r1 + r2 + r3, begin_date=begin, end_date=end)
    print(f"  after_date={len(merged)} api_used={u1+u2+u3}")
    return merged, {"api_used": u1 + u2 + u3, "bridge": m1, "product": m2, "action": m3}


def slice_all_species(records: List[dict], packs, species_list):
    """Attach every matching species record (a record may match one species)."""
    discovery = ["安徽", "浙江", "北京", "上海", "江苏", "山东", "河南", "四川", "广东", "湖北", "湖南"]
    out = []
    for rec in records:
        buyers = rec.get("buyers") or []
        buyer = buyers[0] if buyers else ""
        title = rec.get("title") or ""
        region = rec.get("region") or ""
        if region in ACTION:
            geo = "action"
        elif region:
            geo = "discovery"
            if region not in discovery:
                discovery.append(region)
        else:
            geo = "other"
        for sp in species_list:
            if not match_species(buyer, title, sp):
                continue
            out.append({
                **rec,
                "buyer": buyer,
                "species_id": sp.species_id,
                "species_level": infer_level(buyer, sp),
                "year_month": _year_month(rec.get("publish_time") or ""),
                "amount_bucket": _amount_bucket(float(rec.get("money_wan") or 0)),
                "buyer_system": sp.display_name,
                "geo_role": geo,
                "region": region,
            })
            break
    return out, discovery


def monthly_series(events: List[dict], product_ids: List[str]) -> Dict[str, Dict[str, int]]:
    """product -> {YYYY-MM: count}"""
    series = {pid: Counter() for pid in product_ids}
    for e in events:
        pid = e.get("product_pack")
        ym = e.get("year_month")
        if pid in series and ym:
            series[pid][ym] += 1
    return {pid: dict(sorted(c.items())) for pid, c in series.items()}


def mom_growth(monthly: Dict[str, int]) -> List[dict]:
    items = sorted(monthly.items())
    out = []
    prev = None
    for ym, n in items:
        growth = None if prev is None or prev == 0 else round((n - prev) / prev * 100, 1)
        out.append({"month": ym, "count": n, "mom_growth_pct": growth})
        prev = n
    return out


def score_band(score: float) -> tuple:
    if score >= 60:
        return "高", "≥60%"
    if score >= 35:
        return "中", "35%–59%"
    return "低", "<35%"


def write_html(path: str, payload: dict):
    months = payload["chart_months"]
    series_json = json.dumps(payload["chart_series"], ensure_ascii=False)
    growth_json = json.dumps(payload["chart_growth"], ensure_ascii=False)
    months_json = json.dumps(months, ensure_ascii=False)
    market = payload["market_2025"]
    rows = ""
    for r in payload["score_rows"]:
        rows += (
            f"<tr><td>{r['species']}</td><td>{r['product']}</td>"
            f"<td class='num'>{r['score_pct']}</td>"
            f"<td class='center'><span class='band band-{r['band']}'>{r['band']}</span> "
            f"<small>{r['band_range']}</small></td>"
            f"<td class='num'>{r['events']}</td>"
            f"<td class='num'>{r['volume_leads']}</td>"
            f"<td class='num'>{r['action_leads']}</td></tr>"
        )
    lead_blocks = ""
    for pid, leads in payload["leads_by_product"].items():
        name = payload["product_names"][pid]
        items = "".join(
            f"<li><b>{l['buyer']}</b> · {l['region']} · {l.get('species_id','')} · {l.get('date','')[:10]}</li>"
            for l in leads[:40]
        )
        lead_blocks += f"<h3>{name} 成交池线索（展示前40 / 共{len(leads)}）</h3><ol class='leads'>{items}</ol>"

    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>采购折叠 · 成交池与增长率报告</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<style>
:root {{ --ink:#1a1f2e; --muted:#5c6578; --line:#e2e6ef; --bg:#f4f2ec; --paper:#fffcf7; --accent:#0d5c63; }}
* {{ box-sizing:border-box; }}
body {{ margin:0; font-family:"PingFang SC","Noto Sans SC",sans-serif; color:var(--ink); background:var(--bg); }}
.wrap {{ max-width:1100px; margin:0 auto; padding:36px 20px 80px; }}
h1 {{ font-family:"Songti SC","Noto Serif SC",serif; font-size:2rem; margin:0 0 8px; }}
h2 {{ font-family:"Songti SC","Noto Serif SC",serif; margin:36px 0 12px; font-size:1.25rem; }}
h3 {{ margin:22px 0 8px; color:var(--accent); font-size:1rem; }}
.meta {{ color:var(--muted); font-size:14px; display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:8px; }}
.card {{ background:var(--paper); border:1px solid var(--line); border-radius:4px; padding:16px 18px; margin:12px 0; }}
.legend {{ background:#e8f3f3; padding:10px 14px; border-radius:4px; font-size:14px; margin:12px 0; }}
.charts {{ display:grid; grid-template-columns:1fr; gap:20px; }}
@media(min-width:900px){{ .charts {{ grid-template-columns:1fr 1fr; }} }}
.chart-box {{ background:var(--paper); border:1px solid var(--line); padding:14px; border-radius:4px; }}
.chart-box h3 {{ margin-top:0; }}
table {{ width:100%; border-collapse:collapse; font-size:13px; }}
th,td {{ padding:8px 10px; border-bottom:1px solid var(--line); text-align:left; }}
th {{ background:#eef2f0; color:var(--muted); font-size:12px; }}
.num {{ text-align:right; font-variant-numeric:tabular-nums; }}
.center {{ text-align:center; }}
.band {{ padding:1px 7px; border-radius:3px; font-weight:600; font-size:12px; }}
.band-高 {{ background:#e3f2ea; color:#1b5e3b; }}
.band-中 {{ background:#e8ecf6; color:#3d4f7c; }}
.band-低 {{ background:#f0f0f0; color:#666; }}
.stats {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(140px,1fr)); gap:10px; }}
.stat {{ background:var(--paper); border:1px solid var(--line); padding:12px; border-radius:4px; }}
.stat b {{ display:block; font-size:1.35rem; }}
.stat span {{ font-size:12px; color:var(--muted); }}
.leads {{ columns:1; }}
@media(min-width:800px){{ .leads {{ columns:2; }} }}
.leads li {{ margin:4px 0; font-size:13px; break-inside:avoid; }}
.callout {{ border-left:3px solid var(--accent); padding:8px 12px; background:#eef7f7; margin:12px 0; font-size:14px; }}
</style>
</head>
<body>
<div class="wrap">
  <h1>采购折叠 · 成交池与增长率</h1>
  <div class="meta">
    <div>训练窗：{payload['train_begin']} → {payload['train_end']}</div>
    <div>验证窗：{payload['val_begin']} → {payload['val_end']}</div>
    <div>数据源：知了网真实 API</div>
    <div>API 用量：训 {payload['train_api']} / 验 {payload['val_api']}</div>
  </div>

  <div class="legend"><b>档位百分比定义：</b>{BAND_LEGEND}</div>

  <div class="callout">
    <b>为什么以前只有 1–2 条线索？</b>
    不是复印机/碎纸机市场小，而是旧报告只统计「assoc_gap 缺口预测」。
    知了网 2025 全年：碎纸机 <b>{market.get('碎纸机',0):,}</b> 条、复印机 <b>{market.get('复印机',0):,}</b> 条、
    多功能一体机 <b>{market.get('多功能一体机',0):,}</b> 条；印控仪仅 <b>{market.get('印控仪',0):,}</b> 条。
    本报告改为<strong>成交池（单位去重）</strong>：每品目标 ≥100 条线索。
    产品并不算窄——印控仪窄，碎纸/复印极宽；窄的是旧线索算法。
  </div>

  <h2>2025 公开市场体量（知了网 total）</h2>
  <div class="stats">
    <div class="stat"><b>{market.get('碎纸机',0):,}</b><span>碎纸机</span></div>
    <div class="stat"><b>{market.get('复印机',0):,}</b><span>复印机</span></div>
    <div class="stat"><b>{market.get('多功能一体机',0):,}</b><span>多功能一体机</span></div>
    <div class="stat"><b>{market.get('装订机',0):,}</b><span>装订机</span></div>
    <div class="stat"><b>{market.get('印控仪',0):,}</b><span>印控仪</span></div>
    <div class="stat"><b>{market.get('法院碎纸机',0):,}</b><span>法院×碎纸机</span></div>
    <div class="stat"><b>{market.get('法院复印机',0):,}</b><span>法院×复印机</span></div>
  </div>

  <h2>月度成交量与环比增长率</h2>
  <div class="charts">
    <div class="chart-box">
      <h3>2025 抽样月度成交量（物种命中后）</h3>
      <canvas id="volChart" height="220"></canvas>
    </div>
    <div class="chart-box">
      <h3>环比增长率（%）</h3>
      <canvas id="growthChart" height="220"></canvas>
    </div>
  </div>

  <h2>机会分（百分制）与成交池线索量</h2>
  <div class="card" style="overflow-x:auto">
  <table>
    <thead>
      <tr><th>物种</th><th>产品</th><th>机会分</th><th>档位（百分比区间）</th><th>事件</th><th>成交池线索</th><th>其中陕甘</th></tr>
    </thead>
    <tbody>{rows}</tbody>
  </table>
  </div>

  <h2>成交池线索样本</h2>
  <div class="card">{lead_blocks}</div>

  <p style="color:var(--muted);font-size:13px">生成于 {payload['generated_at']} · 源 JSON 同目录 volume_result.json</p>
</div>
<script>
const months = {months_json};
const series = {series_json};
const growth = {growth_json};
const colors = {{ shredder:'#0d5c63', copier:'#8a4b08', binding_machine:'#3d4f7c', seal_control:'#7a1f1f' }};
const names = {json.dumps(payload['product_names'], ensure_ascii=False)};
new Chart(document.getElementById('volChart'), {{
  type:'line',
  data:{{
    labels: months,
    datasets: Object.keys(series).map(pid => ({{
      label: names[pid] || pid,
      data: months.map(m => series[pid][m] || 0),
      borderColor: colors[pid] || '#333',
      backgroundColor: 'transparent',
      tension: 0.25,
      pointRadius: 3,
    }}))
  }},
  options:{{
    plugins:{{ legend:{{ position:'bottom' }}, title:{{ display:false }} }},
    scales:{{
      y:{{ title:{{ display:true, text:'成交条数（抽样）' }}, beginAtZero:true }},
      x:{{ title:{{ display:true, text:'月份' }} }}
    }}
  }}
}});
new Chart(document.getElementById('growthChart'), {{
  type:'line',
  data:{{
    labels: months,
    datasets: Object.keys(growth).map(pid => ({{
      label: (names[pid]||pid) + ' 环比%',
      data: months.map(m => {{
        const row = (growth[pid]||[]).find(x => x.month===m);
        return row && row.mom_growth_pct != null ? row.mom_growth_pct : null;
      }}),
      borderColor: colors[pid] || '#333',
      borderDash: [4,3],
      tension: 0.25,
      pointRadius: 3,
      spanGaps: true,
    }}))
  }},
  options:{{
    plugins:{{ legend:{{ position:'bottom' }} }},
    scales:{{
      y:{{ title:{{ display:true, text:'环比增长率 (%)' }} }},
      x:{{ title:{{ display:true, text:'月份' }} }}
    }}
  }}
}});
</script>
</body>
</html>"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)


def main():
    train_begin, train_end = "2025-01-01", "2025-12-31"
    val_begin, val_end = "2026-04-01", "2026-06-30"

    collector = UnifiedCollector()
    print("market totals 2025...")
    market = market_totals(collector, train_begin, train_end)
    for k, v in market.items():
        print(f"  {k}: {v}")

    train_recs, train_meta = pull_volume(train_begin, train_end, budget=900, label="TRAIN")
    val_recs, val_meta = pull_volume(val_begin, val_end, budget=300, label="VAL")

    packs = [load_pack(p) for p in PRODUCT_IDS]
    species_list = [load_species(s) for s in SPECIES_IDS]
    product_names = {p.pack_id: p.display_name for p in packs}

    structured, discovery = slice_all_species(train_recs, packs, species_list)
    # Build events across all species by concatenating per-species events
    all_events = []
    score_rows = []
    leads_by_product = {pid: [] for pid in PRODUCT_IDS}
    volume_all = []

    for sp in species_list:
        sp_recs = [r for r in structured if r.get("species_id") == sp.species_id]
        events = build_events(sp_recs, sp, packs)
        all_events.extend(events)
        seq = build_unit_sequences(events)
        scores = score_portfolio(events, seq, packs, sp, ACTION, discovery)
        vol = build_volume_leads(events, packs, ACTION, max_per_product=150)
        volume_all.extend(vol)
        by_pid = Counter(l.get("product_pack") for l in vol)
        action_by_pid = Counter(
            l.get("product_pack") for l in vol if l.get("region") in ACTION
        )
        score_map = {s["product_pack"]: s for s in scores}
        for pack in packs:
            s = score_map.get(pack.pack_id) or {"score": 0, "band": "低"}
            band, br = score_band(float(s.get("score") or 0))
            score_rows.append({
                "species": sp.display_name,
                "product": pack.display_name,
                "score": s.get("score") or 0,
                "score_pct": f"{float(s.get('score') or 0):.1f}%",
                "band": band,
                "band_range": br,
                "events": sum(1 for e in events if e.get("product_pack") == pack.pack_id),
                "volume_leads": by_pid.get(pack.pack_id, 0),
                "action_leads": action_by_pid.get(pack.pack_id, 0),
            })
        for l in vol:
            leads_by_product[l["product_pack"]].append(l)

    # If per-species volume still thin for shredder/copier, also build from all_events pooled
    pooled = build_volume_leads(all_events, packs, ACTION, max_per_product=200)
    for l in pooled:
        pid = l["product_pack"]
        key = f"{l.get('region')}|{l.get('buyer')}|{pid}"
        existing = {f"{x.get('region')}|{x.get('buyer')}|{x.get('product_pack')}" for x in leads_by_product[pid]}
        if key not in existing:
            leads_by_product[pid].append(l)

    monthly = monthly_series(all_events, PRODUCT_IDS)
    # union of months
    all_months = sorted({m for d in monthly.values() for m in d.keys()})
    chart_series = {pid: {m: monthly.get(pid, {}).get(m, 0) for m in all_months} for pid in PRODUCT_IDS}
    chart_growth = {pid: mom_growth(monthly.get(pid, {})) for pid in PRODUCT_IDS}

    # lead counts summary
    print("\nVolume leads by product:")
    for pid, ls in leads_by_product.items():
        print(f"  {product_names[pid]}: {len(ls)} (陕甘 {sum(1 for x in ls if x.get('region') in ACTION)})")

    run_id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_volume"
    out_dir = os.path.join(REPO_DIR, "fold_runs", run_id)
    os.makedirs(out_dir, exist_ok=True)

    payload = {
        "train_begin": train_begin,
        "train_end": train_end,
        "val_begin": val_begin,
        "val_end": val_end,
        "train_api": train_meta["api_used"],
        "val_api": val_meta["api_used"],
        "market_2025": market,
        "band_legend": BAND_LEGEND,
        "score_rows": score_rows,
        "product_names": product_names,
        "leads_by_product": {
            pid: [
                {k: v for k, v in l.items() if k != "evidence"} | {
                    "evidence_title": (l.get("evidence") or [{}])[0].get("title")
                }
                for l in leads_by_product[pid]
            ]
            for pid in PRODUCT_IDS
        },
        "lead_counts": {pid: len(leads_by_product[pid]) for pid in PRODUCT_IDS},
        "chart_months": all_months,
        "chart_series": chart_series,
        "chart_growth": chart_growth,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "note": "成交池=单位去重；档位高≥60%/中35–59%/低<35%",
    }
    with open(os.path.join(out_dir, "volume_result.json"), "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2, default=str)

    html_path = os.path.join(out_dir, "report.html")
    write_html(html_path, payload)
    print(f"\nDONE {html_path}")
    # also write canvas data snippet path
    with open(os.path.join(out_dir, "canvas_data.json"), "w", encoding="utf-8") as f:
        json.dump({
            "months": all_months,
            "series": chart_series,
            "growth": chart_growth,
            "lead_counts": payload["lead_counts"],
            "market": market,
            "score_rows": score_rows,
            "band_legend": BAND_LEGEND,
        }, f, ensure_ascii=False, indent=2)
    return out_dir, html_path


if __name__ == "__main__":
    main()
