#!/usr/bin/env python3
"""电话补全（fold 阶段5必做）

策略（沿用 phone_enricher）：
  1. 扫 scout_data 正文/字段抠号 → contacts.json
  2. 反查买方/参照单位的中标商，作「经集成商联系」路径
  3. 可选 API 小预算补号（默认 0=只本地）

用法:
  cd kg_engine && PYTHONPATH=. python3 -B fold/phone_complete.py --harvest-only
  PYTHONPATH=. python3 -B fold/phone_complete.py --run ../fold_runs/20260711_122047_court
  PYTHONPATH=. python3 -B fold/phone_complete.py --run ... --api-budget 30 --province 陕西
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from collections import defaultdict
from datetime import datetime
from typing import Dict, List, Optional, Set

KG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO_DIR = os.path.dirname(KG_DIR)
if KG_DIR not in sys.path:
    sys.path.insert(0, KG_DIR)

from phone_enricher import (  # noqa: E402
    build_contact_path,
    enrich_names,
    harvest_phones_from_scout_data,
    is_real_phone,
    load_contacts,
)


def _load_json(path: str):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _save_json(path: str, obj) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def _jsonl_winner_map(path: str) -> Dict[str, List[dict]]:
    if not os.path.exists(path):
        return {}
    counts: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
            except Exception:
                continue
            buyers = r.get("buyers") or []
            buyer = r.get("buyer") or (buyers[0] if buyers else "")
            for w in r.get("winners") or []:
                if w and buyer:
                    counts[buyer][w] += 1
    return {
        b: [{"name": n, "deal_count": c} for n, c in sorted(wm.items(), key=lambda x: -x[1])]
        for b, wm in counts.items()
    }


def winners_from_scout_for_buyers(buyer_names: List[str]) -> Dict[str, List[dict]]:
    try:
        from builder import collect_scout_files, load_records_from_file
    except Exception:
        return {}
    want = set(buyer_names)
    counts: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    for fpath, _ in collect_scout_files():
        try:
            records = load_records_from_file(fpath)
        except Exception:
            continue
        for item in records:
            if not isinstance(item, dict):
                continue
            buyers = [n.strip() for n in (item.get("partANameList") or []) if n and n.strip()]
            winners = [n.strip() for n in (item.get("partBNameList") or []) if n and n.strip()]
            if not winners:
                continue
            for b in buyers:
                if b in want:
                    for w in winners:
                        counts[b][w] += 1
    return {
        b: [{"name": n, "deal_count": c} for n, c in sorted(wm.items(), key=lambda x: -x[1])]
        for b, wm in counts.items()
    }


def merge_winner_maps(*maps: Dict[str, List[dict]]) -> Dict[str, List[dict]]:
    counts: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    for m in maps:
        for buyer, items in (m or {}).items():
            for it in items:
                counts[buyer][it["name"]] += int(it.get("deal_count") or 1)
    return {
        b: [{"name": n, "deal_count": c} for n, c in sorted(wm.items(), key=lambda x: -x[1])]
        for b, wm in counts.items()
    }


def species_winner_pool_from_scout() -> List[dict]:
    try:
        from builder import collect_scout_files, load_records_from_file
    except Exception:
        return []
    counts: Dict[str, int] = defaultdict(int)
    keys = ("印控", "印章", "盖章", "装订", "碎纸", "复印", "用印")
    for fpath, _ in collect_scout_files():
        if not any(k in os.path.basename(fpath) for k in keys):
            continue
        try:
            records = load_records_from_file(fpath)
        except Exception:
            continue
        for item in records:
            if not isinstance(item, dict):
                continue
            for w in item.get("partBNameList") or []:
                if w and str(w).strip():
                    counts[str(w).strip()] += 1
    return [{"name": n, "deal_count": c} for n, c in sorted(counts.items(), key=lambda x: -x[1])[:25]]


def peer_from_evidence(lead: dict) -> List[str]:
    peers = []
    for ev in lead.get("evidence") or []:
        note = ev.get("note") or ""
        if "参照" in note and "·" in note:
            peers.append(note.split("·")[-1].strip())
    return [p for p in peers if p]


def collect_names(leads, winner_map, pool) -> List[str]:
    names: List[str] = []
    seen: Set[str] = set()

    def add(n: str):
        if n and n not in seen:
            seen.add(n)
            names.append(n)

    for lead in leads:
        buyer = lead.get("buyer") or lead.get("name") or ""
        add(buyer)
        for peer in peer_from_evidence(lead):
            add(peer)
            for it in winner_map.get(peer) or []:
                add(it.get("name") or "")
        for it in winner_map.get(buyer) or []:
            add(it.get("name") or "")
    for it in pool or []:
        add(it.get("name") or "")
    return names


def enrich_leads(leads, winner_map, contacts, species_pool=None) -> List[dict]:
    pool = species_pool or []
    out = []
    for lead in leads:
        row = dict(lead)
        buyer = row.get("buyer") or row.get("name") or ""
        ints: List[dict] = []
        seen: Set[str] = set()

        def add_int(it: dict):
            name = it.get("name") or ""
            if name and name not in seen:
                ints.append(dict(it))
                seen.add(name)

        for it in winner_map.get(buyer) or []:
            add_int(it)
        for peer in peer_from_evidence(row):
            for it in winner_map.get(peer) or []:
                add_int(it)
        # 始终并入物种渠道池（有真号的优先排前）
        for it in pool[:12]:
            add_int(it)

        for it in ints:
            sp = contacts.get(it.get("name", "")) or ""
            it["phone"] = sp if is_real_phone(sp) else "待确认"
        # 有号的集成商排前面，避免无号名单挡住路径
        ints.sort(key=lambda x: (0 if is_real_phone(x.get("phone")) else 1, -(x.get("deal_count") or 0)))

        path = build_contact_path(buyer, ints, contacts)
        row["name"] = buyer
        row["integrators"] = ints
        row["phone"] = path["buyer_phone"]
        row["contact"] = path["buyer_phone"] if is_real_phone(path["buyer_phone"]) else None
        row["contact_path"] = path
        row["contact_display"] = path["display"]
        row["actionable"] = path["path_type"] in ("direct", "via_integrator")
        if row["actionable"]:
            row["action_blocker"] = None
            base = row.get("suggested_action") or ""
            if path["display"] not in base:
                row["suggested_action"] = (base + "；" + path["display"]).strip("；")
        else:
            row["action_blocker"] = "单位与集成商均无可用电话，需附件/人工补全"
        out.append(row)
    out.sort(key=lambda x: (0 if x.get("actionable") else 1, x.get("buyer") or ""))
    return out


def write_phone_report(run_dir, leads, harvest_stats, enrich_stats) -> str:
    actionable = [x for x in leads if x.get("actionable")]
    direct = [x for x in leads if (x.get("contact_path") or {}).get("path_type") == "direct"]
    via = [x for x in leads if (x.get("contact_path") or {}).get("path_type") == "via_integrator"]
    none = [x for x in leads if not x.get("actionable")]

    md = [
        "# 电话补全报告",
        "",
        f"- 生成时间：{datetime.now().isoformat(timespec='seconds')}",
        f"- scout 扫描：{harvest_stats.get('files_scanned', 0)} 文件，新挂 {harvest_stats.get('new_assignments', 0)}，真号 {harvest_stats.get('real_phones_after', 0)}",
        f"- API：{enrich_stats.get('api_calls', 0)} 次 / 查询 {enrich_stats.get('queried', 0)} 名",
        f"- 覆盖：名单 {len(leads)} · 可行动 {len(actionable)}（直联 {len(direct)} / 经集成商 {len(via)}）· 仍缺 {len(none)}",
        "",
        "## 可行动",
        "",
    ]
    for x in actionable:
        md.append(f"- **{x.get('buyer') or x.get('name')}**：{x.get('contact_display')}")
    if none:
        md += ["", "## 仍缺", ""] + [f"- {x.get('buyer') or x.get('name')}" for x in none[:40]]
    with open(os.path.join(run_dir, "phone_report.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(md) + "\n")

    html = f"""<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"/>
<title>电话补全</title>
<style>
body{{font-family:"PingFang SC",sans-serif;margin:24px;background:#f4f7f6;color:#1a2b2b}}
.card{{background:#fff;border:1px solid #d5e0de;border-radius:10px;padding:14px 16px;margin-bottom:12px}}
.ok{{color:#1f6b5c}}.miss{{color:#a65d3a}}
</style></head><body>
<h1>电话补全</h1>
<div class="card">名单 {len(leads)} · 可行动 <b class="ok">{len(actionable)}</b>
（直联 {len(direct)} / 经集成商 {len(via)}）· 仍缺 <b class="miss">{len(none)}</b><br/>
API {enrich_stats.get('api_calls', 0)} · contacts 真号 {harvest_stats.get('real_phones_after', 0)}
</div>
<div class="card"><h2>可行动</h2><ul>
{''.join(f"<li><b>{x.get('buyer') or x.get('name')}</b> — {x.get('contact_display')}</li>" for x in actionable) or '<li>（无）</li>'}
</ul></div>
<div class="card"><h2>仍缺</h2><ul>
{''.join(f"<li>{x.get('buyer') or x.get('name')}</li>" for x in none[:50]) or '<li>（无）</li>'}
</ul></div>
</body></html>"""
    html_path = os.path.join(run_dir, "phone_report.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)
    return html_path


def complete_run(run_dir: str, api_budget: int = 0, province: Optional[str] = None, harvest: bool = True) -> dict:
    run_dir = os.path.abspath(run_dir)
    leads_path = os.path.join(run_dir, "leads.json")
    if not os.path.exists(leads_path):
        raise FileNotFoundError(f"找不到 leads.json: {leads_path}")

    harvest_stats = {"files_scanned": 0, "new_assignments": 0, "real_phones_after": 0}
    if harvest:
        print("Harvest scout_data → contacts.json …")
        harvest_stats = harvest_phones_from_scout_data(save=True)
        print(
            f"  files={harvest_stats['files_scanned']} new={harvest_stats['new_assignments']} "
            f"real={harvest_stats['real_phones_after']}"
        )

    leads = _load_json(leads_path)
    if isinstance(leads, dict):
        leads = leads.get("leads") or leads.get("items") or []

    events_path = os.path.join(run_dir, "events.jsonl")
    structured_path = os.path.join(run_dir, "structured_records.jsonl")
    buyers = []
    for x in leads:
        buyers.append(x.get("buyer") or x.get("name") or "")
        buyers.extend(peer_from_evidence(x))

    winner_map = merge_winner_maps(
        _jsonl_winner_map(events_path),
        _jsonl_winner_map(structured_path),
        winners_from_scout_for_buyers([b for b in buyers if b]),
    )
    pool = species_winner_pool_from_scout()
    names = collect_names(leads, winner_map, pool)
    print(f"Names to resolve: {len(names)}; winner_map buyers: {len(winner_map)}; pool: {len(pool)}")

    enrich_stats = {"api_calls": 0, "queried": len(names), "found": 0, "missing": 0}
    if api_budget > 0 and names:
        print(f"API enrich up to {api_budget} …")
        enrich_stats = enrich_names(
            names, province=province, max_api_calls=api_budget, harvest_first=False
        )

    contacts = load_contacts()
    enriched = enrich_leads(leads, winner_map, contacts, species_pool=pool)
    _save_json(leads_path, enriched)
    _save_json(os.path.join(run_dir, "leads_phoned.json"), enriched)
    html_path = write_phone_report(run_dir, enriched, harvest_stats, enrich_stats)
    n_ok = sum(1 for x in enriched if x.get("actionable"))
    print(f"DONE actionable={n_ok}/{len(enriched)} → {html_path}")
    return {
        "run_dir": run_dir,
        "html_path": html_path,
        "actionable": n_ok,
        "total": len(enriched),
        "harvest": {k: v for k, v in harvest_stats.items() if k != "contacts"},
        "enrich": {k: v for k, v in enrich_stats.items() if k != "contacts"},
    }


def main(argv=None):
    p = argparse.ArgumentParser(description="采购折叠 · 电话补全")
    p.add_argument("--run", help="fold_runs/<id> 目录")
    p.add_argument("--harvest-only", action="store_true")
    p.add_argument("--api-budget", type=int, default=0)
    p.add_argument("--province", default=None)
    p.add_argument("--no-harvest", action="store_true")
    args = p.parse_args(argv)

    if args.harvest_only or not args.run:
        stats = harvest_phones_from_scout_data(save=True)
        print(json.dumps({k: v for k, v in stats.items() if k != "contacts"}, ensure_ascii=False, indent=2))
        if not args.run:
            return

    complete_run(
        args.run,
        api_budget=args.api_budget,
        province=args.province,
        harvest=not args.no_harvest,
    )


if __name__ == "__main__":
    main()
