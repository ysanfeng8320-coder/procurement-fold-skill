"""Load Product Pack from skills/procurement-fold/product_packs/<id>/."""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional

try:
    import yaml
except ImportError:
    yaml = None


from .paths import layout as _layout

PACK_ROOT = _layout()["pack_root"]


@dataclass
class ProductPack:
    pack_id: str
    display_name: str
    canonical_product: str
    target: List[str]
    near: List[str]
    related: List[str]
    confuse: List[str]
    search_keywords: List[str]
    systems: Dict[str, List[str]]
    high_value_systems: List[str]
    constraints: List[str] = field(default_factory=list)
    product_notes: str = ""
    pack_dir: str = ""


def _parse_yaml_simple(text: str) -> dict:
    """Load lexicon YAML; prefer PyYAML, else minimal subset parser."""
    if yaml is not None:
        return yaml.safe_load(text) or {}

    # Minimal subset: key: value | key: | - item | nested key: [a, b] unsupported → use block lists
    root: dict = {}
    stack = [root]  # dicts only
    list_key = None
    current_dict = root
    indent_stack = [0]

    for raw in text.splitlines():
        if not raw.strip() or raw.strip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        line = raw.strip()
        while indent_stack and indent < indent_stack[-1]:
            indent_stack.pop()
            if len(stack) > 1:
                stack.pop()
            current_dict = stack[-1]
            list_key = None

        if line.startswith("- "):
            item = line[2:].strip().strip('"').strip("'")
            if list_key is None:
                continue
            current_dict.setdefault(list_key, []).append(item)
            continue

        if ":" in line:
            key, val = line.split(":", 1)
            key, val = key.strip(), val.strip()
            if val == "":
                # start nested mapping or list
                # peek: systems-style nested dict vs list — decide on next lines; init empty list tentatively
                current_dict[key] = []
                list_key = key
                # also allow nested dict: if next non-list is key at deeper indent under systems
                indent_stack.append(indent + 2)
                continue
            # scalar
            list_key = None
            if val.startswith("[") and val.endswith("]"):
                inner = val[1:-1].strip()
                current_dict[key] = [x.strip().strip('"').strip("'") for x in inner.split(",") if x.strip()] if inner else []
            else:
                current_dict[key] = val.strip('"').strip("'")
            continue

    # Fix systems: entries that look like nested dicts stored wrong.
    # Re-parse systems block properly if present as list of "Name: [a,b]" strings — our lexicon uses nested maps.
    # Second pass for systems/high_value using regex on original text.
    import re
    systems = {}
    in_systems = False
    for raw in text.splitlines():
        if re.match(r"^systems:\s*$", raw):
            in_systems = True
            continue
        if in_systems:
            if raw and not raw.startswith(" ") and not raw.startswith("\t"):
                in_systems = False
                continue
            m = re.match(r"^\s+([^:#]+):\s*\[(.*)\]\s*$", raw)
            if m:
                name = m.group(1).strip()
                items = [x.strip().strip('"').strip("'") for x in m.group(2).split(",") if x.strip()]
                systems[name] = items
    if systems:
        root["systems"] = systems

    # high_value_systems / list fields already ok if parsed as lists
    for list_field in ("target", "near", "related", "confuse", "search_keywords", "high_value_systems"):
        if list_field in root and not isinstance(root[list_field], list):
            root[list_field] = [root[list_field]]
    return root


def _parse_constraints(md: str) -> List[str]:
    items = []
    for line in md.splitlines():
        m = re.match(r"^\s*\d+\.\s+\*\*(.+?)\*\*[：:]\s*(.+)$", line)
        if m:
            items.append(f"{m.group(1)}：{m.group(2).strip()}")
            continue
        m = re.match(r"^\s*\d+\.\s+(.+)$", line)
        if m:
            items.append(m.group(1).strip())
    return items


def load_pack(pack_id: str, pack_root: Optional[str] = None) -> ProductPack:
    root = pack_root or PACK_ROOT
    d = os.path.join(root, pack_id)
    lex_path = os.path.join(d, "lexicon.yaml")
    with open(lex_path, encoding="utf-8") as f:
        lex = _parse_yaml_simple(f.read())

    constraints_path = os.path.join(d, "constraints.md")
    constraints = []
    if os.path.exists(constraints_path):
        with open(constraints_path, encoding="utf-8") as f:
            constraints = _parse_constraints(f.read())

    notes = ""
    notes_path = os.path.join(d, "product_notes.md")
    if os.path.exists(notes_path):
        with open(notes_path, encoding="utf-8") as f:
            notes = f.read()

    return ProductPack(
        pack_id=lex.get("pack_id", pack_id),
        display_name=lex.get("display_name", pack_id),
        canonical_product=lex.get("canonical_product", pack_id),
        target=list(lex.get("target") or []),
        near=list(lex.get("near") or []),
        related=list(lex.get("related") or []),
        confuse=list(lex.get("confuse") or []),
        search_keywords=list(lex.get("search_keywords") or lex.get("target") or []),
        systems=dict(lex.get("systems") or {}),
        high_value_systems=list(lex.get("high_value_systems") or []),
        constraints=constraints,
        product_notes=notes,
        pack_dir=d,
    )
