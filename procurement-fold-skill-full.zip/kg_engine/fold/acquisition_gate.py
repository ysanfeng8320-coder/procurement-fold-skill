#!/usr/bin/env python3
"""采集闸门：场景发现 / 大样本拉取前的硬检查。

不过闸，不准把 API 预算打满。
"""
from __future__ import annotations

import argparse
import os
import sys
from typing import Dict, List, Optional, Tuple

import yaml

from fold.paths import layout as _layout

_L = _layout()
KG_DIR = _L["kg_dir"]
REPO_DIR = _L["repo_dir"]
GATE_PATH = _L["gate_yaml"]



def load_gate_config(path: str = GATE_PATH) -> dict:
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def exclude_keywords(cfg: Optional[dict] = None) -> List[str]:
    cfg = cfg or load_gate_config()
    return list(cfg.get("exclude_title_keywords") or [])


def is_excluded_title(title: str, cfg: Optional[dict] = None) -> bool:
    t = title or ""
    return any(k in t for k in exclude_keywords(cfg))


def budget_cap(mode: str, cfg: Optional[dict] = None) -> int:
    cfg = cfg or load_gate_config()
    modes = cfg.get("budget_modes") or {}
    m = modes.get(mode) or modes.get("test") or {}
    return int(m.get("max_api_records") or 200)


def check_gate(
    *,
    mode: str = "test",
    api_budget: int = 0,
    keywords: Optional[List[str]] = None,
    reuse_local: bool = True,
    species_id: str = "",
    product_id: str = "",
    cfg: Optional[dict] = None,
) -> Dict:
    cfg = cfg or load_gate_config()
    keywords = [k for k in (keywords or []) if k]
    cap = budget_cap(mode, cfg)
    checks = []

    def add(cid: str, ok: bool, detail: str):
        checks.append({"id": cid, "ok": ok, "detail": detail})

    add(
        "exclude_services",
        True,
        f"排除词已加载 {len(exclude_keywords(cfg))} 条（拉数后过滤）",
    )
    add(
        "goods_or_software",
        bool(product_id or keywords),
        "已指定产品/关键词" if (product_id or keywords) else "未指定产品或关键词",
    )
    add(
        "budget_mode",
        mode in (cfg.get("budget_modes") or {}) and api_budget > 0,
        f"mode={mode} budget={api_budget} cap={cap}",
    )
    add(
        "budget_within_cap",
        api_budget <= cap,
        f"budget {api_budget} ≤ {mode} 上限 {cap}"
        if api_budget <= cap
        else f"budget {api_budget} 超过 {mode} 上限 {cap}，改 formal 或降预算",
    )
    add(
        "keyword_split",
        len(keywords) >= 1,
        f"{len(keywords)} 个关键词将均分额度"
        if keywords
        else "无关键词列表（仅本地时可过）",
    )
    add(
        "local_first",
        reuse_local or api_budget == 0,
        "reuse_local=True 或纯本地" if (reuse_local or api_budget == 0) else "未优先本地",
    )
    add(
        "species_anchor",
        bool(species_id) or mode == "test",
        f"species={species_id or '（测试可后定）'}",
    )

    # 若要花钱且关键词为空 → 不过
    if api_budget > 0 and not keywords and not product_id:
        checks.append({
            "id": "spend_requires_target",
            "ok": False,
            "detail": "花钱拉数必须指定产品或关键词",
        })

    passed = all(c["ok"] for c in checks)
    return {
        "passed": passed,
        "mode": mode,
        "api_budget": api_budget,
        "cap": cap,
        "checks": checks,
        "exclude_count": len(exclude_keywords(cfg)),
    }


def assert_gate_or_exit(result: dict) -> None:
    print("采集闸门:")
    for c in result["checks"]:
        mark = "✓" if c["ok"] else "✗"
        print(f"  {mark} {c['id']}: {c['detail']}")
    if not result["passed"]:
        print("\n未过闸 — 禁止打满 API 预算。修好后再跑。")
        sys.exit(2)
    print("\n已过闸。")


def main(argv=None):
    p = argparse.ArgumentParser(description="采购折叠 · 采集闸门")
    p.add_argument("--mode", choices=["test", "formal"], default="test")
    p.add_argument("--api-budget", type=int, default=200)
    p.add_argument("--keywords", default="", help="逗号分隔")
    p.add_argument("--product", default="")
    p.add_argument("--species", default="")
    p.add_argument("--no-local", action="store_true")
    args = p.parse_args(argv)
    kws = [x.strip() for x in args.keywords.split(",") if x.strip()]
    result = check_gate(
        mode=args.mode,
        api_budget=args.api_budget,
        keywords=kws,
        reuse_local=not args.no_local,
        species_id=args.species,
        product_id=args.product,
    )
    assert_gate_or_exit(result)


if __name__ == "__main__":
    main()
