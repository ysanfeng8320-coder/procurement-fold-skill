#!/usr/bin/env python3
"""Train(2025) → Predict(2026) → Validate(2026 actual) — three panels, one page.

Critical rule: 2026 prediction uses ONLY 2025-trained logic (no peeking at 2026).
2026 actuals appear only in Panel 3 for validation.
Money unit: 千元.
"""
from __future__ import annotations

import json
import os
import sys
from collections import Counter, defaultdict
from datetime import datetime
from statistics import median
from typing import Dict, List, Optional, Tuple

KG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO_DIR = os.path.dirname(KG_DIR)
if KG_DIR not in sys.path:
    sys.path.insert(0, KG_DIR)

# Reuse event loader from year_curve_forecast
from fold.year_curve_forecast import (
    PRODUCT_IDS,
    SPECIES_IDS,
    SPECIES_NAME,
    DEFAULT_UNIT_QIAN,
    load_all_events,
    price_tier,
    wan_to_qian,
)

FOCUS_PRODUCTS = ["binding_machine", "shredder", "copier", "seal_control"]


def split_year(events: List[dict], product_id: str):
    e25 = [
        e for e in events
        if e.get("product_id") == product_id
        and (e.get("source") == "volume_2025" or e.get("year") == 2025)
    ]
    e26 = [
        e for e in events
        if e.get("product_id") == product_id and e.get("year") == 2026
    ]
    return e25, e26


def monthly_agg(events: List[dict]) -> Dict[int, dict]:
    by = {m: {"deals": 0, "qty": 0, "value_qian": 0.0, "units": []} for m in range(1, 13)}
    for e in events:
        m = e.get("month")
        if not m:
            continue
        by[m]["deals"] += 1
        by[m]["qty"] += e["qty"]
        by[m]["value_qian"] += e.get("money_qian") or 0
        if e.get("unit_qian"):
            by[m]["units"].append(e["unit_qian"])
    out = {}
    prev = None
    for m in range(1, 13):
        units = by[m]["units"]
        qty = by[m]["qty"]
        growth = None if prev in (None, 0) else round((qty - prev) / prev * 100, 1)
        out[m] = {
            "deals": by[m]["deals"],
            "qty": qty,
            "value_qian": round(by[m]["value_qian"], 1),
            "unit_p50_qian": round(median(units), 2) if units else None,
            "mom_growth_pct": growth,
        }
        prev = qty
    return out


def species_agg(events: List[dict]) -> List[dict]:
    rows = []
    for sid in SPECIES_IDS + ["other"]:
        subset = [e for e in events if e.get("species_id") == sid]
        if not subset:
            continue
        units = [e["unit_qian"] for e in subset if e.get("unit_qian")]
        tiers = Counter(e.get("price_tier") or "金额未知" for e in subset)
        qty = sum(e["qty"] for e in subset)
        rows.append({
            "species_id": sid,
            "species": SPECIES_NAME[sid],
            "deals": len(subset),
            "qty": qty,
            "share_pct": 0.0,
            "value_qian": round(sum(e.get("money_qian") or 0 for e in subset), 1),
            "unit_p50_qian": round(median(units), 2) if units else DEFAULT_UNIT_QIAN.get(subset[0]["product_id"], {}).get(sid, 5.0),
            "main_tier": max(tiers.items(), key=lambda x: x[1])[0] if tiers else "金额未知",
        })
    total_qty = sum(r["qty"] for r in rows) or 1
    for r in rows:
        r["share_pct"] = round(100 * r["qty"] / total_qty, 1)
    rows.sort(key=lambda x: -x["qty"])
    return rows


def train_model(e25: List[dict], product_id: str) -> dict:
    """Pure 2025 training artifacts."""
    monthly = monthly_agg(e25)
    total_qty = sum(monthly[m]["qty"] for m in range(1, 13)) or 1
    total_val = sum(monthly[m]["value_qian"] for m in range(1, 13))
    shares = {m: round(monthly[m]["qty"] / total_qty, 4) for m in range(1, 13)}
    # season index vs flat
    avg = total_qty / 12.0
    season_index = {m: round(monthly[m]["qty"] / avg, 3) if avg else 0 for m in range(1, 13)}
    peak = max(range(1, 13), key=lambda m: monthly[m]["qty"])
    species = species_agg(e25)
    units_all = [e["unit_qian"] for e in e25 if e.get("unit_qian")]
    tier_dist = Counter(e.get("price_tier") or "金额未知" for e in e25)
    return {
        "product_id": product_id,
        "n_events": len(e25),
        "total_qty": total_qty if total_qty != 1 or sum(monthly[m]["qty"] for m in range(1, 13)) else 0,
        "total_value_qian": round(total_val, 1),
        "monthly": {str(m): monthly[m] for m in range(1, 13)},
        "share": {str(m): shares[m] for m in range(1, 13)},
        "season_index": {str(m): season_index[m] for m in range(1, 13)},
        "peak_month": peak,
        "species": species,
        "unit_p50_qian": round(median(units_all), 2) if units_all else DEFAULT_UNIT_QIAN.get(product_id, {}).get("other", 5.0),
        "tier_dist": dict(tier_dist),
        "push_months": sorted(
            [m for m in range(1, 13) if season_index[m] >= 1.0],
            key=lambda m: -season_index[m],
        )[:3] or [peak],
    }


def predict_2026(model: dict) -> dict:
    """2026 prediction from 2025 model ONLY."""
    total = model["total_qty"] or 1
    unit = model["unit_p50_qian"]
    months = {}
    for m in range(1, 13):
        share = model["share"][str(m)]
        qty = int(round(total * share))
        months[m] = {
            "pred_qty": qty,
            "pred_share_pct": round(share * 100, 2),
            "pred_value_qian": round(qty * unit, 1),
            "season_index": model["season_index"][str(m)],
        }
    species_pred = []
    for s in model["species"]:
        pq = int(round(total * s["share_pct"] / 100))
        species_pred.append({
            "species": s["species"],
            "species_id": s["species_id"],
            "pred_qty": pq,
            "pred_share_pct": s["share_pct"],
            "recommend_unit_qian": s["unit_p50_qian"],
            "recommend_price_range_qian": f"{s['unit_p50_qian'] * 0.85:.1f}–{s['unit_p50_qian'] * 1.15:.1f}",
            "recommend_tier": s["main_tier"],
            "pred_value_qian": round(pq * s["unit_p50_qian"], 1),
        })
    return {
        "scale_note": "绝对台数按「与2025采样强度相当」外推：pred_qty = 2025总台数 × 2025月份额",
        "pred_peak_month": model["peak_month"],
        "pred_push_months": model["push_months"],
        "pred_unit_qian": unit,
        "pred_year_qty": total,
        "pred_year_value_qian": round(total * unit, 1),
        "months": {str(m): months[m] for m in range(1, 13)},
        "species": species_pred,
    }


def validate(pred: dict, e26: List[dict], model: dict) -> dict:
    """Compare 2026 prediction vs 2026 actual (validation only)."""
    actual_m = monthly_agg(e26)
    actual_total = sum(actual_m[m]["qty"] for m in range(1, 13))
    overlap = [m for m in range(1, 13) if actual_m[m]["qty"] > 0]
    # shares among overlap months only (fair shape test)
    pred_overlap_sum = sum(pred["months"][str(m)]["pred_qty"] for m in overlap) or 1
    act_overlap_sum = sum(actual_m[m]["qty"] for m in overlap) or 1

    rows = []
    abs_errors = []
    share_errors = []
    for m in range(1, 13):
        p = pred["months"][str(m)]
        a_qty = actual_m[m]["qty"]
        has_actual = a_qty > 0
        # calibrated pred on overlap: redistribute pred mass to match actual total on overlap
        if m in overlap:
            p_share_o = p["pred_qty"] / pred_overlap_sum
            a_share_o = a_qty / act_overlap_sum
            p_cal = int(round(act_overlap_sum * p_share_o))
            err = a_qty - p_cal
            err_pct = round(abs(err) / a_qty * 100, 1) if a_qty else None
            abs_errors.append(abs(err))
            share_errors.append(abs(p_share_o - a_share_o))
        else:
            p_share_o = None
            a_share_o = None
            p_cal = None
            err = None
            err_pct = None
        rows.append({
            "month": m,
            "pred_qty_raw": p["pred_qty"],
            "pred_share_pct": p["pred_share_pct"],
            "pred_qty_calibrated": p_cal,
            "actual_qty": a_qty if has_actual else None,
            "actual_share_overlap_pct": round(a_share_o * 100, 2) if a_share_o is not None else None,
            "pred_share_overlap_pct": round(p_share_o * 100, 2) if p_share_o is not None else None,
            "error_qty": err,
            "error_pct": err_pct,
            "in_overlap": m in overlap,
            "hit_band": (
                "准"
                if err_pct is not None and err_pct <= 30
                else ("偏差" if err_pct is not None and err_pct <= 60 else ("偏离" if err_pct is not None else "无实测"))
            ),
        })

    actual_peak = max(overlap, key=lambda m: actual_m[m]["qty"]) if overlap else None
    pred_peak = pred["pred_peak_month"]
    peak_hit = actual_peak == pred_peak if actual_peak else None

    # Did predicted push months actually rank high in 2026?
    if overlap:
        ranked_actual = sorted(overlap, key=lambda m: -actual_m[m]["qty"])
        push = pred["pred_push_months"]
        push_in_top = [m for m in push if m in ranked_actual[: max(3, len(ranked_actual))]]
    else:
        ranked_actual = []
        push_in_top = []

    mape = round(sum(r["error_pct"] for r in rows if r["error_pct"] is not None) / max(len(overlap), 1), 1) if overlap else None
    mean_share_err = round(sum(share_errors) / len(share_errors) * 100, 2) if share_errors else None

    # species validation
    act_species = species_agg(e26)
    act_map = {s["species_id"]: s for s in act_species}
    sp_rows = []
    for s in pred["species"]:
        a = act_map.get(s["species_id"])
        sp_rows.append({
            "species": s["species"],
            "pred_share_pct": s["pred_share_pct"],
            "actual_share_pct": a["share_pct"] if a else 0,
            "pred_unit_qian": s["recommend_unit_qian"],
            "actual_unit_qian": a["unit_p50_qian"] if a else None,
            "actual_qty": a["qty"] if a else 0,
        })

    verdict_bits = []
    if peak_hit is True:
        verdict_bits.append(f"峰值月命中：预测{pred_peak}月=实测{actual_peak}月")
    elif peak_hit is False:
        verdict_bits.append(f"峰值月未命中：预测{pred_peak}月，实测{actual_peak}月")
    if mape is not None:
        if mape <= 35:
            verdict_bits.append(f"重叠月校准台数 MAPE={mape}% → 月分布逻辑可用")
        elif mape <= 60:
            verdict_bits.append(f"重叠月校准台数 MAPE={mape}% → 方向对、量级需校准")
        else:
            verdict_bits.append(f"重叠月校准台数 MAPE={mape}% → 2025月分布外推偏差大，需补训")
    if not overlap:
        verdict_bits.append("2026重叠月无实测，无法验证")

    return {
        "overlap_months": overlap,
        "actual_total_qty": actual_total,
        "actual_peak_month": actual_peak,
        "pred_peak_month": pred_peak,
        "peak_month_hit": peak_hit,
        "mape_calibrated_pct": mape,
        "mean_abs_share_err_pct": mean_share_err,
        "push_months_predicted": pred["pred_push_months"],
        "push_months_hit_in_actual_top": push_in_top,
        "month_rows": rows,
        "species_rows": sp_rows,
        "verdict": "；".join(verdict_bits) if verdict_bits else "样本不足",
        "actual_monthly": {str(m): actual_m[m] for m in range(1, 13)},
    }


def build_product_bundle(events: List[dict], product_id: str, display_name: str) -> dict:
    e25, e26 = split_year(events, product_id)
    model = train_model(e25, product_id)
    # fix total_qty edge
    model["total_qty"] = sum(int(model["monthly"][str(m)]["qty"]) for m in range(1, 13))
    pred = predict_2026(model)
    val = validate(pred, e26, model)
    return {
        "product_id": product_id,
        "display_name": display_name,
        "train": model,
        "predict": pred,
        "validate": val,
        "n_2025": len(e25),
        "n_2026": len(e26),
    }


def write_html(path: str, bundles: List[dict], focus_id: str):
    focus = next(b for b in bundles if b["product_id"] == focus_id)
    # also keep others for switcher data
    all_json = json.dumps({b["product_id"]: b for b in bundles}, ensure_ascii=False, default=str)

    t = focus["train"]
    p = focus["predict"]
    v = focus["validate"]
    name = focus["display_name"]

    months = [f"{m}月" for m in range(1, 13)]
    qty25 = [t["monthly"][str(m)]["qty"] for m in range(1, 13)]
    share25 = [round(t["share"][str(m)] * 100, 2) for m in range(1, 13)]
    growth25 = [t["monthly"][str(m)]["mom_growth_pct"] or 0 for m in range(1, 13)]
    unit25 = [t["monthly"][str(m)]["unit_p50_qian"] or 0 for m in range(1, 13)]
    val25 = [t["monthly"][str(m)]["value_qian"] for m in range(1, 13)]
    season = [t["season_index"][str(m)] for m in range(1, 13)]

    pred_qty = [p["months"][str(m)]["pred_qty"] for m in range(1, 13)]
    pred_share = [p["months"][str(m)]["pred_share_pct"] for m in range(1, 13)]
    pred_val = [p["months"][str(m)]["pred_value_qian"] for m in range(1, 13)]

    act_qty = [v["actual_monthly"][str(m)]["qty"] for m in range(1, 13)]
    cal_qty = [r["pred_qty_calibrated"] if r["pred_qty_calibrated"] is not None else None for r in v["month_rows"]]
    # chart.js needs numbers; use 0 for null but mark
    cal_qty_chart = [c if c is not None else 0 for c in cal_qty]

    train_rows = "".join(
        f"<tr><td>{m}月</td><td class='num'>{t['monthly'][str(m)]['qty']}</td>"
        f"<td class='num'>{round(t['share'][str(m)]*100,2)}</td>"
        f"<td class='num'>{t['season_index'][str(m)]}</td>"
        f"<td class='num'>{t['monthly'][str(m)]['value_qian']}</td>"
        f"<td class='num'>{t['monthly'][str(m)]['unit_p50_qian'] if t['monthly'][str(m)]['unit_p50_qian'] is not None else '-'}</td>"
        f"<td class='num'>{t['monthly'][str(m)]['mom_growth_pct'] if t['monthly'][str(m)]['mom_growth_pct'] is not None else '-'}</td></tr>"
        for m in range(1, 13)
    )
    sp_train = "".join(
        f"<tr><td>{s['species']}</td><td class='num'>{s['qty']}</td><td class='num'>{s['share_pct']}%</td>"
        f"<td class='num'>{s['unit_p50_qian']}</td><td>{s['main_tier']}</td><td class='num'>{s['value_qian']}</td></tr>"
        for s in t["species"]
    )
    pred_rows = "".join(
        f"<tr><td>{m}月</td><td class='num'>{p['months'][str(m)]['pred_qty']}</td>"
        f"<td class='num'>{p['months'][str(m)]['pred_share_pct']}</td>"
        f"<td class='num'>{p['months'][str(m)]['pred_value_qian']}</td>"
        f"<td class='num'>{p['months'][str(m)]['season_index']}</td></tr>"
        for m in range(1, 13)
    )
    sp_pred = "".join(
        f"<tr><td>{s['species']}</td><td class='num'>{s['pred_qty']}</td><td class='num'>{s['pred_share_pct']}%</td>"
        f"<td>{s['recommend_price_range_qian']}</td><td>{s['recommend_tier']}</td>"
        f"<td class='num'>{s['pred_value_qian']}</td></tr>"
        for s in p["species"]
    )
    val_rows = "".join(
        f"<tr class='{'overlap' if r['in_overlap'] else ''}'>"
        f"<td>{r['month']}月</td>"
        f"<td class='num'>{r['pred_qty_raw']}</td>"
        f"<td class='num'>{r['pred_qty_calibrated'] if r['pred_qty_calibrated'] is not None else '-'}</td>"
        f"<td class='num'>{r['actual_qty'] if r['actual_qty'] is not None else '-'}</td>"
        f"<td class='num'>{r['pred_share_overlap_pct'] if r['pred_share_overlap_pct'] is not None else '-'}</td>"
        f"<td class='num'>{r['actual_share_overlap_pct'] if r['actual_share_overlap_pct'] is not None else '-'}</td>"
        f"<td class='num'>{r['error_pct'] if r['error_pct'] is not None else '-'}</td>"
        f"<td>{r['hit_band']}</td></tr>"
        for r in v["month_rows"]
    )

    tabs = "".join(
        f"<button class='tab {'active' if b['product_id']==focus_id else ''}' data-pid='{b['product_id']}'>{b['display_name']}</button>"
        for b in bundles
    )
    verdict_cls = (
        "ok"
        if (v.get("mape_calibrated_pct") is not None and v["mape_calibrated_pct"] <= 35)
        else "warn"
    )

    html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>训练→预测→验证 · {name}</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<style>
:root{{--ink:#1a1f2e;--muted:#5c6578;--line:#e2e6ef;--bg:#f2f0ea;--paper:#fffcf7;--a:#0d5c63;--b:#8a4b08;--c:#3d4f7c}}
*{{box-sizing:border-box}}
body{{margin:0;font-family:"PingFang SC","Noto Sans SC",sans-serif;color:var(--ink);background:var(--bg)}}
.wrap{{max-width:1200px;margin:0 auto;padding:28px 16px 72px}}
h1{{font-family:"Songti SC",serif;font-size:1.85rem;margin:0 0 8px}}
.sub{{color:var(--muted);font-size:13px;margin-bottom:14px}}
.tabs{{display:flex;flex-wrap:wrap;gap:8px;margin:10px 0 18px}}
.tab{{border:1px solid var(--line);background:var(--paper);padding:8px 12px;border-radius:4px;cursor:pointer;font-size:13px}}
.tab.active{{background:var(--a);color:#fff;border-color:var(--a)}}
.flow{{display:grid;grid-template-columns:1fr auto 1fr auto 1fr;gap:8px;align-items:center;margin:12px 0 20px;font-size:13px}}
.flow .box{{background:var(--paper);border:1px solid var(--line);padding:10px;border-radius:4px;text-align:center}}
.flow .arrow{{color:var(--muted)}}
.panel{{background:var(--paper);border:1px solid var(--line);border-radius:4px;padding:16px 16px 20px;margin:0 0 18px}}
.panel h2{{font-family:"Songti SC",serif;font-size:1.2rem;margin:0 0 6px;padding-bottom:8px;border-bottom:2px solid var(--a)}}
.panel.p2 h2{{border-color:var(--b)}}
.panel.p3 h2{{border-color:var(--c)}}
.panel .desc{{font-size:13px;color:var(--muted);margin:0 0 12px}}
.stats{{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px;margin:8px 0 12px}}
.stat{{border:1px solid var(--line);padding:8px;border-radius:4px}}
.stat b{{display:block;font-size:1.2rem}}
.stat span{{font-size:11px;color:var(--muted)}}
.charts{{display:grid;gap:12px}}
@media(min-width:960px){{.charts.two{{grid-template-columns:1fr 1fr}}}}
.chart-box{{border:1px solid var(--line);padding:10px;border-radius:4px}}
.chart-box h3{{margin:0 0 8px;font-size:13px;color:var(--a)}}
table{{width:100%;border-collapse:collapse;font-size:12px}}
th,td{{padding:6px 8px;border-bottom:1px solid var(--line);text-align:left;white-space:nowrap}}
th{{background:#eef2f0;color:var(--muted);font-size:11px}}
.num{{text-align:right;font-variant-numeric:tabular-nums}}
tr.overlap{{background:#f3faf7}}
.callout{{border-left:3px solid var(--c);background:#eef1f8;padding:10px 12px;margin:10px 0;font-size:13px}}
.callout.ok{{border-color:#1b5e3b;background:#e3f2ea}}
.callout.warn{{border-color:#8a4b08;background:#f8ead8}}
.scroll{{overflow-x:auto}}
</style></head><body>
<div class="wrap">
<h1>预测系统 · 三板块同页</h1>
<p class="sub">训练(2025) → 预测(2026，仅用2025逻辑) → 验证(2026实测对照) · 金额单位=<b>千元</b> · 当前单品：<b id="titleName">{name}</b></p>

<div class="tabs" id="tabs">{tabs}</div>

<div class="flow">
  <div class="box"><b>① 2025 训练实绩</b><br/>价格·增长·分布</div>
  <div class="arrow">→</div>
  <div class="box"><b>② 2026 预测</b><br/>不偷看实测</div>
  <div class="arrow">→</div>
  <div class="box"><b>③ 2026 验证</b><br/>预测 vs 实测</div>
</div>

<!-- PANEL 1 -->
<section class="panel p1" id="panel1">
  <h2>① 2025 训练实绩</h2>
  <p class="desc">用这一年学：哪个月旺、什么价位、哪个系统份额大、环比怎么走。这是训练样本，不是预测。</p>
  <div class="stats">
    <div class="stat"><b id="tQty">{t['total_qty']}</b><span>年台数</span></div>
    <div class="stat"><b id="tVal">{t['total_value_qian']}</b><span>采购额(千元)</span></div>
    <div class="stat"><b id="tPeak">{t['peak_month']}月</b><span>峰值月</span></div>
    <div class="stat"><b id="tUnit">{t['unit_p50_qian']}</b><span>单价中位(千元/台)</span></div>
    <div class="stat"><b id="tPush">{'、'.join(str(m)+'月' for m in t['push_months'])}</b><span>主推月(季节指数≥1)</span></div>
  </div>
  <div class="charts two">
    <div class="chart-box"><h3>月度台数与季节指数</h3><canvas id="c1a" height="200"></canvas></div>
    <div class="chart-box"><h3>月度分布率(%) 与 环比增长(%)</h3><canvas id="c1b" height="200"></canvas></div>
    <div class="chart-box"><h3>采购额(千元)</h3><canvas id="c1c" height="200"></canvas></div>
    <div class="chart-box"><h3>单价中位(千元/台)</h3><canvas id="c1d" height="200"></canvas></div>
  </div>
  <h3 style="font-size:13px;margin:14px 0 6px">1–12月明细</h3>
  <div class="scroll"><table>
    <thead><tr><th>月</th><th>台数</th><th>分布率%</th><th>季节指数</th><th>采购额(千)</th><th>单价中位(千)</th><th>环比%</th></tr></thead>
    <tbody id="trainMonthBody">{train_rows}</tbody>
  </table></div>
  <h3 style="font-size:13px;margin:14px 0 6px">系统分布与价位</h3>
  <div class="scroll"><table>
    <thead><tr><th>系统</th><th>台数</th><th>份额</th><th>单价中位(千)</th><th>主价位带</th><th>采购额(千)</th></tr></thead>
    <tbody id="trainSpBody">{sp_train}</tbody>
  </table></div>
</section>

<!-- PANEL 2 -->
<section class="panel p2" id="panel2">
  <h2>② 2026 预测（纯2025逻辑）</h2>
  <p class="desc">这里<strong>不使用任何2026实测</strong>。预测台数 = 2025总台数 × 2025月份额；价位/系统按2025学到的中位与份额外推。</p>
  <div class="callout">主推建议：优先打 <b id="pPush">{'、'.join(str(m)+'月' for m in p['pred_push_months'])}</b>（由2025季节指数推出）。峰值月预测为 <b id="pPeak">{p['pred_peak_month']}月</b>。</div>
  <div class="stats">
    <div class="stat"><b id="pQty">{p['pred_year_qty']}</b><span>预测年台数</span></div>
    <div class="stat"><b id="pVal">{p['pred_year_value_qian']}</b><span>预测采购额(千元)</span></div>
    <div class="stat"><b id="pUnit">{p['pred_unit_qian']}</b><span>预测单价(千元/台)</span></div>
  </div>
  <div class="charts two">
    <div class="chart-box"><h3>2026预测台数（1–12月）</h3><canvas id="c2a" height="200"></canvas></div>
    <div class="chart-box"><h3>2026预测分布率(%)</h3><canvas id="c2b" height="200"></canvas></div>
  </div>
  <div class="scroll"><table>
    <thead><tr><th>月</th><th>预测台数</th><th>预测分布率%</th><th>预测采购额(千)</th><th>季节指数</th></tr></thead>
    <tbody id="predMonthBody">{pred_rows}</tbody>
  </table></div>
  <h3 style="font-size:13px;margin:14px 0 6px">预测：去哪个系统、什么价</h3>
  <div class="scroll"><table>
    <thead><tr><th>系统</th><th>预测台数</th><th>份额</th><th>建议单价(千)</th><th>价位带</th><th>预测采购额(千)</th></tr></thead>
    <tbody id="predSpBody">{sp_pred}</tbody>
  </table></div>
</section>

<!-- PANEL 3 -->
<section class="panel p3" id="panel3">
  <h2>③ 2026 验证结果（预测 vs 实测）</h2>
  <p class="desc">用2026真实采购检验①里学到的逻辑对不对。重叠月（有实测的月份）上：把预测份额校准到实测总量后再比台数，避免采样强度不同造成的假误差。</p>
  <div class="callout {verdict_cls}" id="verdictBox">
    <b>验证结论：</b><span id="verdictText">{v['verdict']}</span>
  </div>
  <div class="stats">
    <div class="stat"><b id="vPeak">{'命中' if v.get('peak_month_hit') else ('未命中' if v.get('peak_month_hit') is False else '-')}</b><span>峰值月是否命中</span></div>
    <div class="stat"><b id="vMape">{v.get('mape_calibrated_pct') if v.get('mape_calibrated_pct') is not None else '-'}</b><span>重叠月MAPE%</span></div>
    <div class="stat"><b id="vOverlap">{'、'.join(str(m)+'月' for m in v.get('overlap_months') or []) or '无'}</b><span>可验证月份</span></div>
    <div class="stat"><b id="vAct">{v.get('actual_total_qty') or 0}</b><span>2026实测总台数</span></div>
  </div>
  <div class="charts two">
    <div class="chart-box"><h3>重叠月：校准预测台数 vs 实测台数</h3><canvas id="c3a" height="210"></canvas></div>
    <div class="chart-box"><h3>全年：原始预测台数 vs 实测台数</h3><canvas id="c3b" height="210"></canvas></div>
  </div>
  <div class="scroll"><table>
    <thead><tr>
      <th>月</th><th>原始预测台数</th><th>校准预测台数</th><th>实测台数</th>
      <th>预测份额%(重叠内)</th><th>实测份额%(重叠内)</th><th>误差%</th><th>判定</th>
    </tr></thead>
    <tbody id="valMonthBody">{val_rows}</tbody>
  </table></div>
  <p style="font-size:12px;color:#5c6578;margin-top:8px">绿色行=有2026实测的重叠月。若你在①里看到7月旺，②就会主推7月；③检查2026年7月实测是否也高。</p>
</section>

<p class="sub">生成于 {datetime.now().isoformat(timespec='seconds')} · 预测不偷看2026 · 金额=千元</p>
</div>

<script>
const ALL = {all_json};
const months = {json.dumps(months, ensure_ascii=False)};
let charts = [];

function destroyCharts(){{ charts.forEach(c=>c.destroy()); charts=[]; }}
function line(id, datasets, yTitle){{
  const c = new Chart(document.getElementById(id), {{
    type:'line',
    data:{{labels:months, datasets}},
    options:{{
      plugins:{{legend:{{position:'bottom'}}}},
      scales:{{
        y:{{title:{{display:true,text:yTitle}}, beginAtZero:true}},
        x:{{title:{{display:true,text:'月份'}}}}
      }}
    }}
  }});
  charts.push(c);
}}

function render(pid){{
  const b = ALL[pid];
  const t=b.train, p=b.predict, v=b.validate;
  document.getElementById('titleName').textContent = b.display_name;
  document.querySelectorAll('.tab').forEach(el=>el.classList.toggle('active', el.dataset.pid===pid));

  // stats
  document.getElementById('tQty').textContent = t.total_qty;
  document.getElementById('tVal').textContent = t.total_value_qian;
  document.getElementById('tPeak').textContent = t.peak_month + '月';
  document.getElementById('tUnit').textContent = t.unit_p50_qian;
  document.getElementById('tPush').textContent = (t.push_months||[]).map(m=>m+'月').join('、');
  document.getElementById('pPush').textContent = (p.pred_push_months||[]).map(m=>m+'月').join('、');
  document.getElementById('pPeak').textContent = p.pred_peak_month + '月';
  document.getElementById('pQty').textContent = p.pred_year_qty;
  document.getElementById('pVal').textContent = p.pred_year_value_qian;
  document.getElementById('pUnit').textContent = p.pred_unit_qian;
  document.getElementById('verdictText').textContent = v.verdict;
  document.getElementById('vPeak').textContent = v.peak_month_hit===true?'命中':(v.peak_month_hit===false?'未命中':'-');
  document.getElementById('vMape').textContent = v.mape_calibrated_pct!=null?v.mape_calibrated_pct:'-';
  document.getElementById('vOverlap').textContent = (v.overlap_months||[]).map(m=>m+'月').join('、')||'无';
  document.getElementById('vAct').textContent = v.actual_total_qty||0;

  // tables
  let tr='';
  for(let m=1;m<=12;m++){{
    const cell=t.monthly[String(m)];
    tr += `<tr><td>${{m}}月</td><td class="num">${{cell.qty}}</td><td class="num">${{(t.share[String(m)]*100).toFixed(2)}}</td><td class="num">${{t.season_index[String(m)]}}</td><td class="num">${{cell.value_qian}}</td><td class="num">${{cell.unit_p50_qian??'-'}}</td><td class="num">${{cell.mom_growth_pct??'-'}}</td></tr>`;
  }}
  document.getElementById('trainMonthBody').innerHTML=tr;
  document.getElementById('trainSpBody').innerHTML=(t.species||[]).map(s=>`<tr><td>${{s.species}}</td><td class="num">${{s.qty}}</td><td class="num">${{s.share_pct}}%</td><td class="num">${{s.unit_p50_qian}}</td><td>${{s.main_tier}}</td><td class="num">${{s.value_qian}}</td></tr>`).join('');
  document.getElementById('predMonthBody').innerHTML=Array.from({{length:12}},(_,i)=>i+1).map(m=>{{
    const cell=p.months[String(m)];
    return `<tr><td>${{m}}月</td><td class="num">${{cell.pred_qty}}</td><td class="num">${{cell.pred_share_pct}}</td><td class="num">${{cell.pred_value_qian}}</td><td class="num">${{cell.season_index}}</td></tr>`;
  }}).join('');
  document.getElementById('predSpBody').innerHTML=(p.species||[]).map(s=>`<tr><td>${{s.species}}</td><td class="num">${{s.pred_qty}}</td><td class="num">${{s.pred_share_pct}}%</td><td>${{s.recommend_price_range_qian}}</td><td>${{s.recommend_tier}}</td><td class="num">${{s.pred_value_qian}}</td></tr>`).join('');
  document.getElementById('valMonthBody').innerHTML=(v.month_rows||[]).map(r=>`<tr class="${{r.in_overlap?'overlap':''}}"><td>${{r.month}}月</td><td class="num">${{r.pred_qty_raw}}</td><td class="num">${{r.pred_qty_calibrated??'-'}}</td><td class="num">${{r.actual_qty??'-'}}</td><td class="num">${{r.pred_share_overlap_pct??'-'}}</td><td class="num">${{r.actual_share_overlap_pct??'-'}}</td><td class="num">${{r.error_pct??'-'}}</td><td>${{r.hit_band}}</td></tr>`).join('');

  destroyCharts();
  const qty25=Array.from({{length:12}},(_,i)=>t.monthly[String(i+1)].qty);
  const season=Array.from({{length:12}},(_,i)=>t.season_index[String(i+1)]);
  const share25=Array.from({{length:12}},(_,i)=>+(t.share[String(i+1)]*100).toFixed(2));
  const growth25=Array.from({{length:12}},(_,i)=>t.monthly[String(i+1)].mom_growth_pct||0);
  const val25=Array.from({{length:12}},(_,i)=>t.monthly[String(i+1)].value_qian);
  const unit25=Array.from({{length:12}},(_,i)=>t.monthly[String(i+1)].unit_p50_qian||0);
  const predQty=Array.from({{length:12}},(_,i)=>p.months[String(i+1)].pred_qty);
  const predShare=Array.from({{length:12}},(_,i)=>p.months[String(i+1)].pred_share_pct);
  const actQty=Array.from({{length:12}},(_,i)=>v.actual_monthly[String(i+1)].qty);
  const calQty=(v.month_rows||[]).map(r=>r.pred_qty_calibrated??null);

  line('c1a',[
    {{label:'台数',data:qty25,borderColor:'#0d5c63',tension:.25,pointRadius:3}},
    {{label:'季节指数',data:season,borderColor:'#8a4b08',borderDash:[4,3],tension:.25}}
  ],'台数 / 指数');
  line('c1b',[
    {{label:'分布率%',data:share25,borderColor:'#0d5c63',tension:.25}},
    {{label:'环比%',data:growth25,borderColor:'#8a4b08',borderDash:[4,3],tension:.25}}
  ],'%');
  line('c1c',[{{label:'采购额(千元)',data:val25,borderColor:'#3d4f7c',tension:.25}}],'千元');
  line('c1d',[{{label:'单价中位(千元/台)',data:unit25,borderColor:'#1b5e3b',tension:.25}}],'千元/台');
  line('c2a',[{{label:'预测台数',data:predQty,borderColor:'#8a4b08',tension:.25,pointRadius:3}}],'台数');
  line('c2b',[{{label:'预测分布率%',data:predShare,borderColor:'#8a4b08',tension:.25}}],'%');
  line('c3a',[
    {{label:'校准预测台数',data:calQty.map(x=>x==null?0:x),borderColor:'#3d4f7c',tension:.25}},
    {{label:'实测台数',data:actQty,borderColor:'#0d5c63',tension:.25}}
  ],'台数');
  line('c3b',[
    {{label:'原始预测台数',data:predQty,borderColor:'#8a4b08',borderDash:[4,3],tension:.25}},
    {{label:'实测台数',data:actQty,borderColor:'#0d5c63',tension:.25}}
  ],'台数');
}}

document.getElementById('tabs').addEventListener('click', e=>{{
  const btn=e.target.closest('.tab'); if(!btn) return; render(btn.dataset.pid);
}});
render('{focus_id}');
</script>
</body></html>"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)


def main():
    events = load_all_events()
    names = {
        "binding_machine": "装订机",
        "shredder": "碎纸机",
        "copier": "复印机",
        "seal_control": "印控仪",
    }
    bundles = [build_product_bundle(events, pid, names[pid]) for pid in FOCUS_PRODUCTS]

    # Default to 装订机: 2025 month coverage widest for training narrative
    focus = "binding_machine"
    if not any(b["product_id"] == focus for b in bundles):
        focus = sorted(bundles, key=score, reverse=True)[0]["product_id"]

    run_id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_tpv"
    out_dir = os.path.join(REPO_DIR, "fold_runs", run_id)
    os.makedirs(out_dir, exist_ok=True)
    payload = {"focus": focus, "products": {b["product_id"]: b for b in bundles}}
    with open(os.path.join(out_dir, "tpv_result.json"), "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2, default=str)
    html_path = os.path.join(out_dir, "report.html")
    write_html(html_path, bundles, focus)

    for b in bundles:
        v = b["validate"]
        print(
            f"{b['display_name']}: 2025n={b['n_2025']} 2026n={b['n_2026']} "
            f"peak_pred={b['predict']['pred_peak_month']} peak_act={v.get('actual_peak_month')} "
            f"hit={v.get('peak_month_hit')} MAPE={v.get('mape_calibrated_pct')} "
            f"overlap={v.get('overlap_months')} | {v.get('verdict')}"
        )
    print("FOCUS", focus)
    print("DONE", html_path)
    return out_dir, html_path


if __name__ == "__main__":
    main()
