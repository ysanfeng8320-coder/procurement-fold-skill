"""Act: emit actionable leads in action regions from rule cards + structured records."""
from __future__ import annotations

import json
import os
from collections import defaultdict
from typing import Dict, List, Optional, Set

from .pack_loader import ProductPack

STRONG = {"target", "near"}
RELEVANT = {"target", "near", "related"}


def _relevant_evidence(recs: List[dict], limit: int = 3) -> List[dict]:
    """Only title-matched relevant tiers; newest first."""
    pool = [r for r in recs if r.get("hit_tier") in RELEVANT and r.get("matched_keyword")]
    pool = sorted(pool, key=lambda x: x.get("publish_time") or "", reverse=True)
    evidence = []
    for r in pool[:limit]:
        evidence.append({
            "title": r.get("title"),
            "date": r.get("publish_time"),
            "hit_tier": r.get("hit_tier"),
            "matched_keyword": r.get("matched_keyword"),
            "source_id": r.get("source_id"),
        })
    return evidence


def _load_contacts() -> dict:
    path = os.path.join(os.path.dirname(__file__), "..", "data", "contacts.json")
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    return {}


def _is_phone(phone) -> bool:
    try:
        from phone_enricher import is_real_phone
        return is_real_phone(str(phone or ""))
    except Exception:
        return bool(phone and phone not in ("待确认", "待补充", ""))


def _admin_units_for_systems(pack: ProductPack, systems: List[str], regions: List[str]) -> List[dict]:
    """Optional: expand similar_unbought using admin_regions if present."""
    path = os.path.join(os.path.dirname(__file__), "..", "data", "admin_regions.json")
    if not os.path.exists(path):
        return []
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return []

    # Flexible shapes: list of {name, province, system?} or nested
    units = []
    if isinstance(data, list):
        raw = data
    elif isinstance(data, dict):
        raw = data.get("units") or data.get("regions") or []
        if isinstance(raw, dict):
            raw = [{"name": k, **(v if isinstance(v, dict) else {})} for k, v in raw.items()]
    else:
        raw = []

    for u in raw:
        if not isinstance(u, dict):
            continue
        name = u.get("name") or u.get("unit") or ""
        prov = u.get("province") or u.get("region") or ""
        if regions and prov and prov not in regions:
            continue
        # system guess via pack
        from .structure import classify_system
        sys_name = u.get("system") or classify_system(name, name, pack)
        if systems and sys_name not in systems and not u.get("system"):
            # still keep if name matches system keywords
            if sys_name == "其他":
                continue
        units.append({"buyer": name, "region": prov or "", "buyer_system": sys_name})
    return units


def act_leads(
    structured: List[dict],
    rule_cards: List[dict],
    pack: ProductPack,
    action_regions: List[str],
    max_leads: int = 40,
) -> List[dict]:
    contacts = _load_contacts()
    action_recs = [r for r in structured if r.get("region") in action_regions]

    bought_strong: Set[str] = set()
    buyer_recs: Dict[str, List[dict]] = defaultdict(list)
    for r in action_recs:
        b = r.get("buyer")
        if not b:
            continue
        buyer_recs[b].append(r)
        if r.get("hit_tier") in STRONG:
            bought_strong.add(b)

    # systems emphasized by cooccurrence / surge / high_value
    focus_systems: Set[str] = set(pack.high_value_systems or [])
    surge_systems: Set[str] = set()
    matched_rule_ids = []
    for c in rule_cards:
        if c["type"] == "cooccurrence" and "买方系统更可能是" in (c.get("then") or ""):
            # extract 「系统」
            then = c["then"]
            if "「" in then and "」" in then:
                focus_systems.add(then.split("「")[1].split("」")[0])
                matched_rule_ids.append(c["id"])
        if c["type"] == "temporal_surge" and "「" in (c.get("if") or ""):
            part = c["if"].split("「")[1].split("」")[0]
            if part.endswith("系统") or "/" in part:
                surge_systems.add(part)
                focus_systems.add(part)
                matched_rule_ids.append(c["id"])

    gap_rule = next((c["id"] for c in rule_cards if c["id"] == "cooc_assoc_gap"), "cooc_assoc_gap")
    prior_high = [c["id"] for c in rule_cards if c["type"] == "prior" and c.get("confidence") in ("high", "medium")]

    leads: List[dict] = []

    # B: assoc_gap — 标题真实命中 related/near，且近窗内有证据
    for buyer, recs in buyer_recs.items():
        if buyer in bought_strong:
            continue
        if any(r.get("hit_tier") == "target" for r in recs):
            continue
        if not any(r.get("hit_tier") in ("related", "near") and r.get("matched_keyword") for r in recs):
            continue
        evidence = _relevant_evidence(recs, limit=3)
        if not evidence:
            continue
        sys_name = next((r.get("buyer_system") for r in recs if r.get("buyer_system")), "其他")
        phone = contacts.get(buyer)
        actionable = _is_phone(phone)
        priority = "P0" if sys_name in surge_systems else ("P1" if sys_name in focus_systems else "P2")
        leads.append({
            "buyer": buyer,
            "region": recs[0].get("region"),
            "buyer_system": sys_name,
            "lead_type": "assoc_gap",
            "priority": priority,
            "matched_rules": [gap_rule] + prior_high[:2],
            "evidence": evidence,
            "gap_detail": "近三年内有关联/近义公告命中，未见本品 target 强命中",
            "suggested_action": "确认是否仅电子印章/软件；推进硬件印控（盖章机/用印宝/印控台）补缺" + (
                "；优先走集成商/运营商渠道" if not actionable else "；可直联跟进"
            ),
            "actionable": actionable,
            "action_blocker": None if actionable else "无可用电话，建议经集成商或公告附件补全",
            "contact": phone if actionable else None,
        })

    # A: similar_unbought — high value systems seen in action data but not strong-bought
    strong_by_sys = defaultdict(set)
    for b in bought_strong:
        for r in buyer_recs.get(b, []):
            strong_by_sys[r.get("buyer_system")].add(b)

    for sys_name in focus_systems:
        peers = strong_by_sys.get(sys_name) or set()
        if not peers and sys_name not in (pack.high_value_systems or []):
            continue
        for buyer, recs in buyer_recs.items():
            if buyer in bought_strong:
                continue
            if (recs[0].get("buyer_system") or "其他") != sys_name:
                continue
            evidence = _relevant_evidence(recs, limit=3)
            if not evidence:
                continue
            phone = contacts.get(buyer)
            actionable = _is_phone(phone)
            priority = "P0" if sys_name in surge_systems else "P1"
            rules = [rid for rid in matched_rule_ids if sys_name in rid] or prior_high[:2]
            leads.append({
                "buyer": buyer,
                "region": recs[0].get("region"),
                "buyer_system": sys_name,
                "lead_type": "similar_unbought",
                "priority": priority,
                "matched_rules": rules or [f"prior_high_value_{sys_name}"],
                "evidence": evidence,
                "gap_detail": f"属于高价值/规律聚焦系统「{sys_name}」，近三年未见本品 target 强命中"
                + (f"；同系统已购参照 {len(peers)} 家" if peers else ""),
                "suggested_action": "按系统话术拜访/找集成商；对照发现区同系统案例",
                "actionable": actionable,
                "action_blocker": None if actionable else "无可用电话，建议经集成商或公告附件补全",
                "contact": phone if actionable else None,
            })

    # Dedup buyer preferring assoc_gap over similar when both; keep similar-only
    by_buyer = {}
    for lead in leads:
        b = lead["buyer"]
        prev = by_buyer.get(b)
        if not prev:
            by_buyer[b] = lead
            continue
        # merge: if one is gap and one similar, keep gap but note similarity
        if prev["lead_type"] != lead["lead_type"]:
            gap = lead if lead["lead_type"] == "assoc_gap" else prev
            sim = lead if lead["lead_type"] == "similar_unbought" else prev
            gap = dict(gap)
            gap["matched_rules"] = list(dict.fromkeys((gap.get("matched_rules") or []) + (sim.get("matched_rules") or [])))
            gap["gap_detail"] = (gap.get("gap_detail") or "") + "；同时满足结构相似未购"
            if sim.get("priority") == "P0" or gap.get("priority") == "P0":
                gap["priority"] = "P0"
            elif sim.get("priority") == "P1" or gap.get("priority") == "P1":
                gap["priority"] = "P1"
            by_buyer[b] = gap
        else:
            # keep higher priority
            rank = {"P0": 0, "P1": 1, "P2": 2}
            if rank.get(lead["priority"], 9) < rank.get(prev["priority"], 9):
                by_buyer[b] = lead

    deduped = list(by_buyer.values())

    # similar_unbought from high-value systems: buyers with ONLY confuse/none won't be in corpus.
    # Use strong-hit systems' sibling buyers that appear in any action record without target.
    # Additionally: promote high-value-system assoc_gap already handled above.
    # Build A from action buyers in high_value systems with no strong hit and no related
    # (e.g. near-only already in B). Pure A: appear via keyword_hint files but tier none upgraded.
    existing = {l["buyer"] for l in deduped}
    for buyer, recs in buyer_recs.items():
        if buyer in bought_strong or buyer in existing:
            continue
        sys_name = recs[0].get("buyer_system") or "其他"
        if sys_name not in focus_systems:
            continue
        tiers = {r.get("hit_tier") for r in recs}
        if "related" in tiers or "near" in tiers:
            continue  # should have been B
        evidence = _relevant_evidence(recs, limit=3)
        if not evidence:
            continue
        phone = contacts.get(buyer)
        actionable = _is_phone(phone)
        deduped.append({
            "buyer": buyer,
            "region": recs[0].get("region"),
            "buyer_system": sys_name,
            "lead_type": "similar_unbought",
            "priority": "P0" if sys_name in surge_systems else "P1",
            "matched_rules": prior_high[:2] or [f"high_value_{sys_name}"],
            "evidence": evidence,
            "gap_detail": f"高价值系统「{sys_name}」结构相似，近三年未见本品强命中",
            "suggested_action": "按系统话术拜访/找集成商；对照发现区同系统案例",
            "actionable": actionable,
            "action_blocker": None if actionable else "无可用电话，建议经集成商或公告附件补全",
            "contact": phone if actionable else None,
        })

    priority_rank = {"P0": 0, "P1": 1, "P2": 2}
    deduped.sort(key=lambda x: (priority_rank.get(x["priority"], 9), 0 if x["actionable"] else 1, x["buyer"]))
    return deduped[:max_leads]
