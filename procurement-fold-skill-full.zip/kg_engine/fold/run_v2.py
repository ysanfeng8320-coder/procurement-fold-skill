"""Procurement Fold v2 — species-first pipeline entry."""
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime

KG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO_DIR = os.path.dirname(KG_DIR)
if KG_DIR not in sys.path:
    sys.path.insert(0, KG_DIR)

from fold.pack_loader import load_pack
from fold.species_loader import load_species, match_species, infer_level
from fold.ingest import load_local_records, fetch_api_records
from fold.structure import filter_recent, filter_date_range, _year_month, _amount_bucket
from fold.portfolio import build_events, build_unit_sequences, score_portfolio, build_species_leads
from fold.report import write_run_v2


def _load_contacts() -> dict:
    path = os.path.join(KG_DIR, "data", "contacts.json")
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    return {}


def run_fold_v2(
    species_id: str,
    portfolio: list,
    discovery_regions,
    action_regions,
    api_budget: int = 500,
    reuse_local: bool = True,
    max_age_years: float = 3.0,
    max_leads: int = 40,
    run_id: str = None,
    begin_date: str = None,
    end_date: str = None,
):
    if not species_id:
        raise ValueError("必须提供 species（如 police）。v2 禁止无物种提问。")
    if not portfolio:
        raise ValueError("必须提供至少一个 product pack（货盘）。")

    species = load_species(species_id)
    packs = [load_pack(pid) for pid in portfolio]
    discovery_regions = list(discovery_regions)
    action_regions = list(action_regions)

    product_kws = list(dict.fromkeys(
        [kw for p in packs for kw in (p.search_keywords or p.target or [])]
    )) or list(species.search_keywords)
    # 桥接词：法院印控仪 — 单关键词 API 才能命中「物种×产品」
    bridge_kws = []
    for prefix in (species.bridge_prefixes or species.search_keywords or [])[:3]:
        for pk in product_kws[:8]:
            bridge_kws.append(f"{prefix}{pk}")
    bridge_kws = list(dict.fromkeys(bridge_kws))

    all_regions = list(dict.fromkeys(list(discovery_regions) + list(action_regions)))
    date_kwargs = {}
    if begin_date or end_date:
        date_kwargs = {"begin_date": begin_date, "end_date": end_date}

    # 额度：桥接全国 40% + 落地区桥接/产品 30% + 物种 30%
    national_bridge_budget = max(0, int(api_budget * 0.4))
    action_bridge_budget = max(0, int(api_budget * 0.2))
    product_budget = max(0, int(api_budget * 0.2))
    species_budget = max(0, api_budget - national_bridge_budget - action_bridge_budget - product_budget)

    records = []
    local_files = []
    # 有明确时间窗时默认不混本地旧缓存，避免污染训练/验证
    if reuse_local and not date_kwargs:
        local_recs, local_files = load_local_records(
            list(dict.fromkeys(product_kws + species.search_keywords[:3])),
            all_regions,
        )
        records.extend(local_recs)

    api_used = 0
    bridge_api_meta = {"skipped": True}
    action_bridge_meta = {"skipped": True}
    product_api_meta = {"skipped": True}
    species_api_meta = {"skipped": True}

    if national_bridge_budget > 0 and bridge_kws:
        extra, used, bridge_api_meta = fetch_api_records(
            bridge_kws[:10], ["全国"], budget=national_bridge_budget, **date_kwargs
        )
        api_used += used
        records.extend(extra)

    if action_bridge_budget > 0 and bridge_kws:
        extra, used, action_bridge_meta = fetch_api_records(
            bridge_kws[:6], action_regions, budget=action_bridge_budget, **date_kwargs
        )
        api_used += used
        records.extend(extra)

    if product_budget > 0 and product_kws:
        extra, used, product_api_meta = fetch_api_records(
            product_kws[:4], all_regions, budget=product_budget, **date_kwargs
        )
        api_used += used
        records.extend(extra)

    if species_budget > 0:
        extra2, used2, species_api_meta = fetch_api_records(
            species.search_keywords[:3], all_regions, budget=species_budget, **date_kwargs
        )
        api_used += used2
        records.extend(extra2)

    seen = set()
    merged = []
    local_n = 0
    for rec in records:
        key = str(rec.get("source_id") or "") + "|" + (rec.get("title") or "")
        if key in seen:
            continue
        seen.add(key)
        if rec.get("_raw_source") == "local":
            local_n += 1
        region = rec.get("region") or ""
        if region in action_regions:
            rec["geo_role"] = "action"
        elif region in discovery_regions or region:
            # 非落地区一律作发现区证据（全国桥接回填的省也算）
            rec["geo_role"] = "discovery" if region not in action_regions else "action"
        else:
            rec["geo_role"] = "other"
        if region and region not in action_regions and region not in discovery_regions:
            # 动态扩入发现区，供评分/扩散使用
            if region not in discovery_regions:
                discovery_regions = list(discovery_regions) + [region]
        merged.append(rec)

    ingested = {
        "records": merged,
        "meta": {
            "local_files": local_files,
            "local_count": local_n,
            "api_used": api_used,
            "api_budget": api_budget,
            "bridge_keywords": bridge_kws[:10],
            "bridge_api_meta": bridge_api_meta,
            "action_bridge_meta": action_bridge_meta,
            "product_api_meta": product_api_meta,
            "species_api_meta": species_api_meta,
            "merged_count": len(merged),
            "discovery_regions": discovery_regions,
            "action_regions": action_regions,
        },
    }

    base = []
    for rec in ingested["records"]:
        buyers = rec.get("buyers") or []
        buyer = buyers[0] if buyers else ""
        title = rec.get("title") or ""
        if not match_species(buyer, title, species):
            continue
        base.append({
            **rec,
            "buyer": buyer,
            "species_id": species.species_id,
            "species_level": infer_level(buyer, species),
            "year_month": _year_month(rec.get("publish_time") or ""),
            "amount_bucket": _amount_bucket(float(rec.get("money_wan") or 0)),
            "buyer_system": species.display_name,
        })

    if begin_date or end_date:
        structured = filter_date_range(base, begin_date=begin_date, end_date=end_date)
    else:
        structured = filter_recent(base, max_age_years=max_age_years)
    events = build_events(structured, species, packs)
    sequences = build_unit_sequences(events)
    scores = score_portfolio(
        events, sequences, packs, species, action_regions, discovery_regions
    )
    action_units = [r for r in structured if r.get("region") in action_regions]
    leads = build_species_leads(
        events,
        packs,
        action_regions,
        max_leads=max_leads,
        contacts=_load_contacts(),
        structured_action_units=action_units,
        discovery_regions=discovery_regions,
    )

    run_id = run_id or datetime.now().strftime("%Y%m%d_%H%M%S") + f"_{species_id}"
    run_dir = os.path.join(REPO_DIR, "fold_runs", run_id)
    meta = {
        "mode": "species_first_v2",
        "species_id": species_id,
        "species_name": species.display_name,
        "portfolio": portfolio,
        "discovery_regions": discovery_regions,
        "action_regions": action_regions,
        "ingest": ingested["meta"],
        "max_age_years": max_age_years,
        "begin_date": begin_date,
        "end_date": end_date,
        "structured_before_date_filter": len(base),
        "structured_after_date_filter": len(structured),
        "events_count": len(events),
        "units_with_sequence": len(sequences),
    }
    report_path = write_run_v2(
        run_dir, structured, events, sequences, scores, leads, meta, species, packs
    )
    return {
        "run_dir": run_dir,
        "report_path": report_path,
        "meta": meta,
        "scores": scores,
        "leads": leads,
    }


def main(argv=None):
    p = argparse.ArgumentParser(description="Procurement Fold v2 (species-first)")
    p.add_argument("--species", required=True, help="物种包 id，如 police")
    p.add_argument(
        "--portfolio",
        required=True,
        help="货盘产品包，逗号分隔，如 seal_control 或 seal_control,binding_machine",
    )
    p.add_argument("--discovery", default="安徽,浙江,北京,上海")
    p.add_argument("--action", default="陕西,甘肃")
    p.add_argument("--api-budget", type=int, default=300)
    p.add_argument("--reuse-local", action="store_true", default=True)
    p.add_argument("--no-reuse-local", action="store_true")
    p.add_argument("--max-age-years", type=float, default=3.0)
    p.add_argument("--max-leads", type=int, default=40)
    p.add_argument("--begin-date", default=None, help="YYYY-MM-DD，知了网时间窗起点")
    p.add_argument("--end-date", default=None, help="YYYY-MM-DD，知了网时间窗终点")
    p.add_argument(
        "--phone-complete",
        action="store_true",
        help="跑完名单后执行电话补全（本地harvest；可用 --phone-api-budget）",
    )
    p.add_argument(
        "--phone-api-budget",
        type=int,
        default=0,
        help="电话补全 API 调用上限，默认0=只本地",
    )
    p.add_argument(
        "--gate-mode",
        choices=["test", "formal", "skip"],
        default="test",
        help="采集闸门模式；api-budget>0 时默认检查",
    )
    args = p.parse_args(argv)

    portfolio = [x.strip() for x in args.portfolio.split(",") if x.strip()]
    discovery = [x.strip() for x in args.discovery.split(",") if x.strip()]
    action = [x.strip() for x in args.action.split(",") if x.strip()]
    reuse = not args.no_reuse_local

    if args.gate_mode != "skip" and args.api_budget > 0:
        from fold.acquisition_gate import check_gate, assert_gate_or_exit
        gate = check_gate(
            mode=args.gate_mode,
            api_budget=args.api_budget,
            keywords=portfolio,
            reuse_local=reuse,
            species_id=args.species,
            product_id=portfolio[0] if portfolio else "",
        )
        assert_gate_or_exit(gate)

    result = run_fold_v2(
        species_id=args.species,
        portfolio=portfolio,
        discovery_regions=discovery,
        action_regions=action,
        api_budget=args.api_budget,
        reuse_local=reuse,
        max_age_years=args.max_age_years,
        max_leads=args.max_leads,
        begin_date=args.begin_date,
        end_date=args.end_date,
    )
    print(f"run_dir: {result['run_dir']}")
    print(f"report: {result['report_path']}")
    print(f"species: {args.species} portfolio: {portfolio}")
    print(f"species_units: {result['meta']['structured_after_date_filter']}")
    print(f"events: {result['meta']['events_count']} units: {result['meta']['units_with_sequence']}")
    print(f"leads: {len(result['leads'])}")
    for s in result["scores"]:
        print(f"  [{s['band']}] {s['display_name']}: {s['score']}")
    print(f"api_used: {result['meta']['ingest'].get('api_used')}/{result['meta']['ingest'].get('api_budget')}")

    if args.phone_complete:
        from fold.phone_complete import complete_run
        phone = complete_run(
            result["run_dir"],
            api_budget=args.phone_api_budget,
            province=action[0] if action else None,
            harvest=True,
        )
        print(f"phone_actionable: {phone['actionable']}/{phone['total']}")
        print(f"phone_report: {phone['html_path']}")


if __name__ == "__main__":
    main()
