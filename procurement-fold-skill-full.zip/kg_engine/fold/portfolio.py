"""Build unit purchase sequences and portfolio opportunity scores (species-first)."""
from __future__ import annotations

from collections import Counter, defaultdict
from typing import Dict, List, Optional, Tuple

from .pack_loader import ProductPack
from .species_loader import SpeciesPack
from .structure import hit_tier


def _phone_ok(phone) -> bool:
    try:
        from phone_enricher import is_real_phone
        return is_real_phone(str(phone or ""))
    except Exception:
        return bool(phone and phone not in ("待确认", "待补充", ""))

STRONG = {"target", "near"}


def build_events(
    records: List[dict],
    species: SpeciesPack,
    packs: List[ProductPack],
) -> List[dict]:
    """One event per (record × product_pack) with title hit; species already filtered."""
    events = []
    for rec in records:
        buyer = rec.get("buyer") or ""
        title = rec.get("title") or ""
        for pack in packs:
            tier, kw = hit_tier(title, pack)
            if tier in ("none", "confuse"):
                continue
            events.append({
                "unit_name": buyer,
                "species_id": species.species_id,
                "region": rec.get("region"),
                "level": rec.get("species_level") or "其他",
                "geo_role": rec.get("geo_role"),
                "product_pack": pack.pack_id,
                "product_name": pack.canonical_product or pack.display_name,
                "hit_tier": tier,
                "matched_keyword": kw,
                "date": rec.get("publish_time"),
                "year_month": rec.get("year_month"),
                "amount_bucket": rec.get("amount_bucket"),
                "title": title,
                "source_id": rec.get("source_id"),
            })
    return events


def build_unit_sequences(events: List[dict]) -> Dict[str, List[dict]]:
    seq: Dict[str, List[dict]] = defaultdict(list)
    for e in events:
        key = f"{e.get('region')}|{e.get('unit_name')}"
        seq[key].append(e)
    for k in seq:
        seq[k].sort(key=lambda x: x.get("date") or "")
    return dict(seq)


def score_portfolio(
    events: List[dict],
    sequences: Dict[str, List[dict]],
    packs: List[ProductPack],
    species: SpeciesPack,
    action_regions: List[str],
    discovery_regions: List[str],
) -> List[dict]:
    """Relative 0-100 scores per product pack within this species."""
    units_all = set()
    units_by_pack_strong = defaultdict(set)
    units_by_pack_related = defaultdict(set)
    discovery_strong = defaultdict(set)
    action_units = set()
    action_strong = defaultdict(set)
    action_related = defaultdict(set)
    recent_ym = Counter()

    for e in events:
        u = f"{e.get('region')}|{e.get('unit_name')}"
        units_all.add(u)
        pid = e.get("product_pack")
        if e.get("region") in action_regions:
            action_units.add(u)
        if e.get("hit_tier") in STRONG:
            units_by_pack_strong[pid].add(u)
            if e.get("region") in discovery_regions:
                discovery_strong[pid].add(u)
            if e.get("region") in action_regions:
                action_strong[pid].add(u)
            if e.get("year_month"):
                recent_ym[(pid, e.get("year_month"))] += 1
        elif e.get("hit_tier") == "related":
            units_by_pack_related[pid].add(u)
            if e.get("region") in action_regions:
                action_related[pid].add(u)

    n_units = max(len(units_all), 1)
    n_action = max(len(action_units), 1)
    scores = []

    for pack in packs:
        pid = pack.pack_id
        strong_n = len(units_by_pack_strong[pid])
        related_n = len(units_by_pack_related[pid])
        coverage = strong_n / n_units
        # gap: related but not strong
        gap_units = units_by_pack_related[pid] - units_by_pack_strong[pid]
        gap_rate = len(gap_units) / n_units
        action_gap = action_related[pid] - action_strong[pid]
        action_gap_rate = len(action_gap) / n_action

        # diffusion: discovery has strong, action has gap or missing
        disc = len(discovery_strong[pid])
        action_missing = len(action_units - action_strong[pid]) if action_units else 0
        diffusion = min(1.0, (disc / max(len(discovery_regions) * 2, 1)) * (action_missing / n_action))

        # recent surge proxy: last 2 months share of this pack strong events
        pack_months = sorted([ym for (p, ym), c in recent_ym.items() if p == pid])
        surge = 0.0
        if len(pack_months) >= 2:
            last2 = pack_months[-2:]
            c_last = sum(recent_ym[(pid, m)] for m in last2)
            c_all = sum(c for (p, ym), c in recent_ym.items() if p == pid) or 1
            surge = min(1.0, (c_last / c_all) * 2)

        # prior: species notes mention 印章/用印/印控
        prior = 0.0
        blob = " ".join(species.industry_notes or [])
        for tip in ("印章", "用印", "印控", "盖章"):
            if tip in blob and any(tip in x for x in (pack.target + pack.near + pack.related)):
                prior = 0.15
                break

        # weighted score
        score = 100 * (
            0.25 * min(1.0, coverage * 3)
            + 0.30 * min(1.0, gap_rate * 4)
            + 0.20 * min(1.0, action_gap_rate * 4)
            + 0.15 * diffusion
            + 0.10 * surge
            + prior
        )
        score = round(min(100.0, score), 1)
        if score >= 60:
            band = "高"
            band_range = "≥60%"
        elif score >= 35:
            band = "中"
            band_range = "35%–59%"
        else:
            band = "低"
            band_range = "<35%"

        rationale = []
        rationale.append(f"本物种单位覆盖（强相关）{strong_n}/{len(units_all)}（{coverage:.0%}）")
        rationale.append(f"关联缺口单位 {len(gap_units)} 家（缺口率 {gap_rate:.0%}）")
        rationale.append(f"落地区关联缺口 {len(action_gap)} 家")
        if disc:
            rationale.append(f"发现区已出现强相关 {disc} 家单位，支撑跨地跟风")
        if surge >= 0.3:
            rationale.append("近窗标讯占比偏高，短期有抬头迹象")
        if prior:
            rationale.append("物种行业笔记支持用印/印章类需求")

        scores.append({
            "product_pack": pid,
            "display_name": pack.display_name,
            "canonical_product": pack.canonical_product,
            "score": score,
            "score_pct": f"{score:.1f}%",
            "band": band,
            "band_range": band_range,
            "band_legend": "高≥60%｜中35%–59%｜低<35%",
            "rationale": rationale,
            "factors": {
                "units_total": len(units_all),
                "strong_units": strong_n,
                "related_units": related_n,
                "gap_units": len(gap_units),
                "action_gap_units": len(action_gap),
                "discovery_strong_units": disc,
                "coverage": round(coverage, 3),
                "gap_rate": round(gap_rate, 3),
                "action_gap_rate": round(action_gap_rate, 3),
                "diffusion": round(diffusion, 3),
                "surge": round(surge, 3),
            },
        })

    scores.sort(key=lambda x: -x["score"])
    return scores


def build_species_leads(
    events: List[dict],
    packs: List[ProductPack],
    action_regions: List[str],
    max_leads: int = 40,
    contacts: Optional[dict] = None,
    structured_action_units: Optional[List[dict]] = None,
    discovery_regions: Optional[List[str]] = None,
) -> List[dict]:
    """Action-region gaps + cross-region diffusion candidates."""
    contacts = contacts or {}
    discovery_regions = discovery_regions or []
    by_unit: Dict[str, List[dict]] = defaultdict(list)
    for e in events:
        if e.get("region") not in action_regions:
            continue
        if not e.get("unit_name"):
            continue
        by_unit[f"{e.get('region')}|{e.get('unit_name')}"].append(e)

    leads = []
    for key, evs in by_unit.items():
        region, unit = key.split("|", 1)
        by_pack = defaultdict(set)
        evidence_by_pack = defaultdict(list)
        for e in evs:
            by_pack[e["product_pack"]].add(e["hit_tier"])
            evidence_by_pack[e["product_pack"]].append(e)

        gaps = []
        for pack in packs:
            tiers = by_pack.get(pack.pack_id) or set()
            if "target" in tiers:
                continue
            if "related" in tiers or "near" in tiers:
                gaps.append(pack.pack_id)

        if not gaps:
            continue

        evidence = []
        for pid in gaps:
            for e in sorted(evidence_by_pack[pid], key=lambda x: x.get("date") or "", reverse=True)[:2]:
                evidence.append({
                    "title": e.get("title"),
                    "date": e.get("date"),
                    "hit_tier": e.get("hit_tier"),
                    "matched_keyword": e.get("matched_keyword"),
                    "product_pack": pid,
                    "source_id": e.get("source_id"),
                })
        evidence = sorted(evidence, key=lambda x: x.get("date") or "", reverse=True)[:3]
        phone = contacts.get(unit)
        actionable = _phone_ok(phone)
        gap_names = [p.canonical_product for p in packs if p.pack_id in gaps]
        leads.append({
            "buyer": unit,
            "region": region,
            "buyer_system": evs[0].get("buyer_system") or evs[0].get("species_id") or "species",
            "species_id": evs[0].get("species_id"),
            "level": evs[0].get("level"),
            "lead_type": "assoc_gap",
            "priority": "P1",
            "gap_products": gaps,
            "matched_rules": ["species_sequence_gap"],
            "evidence": evidence,
            "gap_detail": f"近窗内已有关联采购迹象，本品缺口：{'、'.join(gap_names)}",
            "suggested_action": (
                f"按本物种话术推进缺口产品（{'、'.join(gap_names)}）；"
                + ("可直联" if actionable else "优先集成商/运营商渠道")
            ),
            "actionable": actionable,
            "action_blocker": None if actionable else "无可用电话，建议经集成商或公告附件补全",
            "contact": phone if actionable else None,
        })

    # 横向扩散：发现区 OR 落地区内已购参照 → 落地区同物种尚无本品事件的单位
    discovery_packs = {
        e.get("product_pack")
        for e in events
        if e.get("region") in discovery_regions and e.get("hit_tier") in ("target", "near", "related")
    }
    discovery_evidence = sorted(
        [
            e for e in events
            if e.get("region") in discovery_regions and e.get("hit_tier") in ("target", "near", "related")
        ],
        key=lambda x: x.get("date") or "",
        reverse=True,
    )
    _action_strong = [
        e for e in events
        if e.get("region") in action_regions and e.get("hit_tier") in STRONG
    ]
    action_strong_events = sorted(
        [e for e in _action_strong if e.get("hit_tier") == "target"],
        key=lambda x: x.get("date") or "",
        reverse=True,
    ) + sorted(
        [e for e in _action_strong if e.get("hit_tier") != "target"],
        key=lambda x: x.get("date") or "",
        reverse=True,
    )
    action_packs = {e.get("product_pack") for e in action_strong_events}
    ref_packs = discovery_packs | action_packs
    # 有同省已购时优先 peer 证据（销售更可讲）；否则用发现区
    use_intra = bool(action_packs)
    ref_evidence = action_strong_events if action_strong_events else discovery_evidence
    # 若仅有发现区、无落地区已购，则跨地扩散
    if not action_packs and discovery_packs:
        use_intra = False
        ref_evidence = discovery_evidence

    if ref_packs and structured_action_units:
        already = {l["buyer"] for l in leads}
        action_with_event = {
            e.get("unit_name")
            for e in events
            if e.get("region") in action_regions and e.get("product_pack") in ref_packs
        }
        for rec in structured_action_units:
            unit = rec.get("buyer") or ""
            if not unit or unit in already or unit in action_with_event:
                continue
            phone = contacts.get(unit)
            actionable = _phone_ok(phone)
            # 优先同省参照
            same_prov = [e for e in action_strong_events if e.get("region") == rec.get("region")]
            ev = (same_prov or ref_evidence or [None])[0]
            if not ev:
                continue
            if use_intra:
                lead_type = "peer_gap"
                priority = "P1"
                rule = "intra_region_peer"
                detail = (
                    f"落地区同类已购参照：{ev.get('region')}·{ev.get('unit_name')}；"
                    "本单位近窗未见本品公开记录（同省跟风缺口）"
                )
                action = "用同省兄弟法院/单位已购案例切入；确认是否已有电子印章平台或硬件印控"
            else:
                lead_type = "diffusion"
                priority = "P2"
                rule = "cross_region_diffusion"
                detail = (
                    "发现区同类单位已出现印控/电子印章类采购；"
                    "落地区本单位近窗未见同类事件（跨地跟风候选）"
                )
                action = "用外省兄弟单位案例做切入；确认本地是否已有电子印章/用印平台"
            leads.append({
                "buyer": unit,
                "region": rec.get("region"),
                "buyer_system": rec.get("buyer_system") or rec.get("species_id"),
                "species_id": rec.get("species_id"),
                "level": rec.get("species_level"),
                "lead_type": lead_type,
                "priority": priority,
                "gap_products": list(ref_packs),
                "matched_rules": [rule],
                "evidence": [{
                    "title": ev.get("title"),
                    "date": ev.get("date"),
                    "hit_tier": ev.get("hit_tier"),
                    "matched_keyword": ev.get("matched_keyword"),
                    "product_pack": ev.get("product_pack"),
                    "source_id": ev.get("source_id"),
                    "note": f"参照：{ev.get('region')}·{ev.get('unit_name')}",
                }] if ev else [],
                "gap_detail": detail,
                "suggested_action": action + ("；可直联" if actionable else "；走集成商/运营商"),
                "actionable": actionable,
                "action_blocker": None if actionable else "无可用电话，建议经集成商或公告附件补全",
                "contact": phone if actionable else None,
            })
            already.add(unit)

    # 已购强相关：参照/复购观察（不占缺口优先级）
    for e in action_strong_events:
        unit = e.get("unit_name")
        if not unit:
            continue
        if any(l.get("buyer") == unit and l.get("lead_type") == "already_bought" for l in leads):
            continue
        phone = contacts.get(unit)
        actionable = _phone_ok(phone)
        leads.append({
            "buyer": unit,
            "region": e.get("region"),
            "buyer_system": e.get("buyer_system") or e.get("species_id") or "species",
            "species_id": e.get("species_id"),
            "level": e.get("level"),
            "lead_type": "already_bought",
            "priority": "P2",
            "gap_products": [],
            "matched_rules": ["already_bought_reference"],
            "evidence": [{
                "title": e.get("title"),
                "date": e.get("date"),
                "hit_tier": e.get("hit_tier"),
                "matched_keyword": e.get("matched_keyword"),
                "product_pack": e.get("product_pack"),
                "source_id": e.get("source_id"),
            }],
            "gap_detail": "近窗已有本品强相关公开采购（已成交参照，勿当陌生首单）",
            "suggested_action": "作同省案例背书；跟进维保/增购/关联品，而非首单开拓",
            "actionable": actionable,
            "action_blocker": None if actionable else "无可用电话",
            "contact": phone if actionable else None,
        })

    priority_rank = {"P0": 0, "P1": 1, "P2": 2}
    type_rank = {"assoc_gap": 0, "peer_gap": 1, "diffusion": 2, "volume_buyer": 3, "already_bought": 4}
    leads.sort(key=lambda x: (
        priority_rank.get(x.get("priority"), 9),
        0 if x.get("actionable") else 1,
        type_rank.get(x.get("lead_type"), 9),
        x.get("buyer") or "",
    ))
    return leads[:max_leads]


def build_volume_leads(
    events: List[dict],
    packs: List[ProductPack],
    action_regions: List[str],
    max_per_product: int = 150,
    contacts: Optional[dict] = None,
) -> List[dict]:
    """High-volume products: every unique buyer is a lead (成交池), not only assoc_gap.

    碎纸机/复印机等公开成交上万条时，缺口算法会把线索压到个位数；
    成交池按「单位×产品」去重，默认每品最多 max_per_product 条。
    """
    contacts = contacts or {}
    out: List[dict] = []
    for pack in packs:
        pid = pack.pack_id
        seen = set()
        pack_events = [
            e for e in events
            if e.get("product_pack") == pid
            and e.get("hit_tier") in ("target", "near", "related")
            and e.get("unit_name")
        ]

        def _rank(e: dict):
            geo = 0 if e.get("region") in action_regions else 1
            tier = {"target": 0, "near": 1, "related": 2}.get(e.get("hit_tier"), 9)
            # newer first → invert date for ascending sort
            date = e.get("date") or ""
            return (geo, tier, "".join(chr(255 - ord(c)) for c in date if ord(c) < 255))

        pack_events = sorted(pack_events, key=_rank)

        count = 0
        for e in pack_events:
            unit = e.get("unit_name") or ""
            key = f"{e.get('region')}|{unit}|{pid}"
            if key in seen:
                continue
            seen.add(key)
            in_action = e.get("region") in action_regions
            phone = contacts.get(unit)
            actionable = _phone_ok(phone)
            out.append({
                "buyer": unit,
                "region": e.get("region"),
                "buyer_system": e.get("buyer_system") or e.get("species_id"),
                "species_id": e.get("species_id"),
                "level": e.get("level"),
                "lead_type": "volume_buyer",
                "priority": "P1" if in_action else "P2",
                "gap_products": [pid],
                "product_pack": pid,
                "product_name": pack.canonical_product,
                "matched_rules": ["volume_buyer_pool"],
                "evidence": [{
                    "title": e.get("title"),
                    "date": e.get("date"),
                    "hit_tier": e.get("hit_tier"),
                    "matched_keyword": e.get("matched_keyword"),
                    "product_pack": pid,
                    "source_id": e.get("source_id"),
                }],
                "gap_detail": (
                    f"{'落地区' if in_action else '发现区'}已有{pack.canonical_product}公开采购"
                    f"（成交池；可跟进增购/维保/关联品）"
                ),
                "suggested_action": (
                    f"按{pack.canonical_product}成交池跟进；"
                    + ("可直联" if actionable else "走集成商/运营商")
                ),
                "actionable": actionable,
                "action_blocker": None if actionable else "无可用电话",
                "contact": phone if actionable else None,
                "date": e.get("date"),
            })
            count += 1
            if count >= max_per_product:
                break
    return out
