"""Act stage — re-export leads builder."""
from .leads import act_leads

__all__ = ["act_leads"]
