#!/usr/bin/env python3
"""Temporal train/validate for procurement-fold using real 知了网 dated API.

Train: full year 2025 → portfolio scores + 陕甘 leads + advice
Validate: 2026 three months → hit-rate of train predictions vs real purchases

Design:
  - Pull product keywords nationwide with begin_date/end_date (知了网 only)
  - Offline slice by species packs (court/procuratorate/police/agriculture)
  - Products: seal_control, shredder, binding_machine, copier
  - No mock data.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from collections import defaultdict
from datetime import datetime
from typing import Dict, List, Tuple

KG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO_DIR = os.path.dirname(KG_DIR)
if KG_DIR not in sys.path:
    sys.path.insert(0, KG_DIR)

from fold.pack_loader import load_pack, ProductPack
from fold.species_loader import load_species, match_species, infer_level
from fold.ingest import fetch_api_records
from fold.structure import filter_date_range, hit_tier, _year_month, _amount_bucket
from fold.portfolio import build_events, build_unit_sequences, score_portfolio, build_species_leads


SPECIES_IDS = ["court", "procuratorate", "police", "agriculture"]
PRODUCT_IDS = ["seal_control", "shredder", "binding_machine", "copier"]
DISCOVERY = ["安徽", "浙江", "北京", "上海", "江苏", "山东", "河南", "四川", "广东"]
ACTION = ["陕西", "甘肃"]


def _normalize_unit(name: str) -> str:
    return (name or "").strip().replace(" ", "")


def _prepare_records(raw: List[dict], discovery: List[str], action: List[str]) -> List[dict]:
    discovery = list(discovery)
    out = []
    seen = set()
    for rec in raw:
        key = str(rec.get("source_id") or "") + "|" + (rec.get("title") or "")
        if key in seen:
            continue
        seen.add(key)
        region = rec.get("region") or ""
        if region in action:
            rec["geo_role"] = "action"
        elif region:
            rec["geo_role"] = "discovery"
            if region not in discovery and region not in action:
                discovery.append(region)
        else:
            rec["geo_role"] = "other"
        out.append(rec)
    return out, discovery


def _species_slice(records: List[dict], species) -> List[dict]:
    base = []
    for rec in records:
        buyers = rec.get("buyers") or []
        buyer = buyers[0] if buyers else ""
        title = rec.get("title") or ""
        if not match_species(buyer, title, species):
            continue
        base.append({
            **rec,
            "buyer": buyer,
            "species_id": species.species_id,
            "species_level": infer_level(buyer, species),
            "year_month": _year_month(rec.get("publish_time") or ""),
            "amount_bucket": _amount_bucket(float(rec.get("money_wan") or 0)),
            "buyer_system": species.display_name,
        })
    return base


def pull_window(
    packs: List[ProductPack],
    species_list,
    begin: str,
    end: str,
    budget: int,
    label: str,
) -> Tuple[List[dict], dict]:
    """Pull real 知了网 data for a date window. Budget split across products + per-species bridges."""
    product_kws = []
    for p in packs:
        product_kws.extend((p.search_keywords or p.target or [])[:3])
    product_kws = list(dict.fromkeys(product_kws))

    # Per-species bridge lists (avoid court-only starvation of agriculture/police)
    species_bridges = {}
    for sp in species_list:
        kws = []
        for prefix in (sp.bridge_prefixes or sp.search_keywords or [])[:2]:
            for p in packs:
                for pk in (p.search_keywords or p.target or [])[:2]:
                    kws.append(f"{prefix}{pk}")
        species_bridges[sp.species_id] = list(dict.fromkeys(kws))

    # 45% per-species bridge, 30% product, 25% action
    b_bridge = max(40, int(budget * 0.45))
    b_product = max(10, int(budget * 0.30))
    b_action = max(10, budget - b_bridge - b_product)
    per_sp = max(15, b_bridge // max(len(species_list), 1))

    all_recs: List[dict] = []
    meta = {"label": label, "begin": begin, "end": end, "budget": budget, "parts": {}}
    api_used = 0

    print(f"\n=== PULL {label} {begin}→{end} budget={budget} (知了网) ===")
    print(f"  species_bridges={[ (k,len(v)) for k,v in species_bridges.items() ]} product_kws={len(product_kws)}")

    bridge_parts = {}
    for sp in species_list:
        kws = species_bridges[sp.species_id]
        r, u, m = fetch_api_records(
            kws[:12], ["全国"], budget=per_sp, begin_date=begin, end_date=end
        )
        print(f"  bridge[{sp.species_id}]: used={u}/{per_sp} got={len(r)} source={m.get('source')}")
        bridge_parts[sp.species_id] = {"used": u, "got": len(r), "meta": m}
        all_recs.extend(r)
        api_used += u
    meta["parts"]["bridge_by_species"] = bridge_parts

    r2, u2, m2 = fetch_api_records(
        product_kws[:16], ["全国"], budget=b_product, begin_date=begin, end_date=end
    )
    print(f"  product全国: used={u2}/{b_product} got={len(r2)} source={m2.get('source')}")
    meta["parts"]["product"] = {"used": u2, "got": len(r2), "meta": m2}
    all_recs.extend(r2)
    api_used += u2

    action_kws = list(dict.fromkeys(
        [kw for p in packs for kw in (p.search_keywords or [])[:2]]
        + [kw for kws in species_bridges.values() for kw in kws[:4]]
    ))
    r3, u3, m3 = fetch_api_records(
        action_kws[:20], ACTION, budget=b_action, begin_date=begin, end_date=end
    )
    print(f"  action陕甘: used={u3}/{b_action} got={len(r3)} source={m3.get('source')}")
    meta["parts"]["action"] = {"used": u3, "got": len(r3), "meta": m3}
    all_recs.extend(r3)
    api_used += u3

    meta["api_used"] = api_used
    meta["raw_merged"] = len(all_recs)
    dated = filter_date_range(all_recs, begin_date=begin, end_date=end)
    meta["after_date_filter"] = len(dated)
    # compat for report source line
    meta["parts"]["bridge"] = {
        "used": sum(v["used"] for v in bridge_parts.values()),
        "got": sum(v["got"] for v in bridge_parts.values()),
        "meta": {"source": "zhiliao"},
    }
    print(f"  merged={len(all_recs)} after_date={len(dated)} api_used={meta['api_used']}")
    return dated, meta


def analyze_combo(
    records: List[dict],
    species,
    packs: List[ProductPack],
    discovery: List[str],
    action: List[str],
    max_leads: int = 30,
) -> dict:
    prepared, disc = _prepare_records(records, discovery, action)
    structured = _species_slice(prepared, species)
    events = build_events(structured, species, packs)
    sequences = build_unit_sequences(events)
    scores = score_portfolio(events, sequences, packs, species, action, disc)
    action_units = [r for r in structured if r.get("region") in action]
    leads = build_species_leads(
        events, packs, action, max_leads=max_leads,
        structured_action_units=action_units, discovery_regions=disc,
    )
    # unit keys that bought each pack (strong)
    bought: Dict[str, set] = defaultdict(set)
    for e in events:
        if e.get("hit_tier") in ("target", "near"):
            bought[e["product_pack"]].add(_normalize_unit(e.get("unit_name") or ""))
    action_bought: Dict[str, set] = defaultdict(set)
    for e in events:
        if e.get("region") in action and e.get("hit_tier") in ("target", "near", "related"):
            action_bought[e["product_pack"]].add(_normalize_unit(e.get("unit_name") or ""))

    return {
        "species_id": species.species_id,
        "species_name": species.display_name,
        "structured": len(structured),
        "events": len(events),
        "units": len(sequences),
        "action_structured": len(action_units),
        "scores": scores,
        "leads": leads,
        "bought_units": {k: sorted(v) for k, v in bought.items()},
        "action_bought_units": {k: sorted(v) for k, v in action_bought.items()},
        "discovery_regions_used": disc,
    }


def validate_against(
    train_result: dict,
    val_result: dict,
    packs: List[ProductPack],
) -> dict:
    """Compare train leads / patterns vs validate actual purchases."""
    metrics = []
    val_action = val_result.get("action_bought_units") or {}
    train_leads = train_result.get("leads") or []

    for pack in packs:
        pid = pack.pack_id
        # predicted lead buyers for this pack
        pred_units = set()
        for lead in train_leads:
            gaps = lead.get("gap_products") or []
            # diffusion leads may use matched_rules
            if pid in gaps or lead.get("lead_type") in ("diffusion", "peer_gap"):
                # for diffusion, check if pack is in ref
                if pid in gaps or True:
                    # only count if lead mentions this pack somehow
                    if pid in gaps:
                        pred_units.add(_normalize_unit(lead.get("buyer") or ""))
                    elif lead.get("lead_type") in ("diffusion", "peer_gap"):
                        # peer/diffusion often for whole portfolio — count if evidence mentions pack
                        ev = lead.get("evidence") or []
                        if any(e.get("product_pack") == pid for e in ev) or not gaps:
                            pred_units.add(_normalize_unit(lead.get("buyer") or ""))

        # tighter: only assoc_gap with this pack, plus peer/diffusion with evidence for pack
        pred_tight = set()
        for lead in train_leads:
            buyer = _normalize_unit(lead.get("buyer") or "")
            if not buyer:
                continue
            gaps = set(lead.get("gap_products") or [])
            if pid in gaps:
                pred_tight.add(buyer)
                continue
            if lead.get("lead_type") in ("diffusion", "peer_gap"):
                ev = lead.get("evidence") or []
                if any(e.get("product_pack") == pid for e in ev):
                    pred_tight.add(buyer)

        actual = set(val_action.get(pid) or [])
        hits = sorted(pred_tight & actual)
        # also: train discovery strong → validate action same species product (pattern lift)
        train_bought = set(train_result.get("bought_units", {}).get(pid) or [])
        train_action = set(train_result.get("action_bought_units", {}).get(pid) or [])
        # units that bought in validate but not in train action (new demand)
        new_action = sorted(actual - train_action)

        precision = (len(hits) / len(pred_tight)) if pred_tight else None
        recall = (len(hits) / len(actual)) if actual else None

        metrics.append({
            "product_pack": pid,
            "display_name": pack.display_name,
            "train_score": next((s["score"] for s in train_result["scores"] if s["product_pack"] == pid), None),
            "train_band": next((s["band"] for s in train_result["scores"] if s["product_pack"] == pid), None),
            "train_events": sum(1 for e in [] ),  # filled below if needed
            "pred_leads": len(pred_tight),
            "val_action_units": len(actual),
            "hits": hits,
            "hit_count": len(hits),
            "precision": round(precision, 3) if precision is not None else None,
            "recall": round(recall, 3) if recall is not None else None,
            "new_action_units_2026": new_action[:20],
            "new_action_count": len(new_action),
            "train_strong_units": len(train_bought),
            "train_action_units": len(train_action),
        })
    return {"by_product": metrics, "train_leads_n": len(train_leads), "val_structured": val_result.get("structured")}


def advice_from_results(combo_rows: List[dict]) -> List[str]:
    tips = []
    # rank by train band + validate signal
    ranked = []
    for row in combo_rows:
        train = row["train"]
        val = row["validate"]
        metrics = row["metrics"]["by_product"]
        for m in metrics:
            signal = (m.get("train_score") or 0) + 10 * (m.get("hit_count") or 0) + 5 * (m.get("new_action_count") or 0)
            density = train.get("events", 0)
            ranked.append((signal, density, row["species_id"], m))

    ranked.sort(key=lambda x: (-x[0], -x[1]))
    if not ranked:
        tips.append("本次窗口内有效组合过少，建议加大桥接词预算或放宽发现区。")
        return tips

    tips.append("## 优先楔子（按 2025 信号 + 2026 验证命中排序）")
    for signal, density, sid, m in ranked[:8]:
        tips.append(
            f"- **{sid} × {m['display_name']}**：训练分 {m.get('train_score')}（{m.get('train_band')}），"
            f"预测线索 {m.get('pred_leads')}，2026落地区实购单位 {m.get('val_action_units')}，"
            f"线索命中 {m.get('hit_count')}，新出现落地区单位 {m.get('new_action_count')}"
        )

    # desert combos: no train strong AND no validate action AND train score near zero
    deserts = [
        (sid, m) for _, dens, sid, m in ranked
        if (m.get("train_strong_units") or 0) == 0
        and (m.get("val_action_units") or 0) == 0
        and (m.get("train_score") or 0) < 5
    ]
    if deserts:
        tips.append("\n## 公开数据荒漠（2025训练+2026验证均无强信号）")
        seen = set()
        for sid, m in deserts:
            key = f"{sid}|{m['product_pack']}"
            if key in seen:
                continue
            seen.add(key)
            tips.append(f"- {sid} × {m['display_name']}：公开标讯不足以支撑销售名单，勿先砸销售工时")

    # workable
    workable = [
        (sid, m) for _, dens, sid, m in ranked
        if (m.get("train_score") or 0) >= 35 or (m.get("new_action_count") or 0) >= 1 or (m.get("hit_count") or 0) >= 1
    ]
    if workable:
        tips.append("\n## 可继续迭代的组合")
        seen = set()
        for sid, m in workable[:10]:
            key = f"{sid}|{m['product_pack']}"
            if key in seen:
                continue
            seen.add(key)
            tips.append(
                f"- {sid} × {m['display_name']}：用 2025 序列做缺口/同省参照，"
                f"对 2026 新出现的落地区单位做跟进清单"
            )

    tips.append("\n## 方法建议")
    tips.append("- 训练窗用整年（季节性采购不会漏），验证窗用季度即可检验「名单是否空转」。")
    tips.append("- 必须走知了网 `begin_date`/`end_date`；世舶无可靠时间窗，带日期查询勿混源。")
    tips.append("- API 预算必须按关键词均分，否则第一个热词（如碎纸机）会吃光额度，装订机/复印机假荒漠。")
    tips.append("- 物种匹配只看买方名；产品命中只看标题（文件名不得升级 related）。")
    tips.append("- 小样本高分（公安事件<15）只作观察，不作主推；优先法院等厚样本物种。")
    tips.append("- 线索命中率低时，改看「2026落地区新出现单位」作跟进池，而不是死磕 assoc_gap 精确率。")
    tips.append("- 电话仍缺时，验证有实购的组合优先走集成商名单，不要卡在直联。")
    return tips


def write_report(out_dir: str, payload: dict) -> str:
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "temporal_result.json"), "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2, default=str)

    lines = []
    lines.append("# 采购折叠 · 时间窗真实评测报告")
    lines.append("")
    lines.append(f"- 训练窗：{payload['train_begin']} → {payload['train_end']}（知了网真实拉取）")
    lines.append(f"- 验证窗：{payload['val_begin']} → {payload['val_end']}（知了网真实拉取）")
    lines.append(f"- 落地区：{', '.join(payload['action'])}")
    lines.append(f"- 物种：{', '.join(payload['species'])}")
    lines.append(f"- 货盘：{', '.join(payload['products'])}")
    lines.append(f"- API 用量：训练 {payload['train_pull'].get('api_used')} / 验证 {payload['val_pull'].get('api_used')}")
    lines.append(f"- 数据源：训练 `{payload['train_pull'].get('parts', {}).get('bridge', {}).get('meta', {}).get('source')}` "
                 f"/ 验证 `{payload['val_pull'].get('parts', {}).get('bridge', {}).get('meta', {}).get('source')}`")
    lines.append("")
    lines.append("## 组合结果一览")
    lines.append("")
    lines.append("| 物种 | 产品 | 2025分 | 档 | 2025事件 | 2025线索 | 2026落地区实购 | 线索命中 | 精确率 | 新单位 |")
    lines.append("|---|---|---:|:---:|---:|---:|---:|---:|---:|---:|")
    for row in payload["combos"]:
        for m in row["metrics"]["by_product"]:
            lines.append(
                f"| {row['species_name']} | {m['display_name']} | {m.get('train_score')} | {m.get('train_band')} | "
                f"{row['train']['events']} | {m.get('pred_leads')} | {m.get('val_action_units')} | "
                f"{m.get('hit_count')} | {m.get('precision') if m.get('precision') is not None else '-'} | "
                f"{m.get('new_action_count')} |"
            )
    lines.append("")
    for tip in payload["advice"]:
        lines.append(tip)
    lines.append("")
    lines.append("## 命中明细（训练线索 ∩ 2026落地区实购）")
    for row in payload["combos"]:
        for m in row["metrics"]["by_product"]:
            if m.get("hits"):
                lines.append(f"- {row['species_name']}×{m['display_name']}: {', '.join(m['hits'])}")
    lines.append("")
    lines.append("## 2026 落地区新出现单位（样本）")
    for row in payload["combos"]:
        for m in row["metrics"]["by_product"]:
            if m.get("new_action_units_2026"):
                lines.append(
                    f"- {row['species_name']}×{m['display_name']}: "
                    + ", ".join(m["new_action_units_2026"][:8])
                )
    lines.append("")
    lines.append(f"_生成于 {datetime.now().isoformat(timespec='seconds')}_")

    path = os.path.join(out_dir, "report.md")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return path


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--train-begin", default="2025-01-01")
    p.add_argument("--train-end", default="2025-12-31")
    p.add_argument("--val-begin", default="2026-04-01")
    p.add_argument("--val-end", default="2026-06-30")
    p.add_argument("--train-budget", type=int, default=700)
    p.add_argument("--val-budget", type=int, default=300)
    p.add_argument("--species", default=",".join(SPECIES_IDS))
    p.add_argument("--products", default=",".join(PRODUCT_IDS))
    args = p.parse_args(argv)

    species_ids = [x.strip() for x in args.species.split(",") if x.strip()]
    product_ids = [x.strip() for x in args.products.split(",") if x.strip()]
    packs = [load_pack(pid) for pid in product_ids]
    species_list = [load_species(sid) for sid in species_ids]

    train_recs, train_pull = pull_window(
        packs, species_list, args.train_begin, args.train_end, args.train_budget, "TRAIN2025"
    )
    val_recs, val_pull = pull_window(
        packs, species_list, args.val_begin, args.val_end, args.val_budget, "VAL2026Q2"
    )

    combos = []
    for sp in species_list:
        print(f"\n--- analyze species={sp.species_id} ---")
        train = analyze_combo(train_recs, sp, packs, DISCOVERY, ACTION)
        val = analyze_combo(val_recs, sp, packs, DISCOVERY, ACTION)
        metrics = validate_against(train, val, packs)
        print(
            f"  train structured={train['structured']} events={train['events']} leads={len(train['leads'])} | "
            f"val structured={val['structured']} events={val['events']}"
        )
        for m in metrics["by_product"]:
            print(
                f"    {m['product_pack']}: score={m['train_score']} pred={m['pred_leads']} "
                f"val_action={m['val_action_units']} hits={m['hit_count']} new={m['new_action_count']}"
            )
        # strip bulky lists for top-level json readability but keep essentials
        train_slim = {k: v for k, v in train.items() if k not in ("leads",)}
        train_slim["leads_n"] = len(train["leads"])
        train_slim["lead_buyers"] = [
            {"buyer": l.get("buyer"), "region": l.get("region"), "type": l.get("lead_type"),
             "gaps": l.get("gap_products")}
            for l in train["leads"][:40]
        ]
        val_slim = {k: v for k, v in val.items() if k not in ("leads", "scores")}
        combos.append({
            "species_id": sp.species_id,
            "species_name": sp.display_name,
            "train": train_slim,
            "validate": val_slim,
            "metrics": metrics,
            "train_leads_full": train["leads"][:40],
        })

    advice = advice_from_results(combos)
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_temporal"
    out_dir = os.path.join(REPO_DIR, "fold_runs", run_id)
    payload = {
        "train_begin": args.train_begin,
        "train_end": args.train_end,
        "val_begin": args.val_begin,
        "val_end": args.val_end,
        "action": ACTION,
        "discovery_seed": DISCOVERY,
        "species": species_ids,
        "products": product_ids,
        "train_pull": train_pull,
        "val_pull": val_pull,
        "combos": combos,
        "advice": advice,
    }
    report = write_report(out_dir, payload)
    print(f"\nDONE report={report}")
    print(f"out_dir={out_dir}")
    return out_dir


if __name__ == "__main__":
    main()
