#!/usr/bin/env python3
"""Timing + price + quantity overlay for opportunity scores.

Uses local scout_data (money) + existing volume成交池 (dates/species).
No API required (quota may be zero).
"""
from __future__ import annotations

import json
import os
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime
from statistics import median
from typing import Dict, List, Optional, Tuple

KG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO_DIR = os.path.dirname(KG_DIR)
if KG_DIR not in sys.path:
    sys.path.insert(0, KG_DIR)

from fold.ingest import load_local_records
from fold.pack_loader import load_pack
from fold.species_loader import load_species, match_species, infer_level
from fold.structure import hit_tier, _year_month, _amount_bucket

ACTION = ["陕西", "甘肃"]
SPECIES_IDS = ["court", "procuratorate", "police", "agriculture"]
BAND_LEGEND = "高 ≥60% ｜ 中 35%–59% ｜ 低 <35%"

# 碎纸机典型单价（万）— 用于无「台」字样时的台数回推
DEFAULT_UNIT_WAN = {
    "court": 0.9,
    "procuratorate": 0.5,
    "police": 0.3,
    "agriculture": 0.25,
    "other": 0.25,
}

PRICE_TIERS = [
    ("入门 <0.3万", 0, 0.3),
    ("常用 0.3–0.8万", 0.3, 0.8),
    ("机关主力 0.8–1.5万", 0.8, 1.5),
    ("批量/中高 1.5–5万", 1.5, 5.0),
    ("项目级 ≥5万", 5.0, 1e9),
]


def score_band(score: float) -> Tuple[str, str]:
    if score >= 60:
        return "高", "≥60%"
    if score >= 35:
        return "中", "35%–59%"
    return "低", "<35%"


def parse_qty(title: str, money_wan: float, species_id: Optional[str], hit_tier: str = "target") -> Tuple[int, str]:
    """Return (qty, method). Prefer explicit 台; else estimate only for shredder-primary titles."""
    t = title or ""
    ms = re.findall(r"(\d+)\s*台", t)
    if ms:
        vals = [int(x) for x in ms if 0 < int(x) < 500]
        if vals:
            return max(vals), "title_台"
    ms = re.findall(r"(\d+)\s*套", t)
    if ms:
        vals = [int(x) for x in ms if 0 < int(x) < 500]
        if vals:
            return max(vals), "title_套"

    # 整包办公设备/家具：金额不能当成碎纸机台数
    bundle_hints = ("办公设备", "办公家具", "一批", "一批次", "电子产品", "信息化")
    shredder_primary = any(k in t for k in ("碎纸机", "碎纸设备", "保密碎纸"))
    if any(h in t for h in bundle_hints) and not (shredder_primary and "碎纸机" in t and "办公设备" not in t):
        if shredder_primary and sum(1 for h in bundle_hints if h in t) >= 1:
            return 1, "bundle_cap_1"

    if hit_tier not in ("target", "near"):
        return 1, "default_1"

    unit = DEFAULT_UNIT_WAN.get(species_id or "other", DEFAULT_UNIT_WAN["other"])
    # 仅当标题以碎纸为主且金额合理时回推
    if shredder_primary and money_wan and unit and money_wan >= unit * 1.8 and money_wan <= 20:
        est = max(1, int(round(money_wan / unit)))
        return min(est, 80), "money_estimate"
    return 1, "default_1"


def price_tier_name(money_wan: float) -> str:
    if money_wan <= 0:
        return "金额未知"
    for name, lo, hi in PRICE_TIERS:
        if lo <= money_wan < hi:
            return name
    return PRICE_TIERS[-1][0]


def load_shredder_events() -> List[dict]:
    pack = load_pack("shredder")
    species_list = [load_species(s) for s in SPECIES_IDS]
    recs, _ = load_local_records(
        ["碎纸机", "保密碎纸机", "办公碎纸机", "碎纸设备"],
        ACTION + ["安徽", "浙江", "北京", "上海", "江苏", "山东", "河南", "四川", "湖北", "湖南", "广东", "全国"],
    )
    events = []
    seen = set()
    for r in recs:
        title = r.get("title") or ""
        tier, kw = hit_tier(title, pack)
        if tier in ("none", "confuse"):
            continue
        buyers = r.get("buyers") or []
        buyer = buyers[0] if buyers else ""
        key = f"{r.get('source_id')}|{title}|{buyer}"
        if key in seen:
            continue
        seen.add(key)
        sp_id = None
        sp_name = None
        level = "其他"
        for sp in species_list:
            if match_species(buyer, title, sp):
                sp_id = sp.species_id
                sp_name = sp.display_name
                level = infer_level(buyer, sp)
                break
        money = float(r.get("money_wan") or 0)
        qty, qty_method = parse_qty(title, money, sp_id, tier)
        ym = _year_month(r.get("publish_time") or "")
        month = int(ym.split("-")[1]) if ym and "-" in ym else None
        unit = round(money / qty, 3) if money and qty else 0.0
        events.append({
            "buyer": buyer,
            "region": r.get("region"),
            "title": title,
            "hit_tier": tier,
            "matched_keyword": kw,
            "species_id": sp_id or "other",
            "species": sp_name or "其他单位",
            "level": level,
            "money_wan": money,
            "qty": qty,
            "qty_method": qty_method,
            "unit_price_wan": unit,
            "price_tier": price_tier_name(money if money else unit),
            "amount_bucket": _amount_bucket(money),
            "ym": ym,
            "month": month,
            "date": r.get("publish_time") or "",
            "source": "local",
            "in_action": (r.get("region") in ACTION),
        })

    # Enrich with volume成交池 (species+date denser; money often missing)
    vol_path = os.path.join(REPO_DIR, "fold_runs", "20260711_155538_volume", "volume_result.json")
    if os.path.exists(vol_path):
        vol = json.load(open(vol_path, encoding="utf-8"))
        for l in vol.get("leads_by_product", {}).get("shredder", []):
            buyer = l.get("buyer") or ""
            title = l.get("evidence_title") or ""
            key = f"vol|{l.get('region')}|{buyer}|{title[:40]}"
            if key in seen:
                continue
            seen.add(key)
            # try match money from local same buyer
            money = 0.0
            for e in events:
                if e["buyer"] == buyer and e["money_wan"] > 0:
                    money = e["money_wan"]
                    break
            sp_id = l.get("species_id") or "other"
            sp_name = {
                "court": "法院", "procuratorate": "检察院",
                "police": "公安局", "agriculture": "农业局",
            }.get(sp_id, "其他单位")
            qty, qty_method = parse_qty(title, money, sp_id, "target")
            ym = _year_month(l.get("date") or "")
            month = int(ym.split("-")[1]) if ym and "-" in ym else None
            unit = round(money / qty, 3) if money and qty else 0.0
            events.append({
                "buyer": buyer,
                "region": l.get("region"),
                "title": title,
                "hit_tier": "target",
                "matched_keyword": "碎纸机",
                "species_id": sp_id,
                "species": sp_name,
                "level": l.get("level") or "其他",
                "money_wan": money,
                "qty": qty,
                "qty_method": qty_method if money else "default_1",
                "unit_price_wan": unit,
                "price_tier": price_tier_name(money) if money else "金额未知",
                "amount_bucket": _amount_bucket(money),
                "ym": ym,
                "month": month,
                "date": l.get("date") or "",
                "source": "volume_pool",
                "in_action": (l.get("region") in ACTION),
            })
    return events


def monthly_stats(events: List[dict]) -> Dict[int, dict]:
    by_m: Dict[int, List[dict]] = defaultdict(list)
    for e in events:
        if e.get("month"):
            by_m[e["month"]].append(e)
    out = {}
    for m in range(1, 13):
        rows = by_m.get(m, [])
        qty = sum(e["qty"] for e in rows)
        deals = len(rows)
        money = sum(e["money_wan"] for e in rows if e["money_wan"] > 0)
        out[m] = {
            "month": m,
            "deals": deals,
            "qty": qty,
            "money_wan": round(money, 2),
            "buyers": len({e["buyer"] for e in rows if e.get("buyer")}),
        }
    return out


def season_index(monthly: Dict[int, dict], key: str = "qty") -> Dict[int, float]:
    vals = [monthly[m][key] for m in range(1, 13)]
    avg = (sum(vals) / 12.0) or 1.0
    return {m: round(monthly[m][key] / avg, 3) for m in range(1, 13)}


def timing_adjusted_score(base: float, month: int, idx: Dict[int, float]) -> dict:
    """base 0-100 opportunity × season factor → timing score."""
    s = idx.get(month, 1.0)
    # normalize: peak month ~1.5–3x avg → map into multiplier 0.7–1.35
    mult = 0.7 + 0.35 * min(max(s, 0), 3.0) / 1.5
    mult = round(min(1.4, max(0.55, mult)), 3)
    timed = round(min(100.0, base * mult), 1)
    band, br = score_band(timed)
    return {
        "month": month,
        "season_index": s,
        "timing_multiplier": mult,
        "base_score": base,
        "timing_score": timed,
        "timing_score_pct": f"{timed:.1f}%",
        "band": band,
        "band_range": br,
    }


def species_price_profile(events: List[dict]) -> List[dict]:
    rows = []
    for sid in SPECIES_IDS + ["other"]:
        subset = [e for e in events if e["species_id"] == sid]
        if not subset:
            continue
        priced = [e for e in subset if e["money_wan"] > 0]
        amounts = sorted(e["money_wan"] for e in priced)
        units = sorted(e["unit_price_wan"] for e in priced if e["unit_price_wan"] > 0)
        tier_c = Counter(e["price_tier"] for e in subset)
        qty_sum = sum(e["qty"] for e in subset)
        name = subset[0]["species"]
        # recommend price band from p25–p75 unit or money
        if units:
            lo, hi = units[len(units) // 4], units[3 * len(units) // 4]
            rec = f"{lo:.2f}–{hi:.2f}万/台（样例分位）"
            tip_money = median(units)
        elif amounts:
            lo, hi = amounts[len(amounts) // 4], amounts[3 * len(amounts) // 4]
            rec = f"单笔 {lo:.2f}–{hi:.2f}万"
            tip_money = median(amounts)
        else:
            rec = DEFAULT_UNIT_WAN.get(sid, 0.25)
            rec = f"参考默认 ~{rec}万/台（缺金额样本）"
            tip_money = DEFAULT_UNIT_WAN.get(sid, 0.25)
        rows.append({
            "species_id": sid,
            "species": name,
            "deals": len(subset),
            "qty_total": qty_sum,
            "priced_deals": len(priced),
            "money_p50": round(median(amounts), 3) if amounts else None,
            "unit_p50": round(median(units), 3) if units else None,
            "tier_counts": dict(tier_c),
            "recommend_price": rec,
            "tip_unit_wan": round(float(tip_money), 3),
            "month_hist": dict(Counter(e["month"] for e in subset if e.get("month"))),
        })
    rows.sort(key=lambda x: -x["qty_total"])
    return rows


def forecast_windows(monthly: Dict[int, dict], idx: Dict[int, float]) -> List[dict]:
    """Recommend push windows with expected qty (historical same-month)."""
    windows = [
        ("7月", [7]),
        ("8–9月", [8, 9]),
        ("11月", [11]),
        ("11–12月（年底）", [11, 12]),
        ("5–6月（本地旺季）", [5, 6]),
    ]
    out = []
    for name, months in windows:
        deals = sum(monthly[m]["deals"] for m in months)
        qty = sum(monthly[m]["qty"] for m in months)
        avg_idx = sum(idx[m] for m in months) / len(months)
        # forecast next cycle ≈ historical qty (same months); low-sample → flag
        conf = "高" if deals >= 30 else ("中" if deals >= 8 else "低")
        out.append({
            "window": name,
            "months": months,
            "hist_deals": deals,
            "hist_qty": qty,
            "forecast_qty": qty,  # 同月历史台数作为下轮期望
            "season_index_avg": round(avg_idx, 2),
            "confidence": conf,
        })
    out.sort(key=lambda x: (-x["season_index_avg"], -x["hist_qty"]))
    return out


def build_deal_pool_table(events: List[dict], limit: int = 80) -> List[dict]:
    """成交池明细：价位 + 台数."""
    events_sorted = sorted(
        events,
        key=lambda x: (
            0 if x.get("in_action") else 1,
            0 if x.get("money_wan") else 1,
            -(x.get("money_wan") or 0),
            x.get("date") or "",
        ),
    )
    rows = []
    for e in events_sorted[:limit]:
        rows.append({
            "buyer": e["buyer"],
            "region": e["region"],
            "species": e["species"],
            "date": (e.get("date") or "")[:10],
            "money_wan": e["money_wan"],
            "qty": e["qty"],
            "qty_method": e["qty_method"],
            "unit_price_wan": e["unit_price_wan"],
            "price_tier": e["price_tier"],
            "title": (e.get("title") or "")[:60],
        })
    return rows


def write_html(path: str, payload: dict):
    months = list(range(1, 13))
    qty_line = [payload["monthly"][str(m)]["qty"] for m in months]
    score_line = [payload["timing_scores"][str(m)]["timing_score"] for m in months]
    idx_line = [payload["season_index"][str(m)] for m in months]

    win_rows = "".join(
        f"<tr><td>{w['window']}</td><td class='num'>{w['season_index_avg']}</td>"
        f"<td class='num'>{w['hist_deals']}</td><td class='num'>{w['hist_qty']}</td>"
        f"<td class='num'><b>{w['forecast_qty']}</b></td><td>{w['confidence']}</td>"
        f"<td>{w['verdict']}</td></tr>"
        for w in payload["windows"]
    )
    sp_rows = "".join(
        f"<tr><td>{s['species']}</td><td class='num'>{s['deals']}</td>"
        f"<td class='num'>{s['qty_total']}</td><td class='num'>{s['priced_deals']}</td>"
        f"<td class='num'>{s['money_p50'] if s['money_p50'] is not None else '-'}</td>"
        f"<td class='num'>{s['unit_p50'] if s['unit_p50'] is not None else '-'}</td>"
        f"<td><b>{s['recommend_price']}</b></td></tr>"
        for s in payload["species_prices"]
    )
    pool_rows = "".join(
        f"<tr><td>{r['buyer']}</td><td>{r['region']}</td><td>{r['species']}</td>"
        f"<td>{r['date']}</td><td class='num'>{r['money_wan'] or '-'}</td>"
        f"<td class='num'>{r['qty']}</td><td>{r['price_tier']}</td></tr>"
        for r in payload["deal_pool"][:60]
    )
    tier_rows = "".join(
        f"<tr><td>{t['tier']}</td><td class='num'>{t['deals']}</td>"
        f"<td class='num'>{t['qty']}</td><td class='num'>{t['pct']}%</td></tr>"
        for t in payload["tier_summary"]
    )

    html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>碎纸机 · 时机×价位×台数</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<style>
:root{{--ink:#1a1f2e;--muted:#5c6578;--line:#e2e6ef;--bg:#f4f2ec;--paper:#fffcf7;--accent:#0d5c63;--go:#1b5e3b}}
body{{margin:0;font-family:"PingFang SC","Noto Sans SC",sans-serif;color:var(--ink);background:var(--bg)}}
.wrap{{max-width:1100px;margin:0 auto;padding:36px 20px 80px}}
h1{{font-family:"Songti SC",serif;font-size:2rem;margin:0 0 8px}}
h2{{font-family:"Songti SC",serif;margin:32px 0 12px;font-size:1.25rem}}
.meta{{color:var(--muted);font-size:14px}}
.legend{{background:#e8f3f3;padding:12px 14px;border-radius:4px;margin:12px 0;font-size:14px}}
.callout{{border-left:3px solid var(--accent);padding:10px 14px;background:#eef7f7;margin:12px 0;font-size:14px}}
.go{{border-left-color:var(--go);background:#e3f2ea}}
.charts{{display:grid;gap:16px}}
@media(min-width:900px){{.charts{{grid-template-columns:1fr 1fr}}}}
.chart-box{{background:var(--paper);border:1px solid var(--line);padding:14px;border-radius:4px}}
.card{{background:var(--paper);border:1px solid var(--line);padding:14px;border-radius:4px;overflow-x:auto;margin:12px 0}}
table{{width:100%;border-collapse:collapse;font-size:13px}}
th,td{{padding:8px 10px;border-bottom:1px solid var(--line);text-align:left}}
th{{background:#eef2f0;color:var(--muted);font-size:12px}}
.num{{text-align:right;font-variant-numeric:tabular-nums}}
.verdict{{font-weight:600;color:var(--go)}}
</style></head><body><div class="wrap">
<h1>碎纸机 · 何时推 / 推什么价 / 多少台</h1>
<p class="meta">机会分叠加时间要素 · 成交池含价位与台数 · 数据：本地标讯金额 + 成交池物种日期（知了网额度已用尽，未再拉新）</p>
<div class="legend"><b>档位：</b>{BAND_LEGEND} · 时机分 = 基础机会分 × 季节乘数</div>

<div class="callout go">
<b>直接回答你的问题：</b><br/>
推窗排序（按季节指数）：<b>{payload['best_window']}</b>。<br/>
7月 vs 8–9月 vs 11月：见下表「窗口对比」。陕甘本地金额样本旺在 <b>5–6月</b>；成交池抽样偏 <b>11–12月</b> 年底直购。<br/>
价位：法院约 <b>0.8–1.5万</b>；检察约 <b>0.3–0.8万</b>；多数公开单 <b>&lt;1万 / 1台</b>。
</div>

<h2>窗口对比：7月 / 8–9月 / 11月</h2>
<div class="card"><table>
<thead><tr><th>窗口</th><th>季节指数</th><th>历史成交笔数</th><th>历史台数</th><th>下轮期望台数</th><th>置信</th><th>建议</th></tr></thead>
<tbody>{win_rows}</tbody></table>
<p style="font-size:12px;color:#5c6578">期望台数 = 历史同月台数合计（作为下一轮同窗预测）；置信取决于样本笔数。</p>
</div>

<h2>时机分曲线（基础分按碎纸机中档 42 起算）</h2>
<div class="charts">
<div class="chart-box"><h3>月度台数（成交池+本地）</h3><canvas id="qtyChart" height="220"></canvas></div>
<div class="chart-box"><h3>时机机会分 %（叠加季节）</h3><canvas id="scoreChart" height="220"></canvas></div>
</div>

<h2>什么系统推什么价</h2>
<div class="card"><table>
<thead><tr><th>系统</th><th>成交笔数</th><th>台数合计</th><th>有金额</th><th>金额中位(万)</th><th>单价中位(万)</th><th>建议推价</th></tr></thead>
<tbody>{sp_rows}</tbody></table></div>

<h2>价位带 × 台数</h2>
<div class="card"><table>
<thead><tr><th>价位带</th><th>笔数</th><th>台数</th><th>占比</th></tr></thead>
<tbody>{tier_rows}</tbody></table></div>

<h2>成交池明细（价位 · 台数）</h2>
<div class="card"><table>
<thead><tr><th>买方</th><th>省</th><th>系统</th><th>日期</th><th>金额(万)</th><th>台数</th><th>价位带</th></tr></thead>
<tbody>{pool_rows}</tbody></table>
<p style="font-size:12px;color:#5c6578">台数：标题含「N台」则用原文；否则按金额/物种默认单价回推，或记 1 台。</p>
</div>

<p class="meta">生成于 {payload['generated_at']} · 合计笔数 {payload['totals']['deals']} · 台数 {payload['totals']['qty']} · 有金额 {payload['totals']['priced']}</p>
</div>
<script>
const months = {json.dumps([f"{m}月" for m in months])};
const qty = {json.dumps(qty_line)};
const scores = {json.dumps(score_line)};
const idx = {json.dumps(idx_line)};
new Chart(document.getElementById('qtyChart'), {{
  type:'line',
  data:{{ labels:months, datasets:[
    {{label:'台数', data:qty, borderColor:'#0d5c63', tension:0.25, pointRadius:3}},
    {{label:'季节指数', data:idx, borderColor:'#8a4b08', borderDash:[4,3], tension:0.25, yAxisID:'y1'}}
  ]}},
  options:{{ plugins:{{legend:{{position:'bottom'}}}},
    scales:{{
      y:{{ title:{{display:true,text:'台数'}}, beginAtZero:true }},
      y1:{{ position:'right', title:{{display:true,text:'季节指数'}}, grid:{{drawOnChartArea:false}} }},
      x:{{ title:{{display:true,text:'月份'}} }}
    }}
  }}
}});
new Chart(document.getElementById('scoreChart'), {{
  type:'line',
  data:{{ labels:months, datasets:[
    {{label:'时机机会分%', data:scores, borderColor:'#3d4f7c', tension:0.25, fill:false, pointRadius:3}}
  ]}},
  options:{{ plugins:{{legend:{{position:'bottom'}}}},
    scales:{{
      y:{{ title:{{display:true,text:'机会分 (%)'}}, min:0, max:100 }},
      x:{{ title:{{display:true,text:'月份'}} }}
    }}
  }}
}});
</script></body></html>"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)


def main():
    events = load_shredder_events()
    monthly = monthly_stats(events)
    idx = season_index(monthly, "qty")
    base = 42.0  # shredder mid-band from prior portfolio scores
    timing_scores = {m: timing_adjusted_score(base, m, idx) for m in range(1, 13)}

    windows = forecast_windows(monthly, idx)
    # verdicts for the three user-asked windows
    asked = {"7月", "8–9月", "11月"}
    for w in windows:
        if w["window"] == "7月":
            w["verdict"] = "可跟尾单，不宜当主攻月" if w["hist_qty"] < windows[0]["hist_qty"] else "可推"
        elif w["window"] == "8–9月":
            w["verdict"] = "样本近空 → 不主推（除非补数）"
        elif w["window"] == "11月":
            w["verdict"] = "年底窗口，可主推之一"
        elif "5–6月" in w["window"]:
            w["verdict"] = "陕甘本地旺季 · 首选"
        elif "11–12月" in w["window"]:
            w["verdict"] = "年底采购 · 次选/并列"
        else:
            w["verdict"] = ""

    species_prices = species_price_profile(events)
    deal_pool = build_deal_pool_table(events, limit=100)

    tier_c = Counter()
    tier_qty = Counter()
    for e in events:
        tier_c[e["price_tier"]] += 1
        tier_qty[e["price_tier"]] += e["qty"]
    total_deals = max(len(events), 1)
    tier_summary = []
    for name, _, _ in PRICE_TIERS + [("金额未知", 0, 0)]:
        if name == "金额未知" or tier_c[name] or tier_qty[name]:
            tier_summary.append({
                "tier": name,
                "deals": tier_c[name],
                "qty": tier_qty[name],
                "pct": round(100 * tier_c[name] / total_deals, 1),
            })
    # dedupe unknown
    seen = set()
    tier_summary2 = []
    for t in tier_summary:
        if t["tier"] in seen:
            continue
        seen.add(t["tier"])
        if t["deals"] or t["qty"]:
            tier_summary2.append(t)

    best = max(windows, key=lambda x: (x["season_index_avg"], x["hist_qty"]))
    payload = {
        "product": "碎纸机",
        "band_legend": BAND_LEGEND,
        "base_score": base,
        "monthly": {str(k): v for k, v in monthly.items()},
        "season_index": {str(k): v for k, v in idx.items()},
        "timing_scores": {str(k): v for k, v in timing_scores.items()},
        "windows": windows,
        "best_window": f"{best['window']}（期望约 {best['forecast_qty']} 台量级）",
        "species_prices": species_prices,
        "deal_pool": deal_pool,
        "tier_summary": tier_summary2,
        "totals": {
            "deals": len(events),
            "qty": sum(e["qty"] for e in events),
            "priced": sum(1 for e in events if e["money_wan"] > 0),
            "action_deals": sum(1 for e in events if e["in_action"]),
        },
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "data_note": "本地scout金额样本 + volume成交池日期；API额度0未刷新月度全市场",
    }

    run_id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_timing_price"
    out_dir = os.path.join(REPO_DIR, "fold_runs", run_id)
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "timing_price_result.json"), "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2, default=str)
    html_path = os.path.join(out_dir, "report.html")
    write_html(html_path, payload)

    print("events", payload["totals"])
    print("season_index", idx)
    print("windows:")
    for w in windows:
        print(" ", w["window"], "idx", w["season_index_avg"], "qty", w["hist_qty"], w["verdict"])
    print("species:")
    for s in species_prices:
        print(" ", s["species"], "qty", s["qty_total"], "rec", s["recommend_price"])
    print("DONE", html_path)
    return out_dir, html_path


if __name__ == "__main__":
    main()
