"""Resolve monorepo vs skill-bundled layout.

Layouts:
1) Monorepo:
   <REPO>/kg_engine/fold/
   <REPO>/skills/procurement-fold/{product_packs,species_packs,config}/

2) Bundled (WorkBuddy / CodeBuddy one-click):
   <SKILL>/kg_engine/fold/
   <SKILL>/{product_packs,species_packs,config,SKILL.md}/
"""
from __future__ import annotations

import os
from functools import lru_cache
from typing import Dict


@lru_cache(maxsize=1)
def layout() -> Dict[str, str]:
    kg_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    parent = os.path.dirname(kg_dir)

    bundled_skill = os.path.join(parent, "SKILL.md")
    bundled_packs = os.path.join(parent, "product_packs")
    if os.path.isfile(bundled_skill) and os.path.isdir(bundled_packs):
        skill = parent
        return {
            "mode": "bundled",
            "kg_dir": kg_dir,
            "repo_dir": parent,
            "skill_dir": skill,
            "pack_root": os.path.join(skill, "product_packs"),
            "species_root": os.path.join(skill, "species_packs"),
            "gate_yaml": os.path.join(skill, "config", "acquisition_gate.yaml"),
            "scout_dir": os.path.join(parent, "scout_data"),
            "fold_runs": os.path.join(parent, "fold_runs"),
        }

    skill = os.path.join(parent, "skills", "procurement-fold")
    return {
        "mode": "monorepo",
        "kg_dir": kg_dir,
        "repo_dir": parent,
        "skill_dir": skill,
        "pack_root": os.path.join(skill, "product_packs"),
        "species_root": os.path.join(skill, "species_packs"),
        "gate_yaml": os.path.join(skill, "config", "acquisition_gate.yaml"),
        "scout_dir": os.path.join(parent, "scout_data"),
        "fold_runs": os.path.join(parent, "fold_runs"),
    }
