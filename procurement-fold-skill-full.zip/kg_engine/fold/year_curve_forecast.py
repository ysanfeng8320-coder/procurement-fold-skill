#!/usr/bin/env python3
"""Full 1–12 month curves: 2025 actual + 2026 forecast.

Money unit: 千元 (1万=10千). Covers species × price tier × SKU × growth.
Uses volume成交池(2025) + local scout(金额, 多为2026实绩).
"""
from __future__ import annotations

import json
import os
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime
from statistics import median
from typing import Dict, List, Optional, Tuple

KG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO_DIR = os.path.dirname(KG_DIR)
if KG_DIR not in sys.path:
    sys.path.insert(0, KG_DIR)

from fold.ingest import load_local_records
from fold.pack_loader import load_pack
from fold.species_loader import load_species, match_species, infer_level
from fold.structure import hit_tier, _year_month

ACTION = ["陕西", "甘肃"]
SPECIES_IDS = ["court", "procuratorate", "police", "agriculture"]
PRODUCT_IDS = ["shredder", "copier", "binding_machine", "seal_control"]

# 默认单价（千元/台）
DEFAULT_UNIT_QIAN = {
    "shredder": {"court": 9.9, "procuratorate": 4.8, "police": 0.9, "agriculture": 2.5, "other": 2.0},
    "copier": {"court": 15.0, "procuratorate": 12.0, "police": 10.0, "agriculture": 8.0, "other": 8.0},
    "binding_machine": {"court": 8.0, "procuratorate": 6.0, "police": 5.0, "agriculture": 4.0, "other": 4.0},
    "seal_control": {"court": 30.0, "procuratorate": 25.0, "police": 20.0, "agriculture": 15.0, "other": 20.0},
}

PRICE_TIERS_QIAN = [
    ("入门 <3千", 0, 3),
    ("常用 3–8千", 3, 8),
    ("机关主力 8–15千", 8, 15),
    ("中高 15–50千", 15, 50),
    ("项目级 ≥50千", 50, 1e12),
]

SPECIES_NAME = {
    "court": "法院", "procuratorate": "检察院", "police": "公安局",
    "agriculture": "农业局", "other": "其他单位",
}


def wan_to_qian(wan: float) -> float:
    return round(float(wan or 0) * 10.0, 2)


def price_tier(qian: float) -> str:
    if qian <= 0:
        return "金额未知"
    for name, lo, hi in PRICE_TIERS_QIAN:
        if lo <= qian < hi:
            return name
    return PRICE_TIERS_QIAN[-1][0]


def parse_qty(title: str, money_qian: float, product_id: str, species_id: str, hit: str) -> Tuple[int, str]:
    t = title or ""
    ms = re.findall(r"(\d+)\s*台", t)
    if ms:
        vals = [int(x) for x in ms if 0 < int(x) < 500]
        if vals:
            return max(vals), "title_台"
    ms = re.findall(r"(\d+)\s*套", t)
    if ms:
        vals = [int(x) for x in ms if 0 < int(x) < 500]
        if vals:
            return max(vals), "title_套"
    bundle = ("办公设备", "办公家具", "信息化", "一批")
    primary = {
        "shredder": ("碎纸机", "碎纸设备"),
        "copier": ("复印机", "多功能一体机", "复合机", "数码复印"),
        "binding_machine": ("装订机", "胶装机"),
        "seal_control": ("印控仪", "智能印章", "盖章机", "用印宝", "电子印章"),
        "signal_shield": ("信号屏蔽器", "信号屏蔽"),
        "rubber_track": ("塑胶跑道", "塑胶场地"),
    }.get(product_id, ())
    is_primary = any(k in t for k in primary)
    if any(b in t for b in bundle) and not (is_primary and "办公设备" not in t):
        return 1, "bundle_cap_1"
    if hit not in ("target", "near") or not is_primary:
        return 1, "default_1"
    unit = DEFAULT_UNIT_QIAN.get(product_id, {}).get(species_id or "other", 5.0)
    if money_qian and unit and money_qian >= unit * 1.8 and money_qian <= 200:
        est = max(1, int(round(money_qian / unit)))
        return min(est, 80), "money_estimate"
    return 1, "default_1"


def load_all_events() -> List[dict]:
    packs = {pid: load_pack(pid) for pid in PRODUCT_IDS}
    species_list = [load_species(s) for s in SPECIES_IDS]
    events: List[dict] = []
    seen = set()

    # 1) local scout with money
    kw_map = {
        "shredder": ["碎纸机", "保密碎纸机", "办公碎纸机"],
        "copier": ["复印机", "多功能一体机", "复合机", "数码复印机"],
        "binding_machine": ["装订机", "胶装机", "财务装订机"],
        "seal_control": ["印控仪", "智能印章", "盖章机", "用印宝", "电子印章"],
    }
    regions = ACTION + ["安徽", "浙江", "北京", "上海", "江苏", "山东", "河南", "四川", "湖北", "湖南", "广东", "全国"]
    for pid, kws in kw_map.items():
        recs, _ = load_local_records(kws, regions)
        pack = packs[pid]
        for r in recs:
            title = r.get("title") or ""
            tier, kw = hit_tier(title, pack)
            if tier in ("none", "confuse"):
                continue
            buyers = r.get("buyers") or []
            buyer = buyers[0] if buyers else ""
            key = f"local|{pid}|{r.get('source_id')}|{title[:50]}|{buyer}"
            if key in seen:
                continue
            seen.add(key)
            sp_id = "other"
            for sp in species_list:
                if match_species(buyer, title, sp):
                    sp_id = sp.species_id
                    break
            money_qian = wan_to_qian(r.get("money_wan") or 0)
            qty, qmethod = parse_qty(title, money_qian, pid, sp_id, tier)
            unit = round(money_qian / qty, 2) if money_qian and qty else 0.0
            ym = _year_month(r.get("publish_time") or "")
            year = int(ym[:4]) if ym and len(ym) >= 4 and ym[:4].isdigit() else None
            month = int(ym.split("-")[1]) if ym and "-" in ym else None
            events.append({
                "product_id": pid,
                "product": pack.canonical_product,
                "buyer": buyer,
                "region": r.get("region"),
                "species_id": sp_id,
                "species": SPECIES_NAME.get(sp_id, "其他单位"),
                "title": title,
                "money_qian": money_qian,
                "qty": qty,
                "qty_method": qmethod,
                "unit_qian": unit,
                "price_tier": price_tier(money_qian if money_qian else unit),
                "ym": ym,
                "year": year,
                "month": month,
                "date": r.get("publish_time") or "",
                "source": "local",
                "hit_tier": tier,
            })

    # 2) volume pool 2025 (species dense)
    vol_path = os.path.join(REPO_DIR, "fold_runs", "20260711_155538_volume", "volume_result.json")
    if os.path.exists(vol_path):
        vol = json.load(open(vol_path, encoding="utf-8"))
        for pid, leads in (vol.get("leads_by_product") or {}).items():
            if pid not in packs:
                continue
            pack = packs[pid]
            for l in leads:
                buyer = l.get("buyer") or ""
                title = l.get("evidence_title") or ""
                key = f"vol|{pid}|{l.get('region')}|{buyer}|{title[:40]}"
                if key in seen:
                    continue
                seen.add(key)
                sp_id = l.get("species_id") or "other"
                # join money from local same buyer+product
                money_qian = 0.0
                for e in events:
                    if e["product_id"] == pid and e["buyer"] == buyer and e["money_qian"] > 0:
                        money_qian = e["money_qian"]
                        break
                if money_qian <= 0:
                    # default unit as deal value proxy (1台)
                    money_qian = DEFAULT_UNIT_QIAN.get(pid, {}).get(sp_id, 5.0)
                    qmethod_force = "default_unit_fill"
                else:
                    qmethod_force = None
                qty, qmethod = parse_qty(title, money_qian, pid, sp_id, "target")
                if qmethod_force:
                    qmethod = qmethod_force
                    qty = 1
                    unit = money_qian
                else:
                    unit = round(money_qian / qty, 2) if money_qian and qty else 0.0
                ym = _year_month(l.get("date") or "")
                year = int(ym[:4]) if ym and len(ym) >= 4 and ym[:4].isdigit() else 2025
                month = int(ym.split("-")[1]) if ym and "-" in ym else None
                events.append({
                    "product_id": pid,
                    "product": pack.canonical_product,
                    "buyer": buyer,
                    "region": l.get("region"),
                    "species_id": sp_id,
                    "species": SPECIES_NAME.get(sp_id, "其他单位"),
                    "title": title,
                    "money_qian": money_qian,
                    "qty": qty,
                    "qty_method": qmethod,
                    "unit_qian": unit,
                    "price_tier": price_tier(money_qian if money_qian else unit),
                    "ym": ym,
                    "year": year,
                    "month": month,
                    "date": l.get("date") or "",
                    "source": "volume_2025",
                    "hit_tier": "target",
                })
    return events


def month_matrix(events: List[dict], year: Optional[int]) -> Dict[str, dict]:
    """product -> month -> stats"""
    out = {pid: {m: {"deals": 0, "qty": 0, "value_qian": 0.0, "units": []} for m in range(1, 13)} for pid in PRODUCT_IDS}
    for e in events:
        if year and e.get("year") != year:
            # volume tagged 2025; local may be 2026 — allow source filter separately
            if e.get("source") == "volume_2025" and year == 2025:
                pass
            elif e.get("year") != year:
                continue
        if not e.get("month") or e["product_id"] not in out:
            continue
        m = e["month"]
        cell = out[e["product_id"]][m]
        cell["deals"] += 1
        cell["qty"] += e["qty"]
        cell["value_qian"] += e["money_qian"] or 0
        if e.get("unit_qian"):
            cell["units"].append(e["unit_qian"])
    for pid in out:
        for m in range(1, 13):
            cell = out[pid][m]
            units = cell.pop("units")
            cell["unit_p50_qian"] = round(median(units), 2) if units else None
            cell["value_qian"] = round(cell["value_qian"], 1)
            cell["mom_qty_growth"] = None
        prev = None
        for m in range(1, 13):
            q = out[pid][m]["qty"]
            if prev not in (None, 0):
                out[pid][m]["mom_qty_growth"] = round((q - prev) / prev * 100, 1)
            prev = q
    return out


def species_month(events: List[dict], product_id: str = "shredder") -> Dict[str, Dict[int, dict]]:
    """species -> month -> stats for one product (events already year-filtered)."""
    out = {sid: {m: {"deals": 0, "qty": 0, "value_qian": 0.0, "units": []} for m in range(1, 13)} for sid in SPECIES_IDS + ["other"]}
    for e in events:
        if e.get("product_id") != product_id:
            continue
        sid = e.get("species_id") or "other"
        m = e.get("month")
        if not m:
            continue
        cell = out[sid][m]
        cell["deals"] += 1
        cell["qty"] += e["qty"]
        cell["value_qian"] += e["money_qian"] or 0
        if e.get("unit_qian"):
            cell["units"].append(e["unit_qian"])
    for sid in out:
        for m in range(1, 13):
            cell = out[sid][m]
            units = cell.pop("units")
            cell["unit_p50_qian"] = round(median(units), 2) if units else None
            cell["value_qian"] = round(cell["value_qian"], 1)
    return out


def tier_by_species(events: List[dict], product_id: str) -> List[dict]:
    rows = []
    for sid in SPECIES_IDS + ["other"]:
        subset = [e for e in events if e.get("product_id") == product_id and e.get("species_id") == sid]
        if not subset:
            continue
        tiers = Counter(e["price_tier"] for e in subset)
        qty = sum(e["qty"] for e in subset)
        val = sum(e["money_qian"] for e in subset)
        units = [e["unit_qian"] for e in subset if e.get("unit_qian")]
        rows.append({
            "species": SPECIES_NAME[sid],
            "species_id": sid,
            "deals": len(subset),
            "qty": qty,
            "value_qian": round(val, 1),
            "unit_p50_qian": round(median(units), 2) if units else DEFAULT_UNIT_QIAN[product_id].get(sid, 5),
            "tiers": dict(tiers),
            "recommend_tier": max(tiers.items(), key=lambda x: x[1])[0] if tiers else "常用 3–8千",
        })
    rows.sort(key=lambda x: -x["qty"])
    return rows


def season_index_from_qty(month_qty: Dict[int, int]) -> Dict[int, float]:
    vals = [month_qty.get(m, 0) for m in range(1, 13)]
    avg = (sum(vals) / 12.0) or 1.0
    return {m: round(month_qty.get(m, 0) / avg, 3) for m in range(1, 13)}


def forecast_2026(
    events: List[dict],
    product_id: str = "shredder",
) -> dict:
    """Seasonality from 2025 volume + 2026 local month-of-year; forecast missing 2026 months."""
    ev_2025 = [e for e in events if e["product_id"] == product_id and (e.get("source") == "volume_2025" or e.get("year") == 2025)]
    ev_2026 = [e for e in events if e["product_id"] == product_id and e.get("year") == 2026]

    qty_2025 = Counter()
    for e in ev_2025:
        if e.get("month"):
            qty_2025[e["month"]] += e["qty"]

    qty_2026_act = Counter()
    val_2026_act = Counter()
    deals_2026 = Counter()
    for e in ev_2026:
        if e.get("month"):
            qty_2026_act[e["month"]] += e["qty"]
            val_2026_act[e["month"]] += e["money_qian"] or 0
            deals_2026[e["month"]] += 1

    # Combined seasonal shape: average normalized profiles of years that have data
    def _norm_profile(counter: Counter) -> Dict[int, float]:
        total = sum(counter.values()) or 1
        return {m: counter.get(m, 0) / total for m in range(1, 13)}

    profiles = []
    if sum(qty_2025.values()) > 0:
        profiles.append(_norm_profile(qty_2025))
    if sum(qty_2026_act.values()) > 0:
        profiles.append(_norm_profile(qty_2026_act))
    if not profiles:
        profiles = [{m: 1 / 12 for m in range(1, 13)}]
    blend = {m: sum(p[m] for p in profiles) / len(profiles) for m in range(1, 13)}
    avg_blend = (sum(blend.values()) / 12.0) or 1.0
    idx = {m: round(blend[m] / avg_blend, 3) for m in range(1, 13)}

    actual_2026 = {
        m: {
            "qty": qty_2026_act.get(m, 0),
            "value_qian": round(val_2026_act.get(m, 0), 1),
            "deals": deals_2026.get(m, 0),
        }
        for m in range(1, 13)
    }

    observed = [actual_2026[m]["qty"] for m in range(1, 13) if actual_2026[m]["qty"] > 0]
    if observed:
        scales = [
            actual_2026[m]["qty"] / idx[m]
            for m in range(1, 13)
            if actual_2026[m]["qty"] > 0 and idx[m] > 0
        ]
        scale = median(scales) if scales else (sum(observed) / len(observed))
    else:
        scale = (sum(qty_2025.values()) / 12.0) if qty_2025 else 5.0

    # unit price from 2026 actuals when available
    units_2026 = [e["unit_qian"] for e in ev_2026 if e.get("unit_qian")]
    default_unit = median(units_2026) if units_2026 else DEFAULT_UNIT_QIAN[product_id]["other"]

    forecast_months = {}
    for m in range(1, 13):
        if actual_2026[m]["qty"] > 0:
            forecast_months[m] = {
                "mode": "actual",
                "qty": actual_2026[m]["qty"],
                "value_qian": actual_2026[m]["value_qian"],
                "deals": actual_2026[m]["deals"],
            }
        else:
            fq = max(0, int(round(scale * idx[m])))
            forecast_months[m] = {
                "mode": "forecast",
                "qty": fq,
                "value_qian": round(fq * default_unit, 1),
                "deals": None,
            }

    species_share = Counter()
    for e in ev_2025 + ev_2026:
        species_share[e["species_id"]] += e["qty"]
    total_share = sum(species_share.values()) or 1
    rest_qty = sum(forecast_months[m]["qty"] for m in range(1, 13) if forecast_months[m]["mode"] == "forecast")
    actual_qty = sum(forecast_months[m]["qty"] for m in range(1, 13) if forecast_months[m]["mode"] == "actual")

    # unit by species from 2026 money when possible
    species_forecast = []
    for sid in SPECIES_IDS + ["other"]:
        share = species_share.get(sid, 0) / total_share
        act = sum(e["qty"] for e in ev_2026 if e["species_id"] == sid)
        units = [e["unit_qian"] for e in ev_2026 if e["species_id"] == sid and e.get("unit_qian")]
        if not units:
            units = [e["unit_qian"] for e in ev_2025 if e["species_id"] == sid and e.get("unit_qian")]
        unit = median(units) if units else DEFAULT_UNIT_QIAN[product_id].get(sid, 5.0)
        fq_rest = int(round(rest_qty * share))
        fq_year = act + fq_rest
        species_forecast.append({
            "species": SPECIES_NAME[sid],
            "species_id": sid,
            "actual_qty_yd": act,
            "forecast_rest_qty": fq_rest,
            "forecast_year_qty": fq_year,
            "unit_qian": round(float(unit), 2),
            "recommend_price_qian": f"{float(unit) * 0.85:.1f}–{float(unit) * 1.15:.1f}千",
            "recommend_tier": price_tier(float(unit)),
            "forecast_value_qian": round(fq_year * float(unit), 1),
            "share_2025": round(share * 100, 1),
        })
    species_forecast.sort(key=lambda x: -x["forecast_year_qty"])

    return {
        "product_id": product_id,
        "season_index_2025": idx,  # blended season index (name kept for template)
        "season_index_blended": idx,
        "qty_2025_by_month": {str(m): qty_2025.get(m, 0) for m in range(1, 13)},
        "qty_2026_actual_by_month": {str(m): qty_2026_act.get(m, 0) for m in range(1, 13)},
        "months_2026": {str(m): forecast_months[m] for m in range(1, 13)},
        "species_forecast": species_forecast,
        "totals": {
            "qty_2025": sum(qty_2025.values()),
            "qty_2026_actual": actual_qty,
            "qty_2026_forecast_year": actual_qty + rest_qty,
            "value_2026_forecast_qian": round(sum(s["forecast_value_qian"] for s in species_forecast), 1),
        },
    }


def write_html(path: str, payload: dict):
    months = [f"{m}月" for m in range(1, 13)]
    y26 = payload.get("matrix_2026", {}).get("shredder") or {str(m): {"qty": 0, "value_qian": 0, "unit_p50_qian": 0} for m in range(1, 13)}
    qty26_act = [y26[str(m)]["qty"] for m in range(1, 13)]
    val26_act = [y26[str(m)]["value_qian"] for m in range(1, 13)]
    unit26_act = [y26[str(m)]["unit_p50_qian"] or 0 for m in range(1, 13)]

    # shredder focus curves
    y25 = payload["matrix_2025"]["shredder"]
    qty25 = [y25[str(m)]["qty"] for m in range(1, 13)]
    val25 = [y25[str(m)]["value_qian"] for m in range(1, 13)]
    unit25 = [(y25[str(m)]["unit_p50_qian"] or y26[str(m)]["unit_p50_qian"] or 0) for m in range(1, 13)]
    growth25 = [y25[str(m)]["mom_qty_growth"] if y25[str(m)]["mom_qty_growth"] is not None else 0 for m in range(1, 13)]
    # 2026 actual mom
    growth26 = []
    prev = None
    for m in range(1, 13):
        q = y26[str(m)]["qty"]
        growth26.append(round((q - prev) / prev * 100, 1) if prev not in (None, 0) else 0)
        prev = q

    fc = payload["forecast_shredder"]
    qty26 = [fc["months_2026"][str(m)]["qty"] for m in range(1, 13)]
    mode26 = [fc["months_2026"][str(m)]["mode"] for m in range(1, 13)]
    val26 = [fc["months_2026"][str(m)]["value_qian"] for m in range(1, 13)]

    # species stacked-ish as separate series for 2025 shredder
    sm = payload["species_month_2025_shredder"]
    species_series = []
    colors = {"court": "#0d5c63", "procuratorate": "#8a4b08", "police": "#3d4f7c", "agriculture": "#1b5e3b", "other": "#888"}
    for sid in SPECIES_IDS + ["other"]:
        species_series.append({
            "label": SPECIES_NAME[sid],
            "data": [sm[sid][str(m)]["qty"] for m in range(1, 13)],
            "color": colors[sid],
        })

    win_rows = "".join(
        f"<tr><td>{r['month']}月</td><td class='num'>{r['season_index']}</td>"
        f"<td class='num'>{r['qty']}</td><td class='num'>{r.get('qty_2026_actual', 0)}</td>"
        f"<td class='num'>{r['deals']}</td>"
        f"<td class='num'>{r['value_qian']}</td><td class='num'>{r['unit_p50_qian'] if r['unit_p50_qian'] is not None else '-'}</td>"
        f"<td class='num'>{r['mom_growth'] if r['mom_growth'] is not None else '-'}</td>"
        f"<td class='num'>{r['forecast_2026_qty']}</td><td>{r['forecast_mode']}</td></tr>"
        for r in payload["window_1_12"]
    )

    sp_hist = "".join(
        f"<tr><td>{r['species']}</td><td class='num'>{r['deals']}</td><td class='num'>{r['qty']}</td>"
        f"<td class='num'>{r['value_qian']}</td><td class='num'>{r['unit_p50_qian']}</td>"
        f"<td>{r['recommend_tier']}</td></tr>"
        for r in payload["tier_species_2025"]
    )
    sp_hist26 = "".join(
        f"<tr><td>{r['species']}</td><td class='num'>{r['deals']}</td><td class='num'>{r['qty']}</td>"
        f"<td class='num'>{r['value_qian']}</td><td class='num'>{r['unit_p50_qian']}</td>"
        f"<td>{r['recommend_tier']}</td></tr>"
        for r in (payload.get("tier_species_2026") or [])
    )

    sp_fc = "".join(
        f"<tr><td>{r['species']}</td><td class='num'>{r['actual_qty_yd']}</td>"
        f"<td class='num'>{r['forecast_rest_qty']}</td><td class='num'><b>{r['forecast_year_qty']}</b></td>"
        f"<td>{r['recommend_price_qian']}</td><td>{r['recommend_tier']}</td>"
        f"<td class='num'>{r['forecast_value_qian']}</td></tr>"
        for r in fc["species_forecast"]
    )

    # product comparison 2025
    prod_rows = "".join(
        f"<tr><td>{payload['product_names'][pid]}</td>"
        + "".join(f"<td class='num'>{payload['matrix_2025'][pid][str(m)]['qty']}</td>" for m in range(1, 13))
        + f"<td class='num'><b>{sum(payload['matrix_2025'][pid][str(m)]['qty'] for m in range(1,13))}</b></td></tr>"
        for pid in PRODUCT_IDS
    )

    html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>2025实绩 × 2026预测 · 千元口径</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<style>
:root{{--ink:#1a1f2e;--muted:#5c6578;--line:#e2e6ef;--bg:#f3f1eb;--paper:#fffcf7;--accent:#0d5c63}}
body{{margin:0;font-family:"PingFang SC","Noto Sans SC",sans-serif;color:var(--ink);background:var(--bg)}}
.wrap{{max-width:1180px;margin:0 auto;padding:32px 18px 80px}}
h1{{font-family:"Songti SC",serif;font-size:1.9rem;margin:0 0 6px}}
h2{{font-family:"Songti SC",serif;margin:34px 0 10px;font-size:1.25rem;border-bottom:2px solid var(--accent);padding-bottom:6px}}
h3{{margin:16px 0 8px;color:var(--accent);font-size:1rem}}
.meta{{color:var(--muted);font-size:13px}}
.legend{{background:#e8f3f3;padding:10px 12px;border-radius:4px;margin:10px 0;font-size:13px}}
.callout{{border-left:3px solid var(--accent);padding:10px 12px;background:#eef7f7;margin:12px 0;font-size:14px}}
.charts{{display:grid;gap:14px}}
@media(min-width:960px){{.charts.two{{grid-template-columns:1fr 1fr}}}}
.chart-box{{background:var(--paper);border:1px solid var(--line);padding:12px;border-radius:4px}}
.card{{background:var(--paper);border:1px solid var(--line);padding:12px;border-radius:4px;overflow-x:auto;margin:10px 0}}
table{{width:100%;border-collapse:collapse;font-size:12px}}
th,td{{padding:7px 8px;border-bottom:1px solid var(--line);text-align:left;white-space:nowrap}}
th{{background:#eef2f0;color:var(--muted);font-size:11px}}
.num{{text-align:right;font-variant-numeric:tabular-nums}}
.stats{{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px;margin:10px 0}}
.stat{{background:var(--paper);border:1px solid var(--line);padding:10px;border-radius:4px}}
.stat b{{display:block;font-size:1.25rem}}
.stat span{{font-size:11px;color:var(--muted)}}
.tag{{display:inline-block;padding:2px 8px;background:#e8f3f3;border-radius:3px;font-size:12px;margin-right:6px}}
</style></head><body><div class="wrap">
<h1>采购折叠 · 2025实绩与2026预测</h1>
<p class="meta">金额单位统一为 <b>千元</b>（1万=10千）· 窗口对比覆盖 1–12 月 · 主单品示例：碎纸机（可同结构扩展复印/装订/印控）</p>
<div class="legend">
<span class="tag">单位：千元 / 台</span>
<span class="tag">2025：成交池+当年标讯</span>
<span class="tag">2026：本地实绩 + 按2025季节指数外推</span>
</div>

<div class="callout">
<b>怎么读：</b>上半部分是 <b>2025 全年每月</b> 哪个系统、什么价位、多少台、单价与增长曲线；
下半部分是 <b>2026 预测</b>——去哪个系统、推什么价位/单品、大约多少台、采购额（千元）。
</div>

<h2>一、2025 实绩（1–12月全窗）</h2>
<div class="stats">
<div class="stat"><b>{payload['totals_2025']['qty']}</b><span>2025碎纸机台数(成交池)</span></div>
<div class="stat"><b>{payload['totals_2025']['value_qian']:,.0f}</b><span>2025采购额(千元)</span></div>
<div class="stat"><b>{payload.get('totals_2026_ytd',{}).get('qty',0)}</b><span>2026已发生台数(本地)</span></div>
<div class="stat"><b>{payload.get('totals_2026_ytd',{}).get('value_qian',0):,.0f}</b><span>2026已发生采购额(千元)</span></div>
</div>

<h3>1–12月窗口总表（碎纸机 · 千元）</h3>
<div class="card"><table>
<thead><tr>
<th>月</th><th>季节指数</th><th>2025台数</th><th>2026实绩台数</th><th>2025笔数</th><th>采购额(千)</th><th>单价中位(千)</th><th>2025环比%</th><th>2026预测台数</th><th>类型</th>
</tr></thead>
<tbody>{win_rows}</tbody></table>
<p style="font-size:12px;color:#5c6578">季节指数混合 2025成交池 + 2026本地月分布。2025早期月台数为0表示成交池抽样未覆盖，不是市场为零。</p>
</div>

<div class="charts two">
<div class="chart-box"><h3>订购曲线：2025成交池 vs 2026实绩（台）</h3><canvas id="cQty25" height="210"></canvas></div>
<div class="chart-box"><h3>环比增长率（%）：2025 / 2026实绩</h3><canvas id="cGrow25" height="210"></canvas></div>
<div class="chart-box"><h3>采购额（千元）</h3><canvas id="cVal25" height="210"></canvas></div>
<div class="chart-box"><h3>单价中位（千元/台）</h3><canvas id="cUnit25" height="210"></canvas></div>
</div>

<h3>2025 各系统每月台数（碎纸机）</h3>
<div class="chart-box"><canvas id="cSp25" height="240"></canvas></div>

<h3>2025 各系统价位与建议（成交池 · 千元）</h3>
<div class="card"><table>
<thead><tr><th>系统</th><th>笔数</th><th>台数</th><th>采购额(千)</th><th>单价中位(千)</th><th>主价位带</th></tr></thead>
<tbody>{sp_hist}</tbody></table></div>

<h3>2026 已发生：各系统价位实绩（本地 · 千元）</h3>
<div class="card"><table>
<thead><tr><th>系统</th><th>笔数</th><th>台数</th><th>采购额(千)</th><th>单价中位(千)</th><th>主价位带</th></tr></thead>
<tbody>{sp_hist26}</tbody></table></div>

<h3>2025 四大单品月度台数对比</h3>
<div class="card"><table>
<thead><tr><th>单品</th>{''.join(f'<th>{m}</th>' for m in months)}<th>全年</th></tr></thead>
<tbody>{prod_rows}</tbody></table></div>
<div class="chart-box"><canvas id="cProd25" height="240"></canvas></div>

<h2>二、2026 预测展现</h2>
<div class="stats">
<div class="stat"><b>{fc['totals']['qty_2026_actual']}</b><span>2026已发生台数</span></div>
<div class="stat"><b>{fc['totals']['qty_2026_forecast_year']}</b><span>2026全年预测台数</span></div>
<div class="stat"><b>{fc['totals']['value_2026_forecast_qian']:,.0f}</b><span>2026预测采购额(千元)</span></div>
<div class="stat"><b>{fc['species_forecast'][0]['species'] if fc['species_forecast'] else '-'}</b><span>优先系统</span></div>
</div>

<div class="callout">
<b>预测逻辑：</b>有2026实绩的月份用实绩；其余月份 = 规模系数 × 2025季节指数。
系统分配按2025成交池物种份额；价位用该系统默认/中位单价（千元）。
</div>

<div class="charts two">
<div class="chart-box"><h3>2026 台数：实绩 vs 预测</h3><canvas id="cQty26" height="220"></canvas></div>
<div class="chart-box"><h3>2026 采购额（千元）</h3><canvas id="cVal26" height="220"></canvas></div>
</div>

<h3>去哪个系统 · 多少台 · 什么价 · 采购额</h3>
<div class="card"><table>
<thead><tr><th>系统</th><th>年内已发生台数</th><th>剩余预测台数</th><th>全年预测台数</th><th>建议单价(千)</th><th>价位带</th><th>预测采购额(千)</th></tr></thead>
<tbody>{sp_fc}</tbody></table></div>
<div class="chart-box"><h3>2026 各系统全年预测台数</h3><canvas id="cSpFc" height="220"></canvas></div>

<p class="meta">生成于 {payload['generated_at']} · {payload['data_note']}</p>
</div>
<script>
const months = {json.dumps(months, ensure_ascii=False)};
const qty25 = {json.dumps(qty25)};
const growth25 = {json.dumps(growth25)};
const val25 = {json.dumps(val25)};
const unit25 = {json.dumps(unit25)};
const qty26 = {json.dumps(qty26)};
const val26 = {json.dumps(val26)};
const mode26 = {json.dumps(mode26, ensure_ascii=False)};
const spSeries = {json.dumps(species_series, ensure_ascii=False)};
const prodNames = {json.dumps(payload['product_names'], ensure_ascii=False)};
const prodQty = {json.dumps({pid: [payload['matrix_2025'][pid][str(m)]['qty'] for m in range(1,13)] for pid in PRODUCT_IDS}, ensure_ascii=False)};
const spFcLabels = {json.dumps([r['species'] for r in fc['species_forecast']], ensure_ascii=False)};
const spFcQty = {json.dumps([r['forecast_year_qty'] for r in fc['species_forecast']])};
const colors = {{shredder:'#0d5c63',copier:'#8a4b08',binding_machine:'#3d4f7c',seal_control:'#7a1f1f'}};

function line(id, datasets, yTitle) {{
  new Chart(document.getElementById(id), {{
    type:'line',
    data:{{labels:months, datasets}},
    options:{{
      plugins:{{legend:{{position:'bottom'}}}},
      scales:{{
        y:{{title:{{display:true,text:yTitle}}, beginAtZero:true}},
        x:{{title:{{display:true,text:'月份'}}}}
      }}
    }}
  }});
}}
const qty26act = {json.dumps(qty26_act)};
const val26act = {json.dumps(val26_act)};
const unit26act = {json.dumps(unit26_act)};
const growth26 = {json.dumps(growth26)};

line('cQty25', [
  {{label:'2025成交池台数', data:qty25, borderColor:'#0d5c63', tension:0.25, pointRadius:3}},
  {{label:'2026实绩台数', data:qty26act, borderColor:'#8a4b08', tension:0.25, pointRadius:3}}
], '台数');
line('cGrow25', [
  {{label:'2025环比%', data:growth25, borderColor:'#0d5c63', borderDash:[4,3], tension:0.25}},
  {{label:'2026实绩环比%', data:growth26, borderColor:'#8a4b08', borderDash:[2,2], tension:0.25}}
], '环比增长率 (%)');
line('cVal25', [
  {{label:'2025采购额(千)', data:val25, borderColor:'#3d4f7c', tension:0.25}},
  {{label:'2026实绩采购额(千)', data:val26act, borderColor:'#8a4b08', tension:0.25}}
], '千元');
line('cUnit25', [
  {{label:'单价中位(千元/台)', data:unit25.map((v,i)=>v||unit26act[i]||0), borderColor:'#1b5e3b', tension:0.25}}
], '千元/台');

new Chart(document.getElementById('cSp25'), {{
  type:'bar',
  data:{{
    labels:months,
    datasets: spSeries.map(s => ({{label:s.label, data:s.data, backgroundColor:s.color}}))
  }},
  options:{{
    plugins:{{legend:{{position:'bottom'}}}},
    scales:{{
      x:{{stacked:true, title:{{display:true,text:'月份'}}}},
      y:{{stacked:true, title:{{display:true,text:'台数'}}, beginAtZero:true}}
    }}
  }}
}});

new Chart(document.getElementById('cProd25'), {{
  type:'line',
  data:{{
    labels:months,
    datasets: Object.keys(prodQty).map(pid => ({{
      label: prodNames[pid], data: prodQty[pid], borderColor: colors[pid], tension:0.25, pointRadius:2
    }}))
  }},
  options:{{plugins:{{legend:{{position:'bottom'}}}}, scales:{{y:{{title:{{display:true,text:'台数'}}, beginAtZero:true}}, x:{{title:{{display:true,text:'月份'}}}}}}}}
}});

// 2026: split color by actual/forecast via point styles
line('cQty26', [{{
  label:'2026台数', data:qty26, borderColor:'#0d5c63', tension:0.25, pointRadius:4,
  pointBackgroundColor: mode26.map(m => m==='actual' ? '#0d5c63' : '#aaa')
}}], '台数');
line('cVal26', [{{label:'采购额(千元)', data:val26, borderColor:'#3d4f7c', tension:0.25}}], '千元');

new Chart(document.getElementById('cSpFc'), {{
  type:'bar',
  data:{{labels:spFcLabels, datasets:[{{label:'全年预测台数', data:spFcQty, backgroundColor:'#0d5c63'}}]}},
  options:{{plugins:{{legend:{{display:false}}}}, scales:{{y:{{title:{{display:true,text:'台数'}}, beginAtZero:true}}, x:{{title:{{display:true,text:'系统'}}}}}}}}
}});
</script></body></html>"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)


def main():
    events = load_all_events()
    packs = {pid: load_pack(pid) for pid in PRODUCT_IDS}
    product_names = {pid: packs[pid].canonical_product for pid in PRODUCT_IDS}

    # 2025 matrix: prefer volume_2025 + any local year==2025
    ev_2025 = [
        e for e in events
        if e.get("source") == "volume_2025" or e.get("year") == 2025
    ]
    matrix_2025 = month_matrix(ev_2025, year=None)  # already filtered
    # re-key months as str for json
    matrix_2025_s = {
        pid: {str(m): matrix_2025[pid][m] for m in range(1, 13)}
        for pid in PRODUCT_IDS
    }

    # 2026 local for price curves
    ev_2026 = [e for e in events if e.get("year") == 2026]
    matrix_2026 = month_matrix(ev_2026, year=None)
    matrix_2026_s = {
        pid: {str(m): matrix_2026[pid][m] for m in range(1, 13)}
        for pid in PRODUCT_IDS
    }
    tier_species_2026 = tier_by_species(ev_2026, "shredder")

    sm = species_month(ev_2025, product_id="shredder")
    sm_s = {sid: {str(m): sm[sid][m] for m in range(1, 13)} for sid in sm}

    tier_species = tier_by_species(ev_2025, "shredder")
    fc = forecast_2026(events, "shredder")

    idx = fc["season_index_blended"]
    window_1_12 = []
    for m in range(1, 13):
        cell = matrix_2025["shredder"][m]
        cell26 = matrix_2026["shredder"][m]
        fm = fc["months_2026"][str(m)]
        # 展示单价：优先2025，否则用2026实绩单价
        unit = cell["unit_p50_qian"] if cell["unit_p50_qian"] is not None else cell26["unit_p50_qian"]
        window_1_12.append({
            "month": m,
            "season_index": idx.get(m, 0),
            "qty": cell["qty"],
            "qty_2026_actual": cell26["qty"],
            "deals": cell["deals"],
            "value_qian": cell["value_qian"] if cell["value_qian"] else cell26["value_qian"],
            "unit_p50_qian": unit,
            "mom_growth": cell["mom_qty_growth"],
            "forecast_2026_qty": fm["qty"],
            "forecast_mode": "实绩" if fm["mode"] == "actual" else "预测",
        })

    totals_2025 = {
        "qty": sum(matrix_2025["shredder"][m]["qty"] for m in range(1, 13)),
        "deals": sum(matrix_2025["shredder"][m]["deals"] for m in range(1, 13)),
        "value_qian": round(sum(matrix_2025["shredder"][m]["value_qian"] for m in range(1, 13)), 1),
    }
    totals_2026_ytd = {
        "qty": sum(matrix_2026["shredder"][m]["qty"] for m in range(1, 13)),
        "deals": sum(matrix_2026["shredder"][m]["deals"] for m in range(1, 13)),
        "value_qian": round(sum(matrix_2026["shredder"][m]["value_qian"] for m in range(1, 13)), 1),
    }

    payload = {
        "product_names": product_names,
        "matrix_2025": matrix_2025_s,
        "matrix_2026": matrix_2026_s,
        "species_month_2025_shredder": sm_s,
        "tier_species_2025": tier_species,
        "tier_species_2026": tier_species_2026,
        "window_1_12": window_1_12,
        "forecast_shredder": fc,
        "totals_2025": totals_2025,
        "totals_2026_ytd": totals_2026_ytd,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "data_note": "金额单位=千元。2025台数主来自知了网成交池（偏11–12月）；2026实绩与价位来自本地scout。季节指数=两年月分布混合。知了网额度已用尽。",
        "event_counts": {
            "all": len(events),
            "y2025": len(ev_2025),
            "y2026": len(ev_2026),
        },
    }

    run_id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_year_forecast"
    out_dir = os.path.join(REPO_DIR, "fold_runs", run_id)
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "year_forecast.json"), "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2, default=str)
    html_path = os.path.join(out_dir, "report.html")
    write_html(html_path, payload)
    print("events", payload["event_counts"])
    print("2025 shredder", totals_2025)
    print("2026 forecast", fc["totals"])
    print("window sample", window_1_12[4], window_1_12[5], window_1_12[10])
    print("DONE", html_path)
    return out_dir, html_path


if __name__ == "__main__":
    main()
