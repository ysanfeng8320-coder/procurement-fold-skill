"""Procurement Fold pipeline entry."""
from __future__ import annotations

import argparse
import os
import sys
from datetime import datetime

KG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO_DIR = os.path.dirname(KG_DIR)
if KG_DIR not in sys.path:
    sys.path.insert(0, KG_DIR)

from fold.pack_loader import load_pack
from fold.ingest import ingest
from fold.structure import structure_records, filter_recent
from fold.fold_rules import fold_rules
from fold.act import act_leads
from fold.report import write_run


def run_fold(
    pack_id: str,
    discovery_regions,
    action_regions,
    api_budget: int = 500,
    reuse_local: bool = True,
    windows_months=None,
    min_support: int = 3,
    max_leads: int = 40,
    max_age_years: float = 3.0,
    run_id: str = None,
):
    windows_months = windows_months or [1, 2]
    pack = load_pack(pack_id)

    ingested = ingest(
        keywords=pack.search_keywords,
        discovery_regions=discovery_regions,
        action_regions=action_regions,
        api_budget=api_budget,
        reuse_local=reuse_local,
    )
    structured_all = structure_records(ingested["records"], pack)
    structured = filter_recent(structured_all, max_age_years=max_age_years)
    cards = fold_rules(
        structured,
        pack,
        discovery_regions=discovery_regions,
        windows_months=windows_months,
        min_support=min_support,
    )
    leads = act_leads(
        structured,
        cards,
        pack,
        action_regions=action_regions,
        max_leads=max_leads,
    )

    run_id = run_id or datetime.now().strftime("%Y%m%d_%H%M%S") + f"_{pack_id}"
    run_dir = os.path.join(REPO_DIR, "fold_runs", run_id)
    meta = {
        "discovery_regions": discovery_regions,
        "action_regions": action_regions,
        "ingest": ingested["meta"],
        "windows_months": windows_months,
        "min_support": min_support,
        "max_age_years": max_age_years,
        "structured_before_date_filter": len(structured_all),
        "structured_after_date_filter": len(structured),
        "mode": "stats_graph_no_ml",
    }
    report_path = write_run(run_dir, structured, cards, leads, meta, pack_id)
    return {"run_dir": run_dir, "report_path": report_path, "meta": meta, "leads": leads, "rule_cards": cards}


def main(argv=None):
    p = argparse.ArgumentParser(description="Procurement Fold runner")
    p.add_argument("--pack", required=True, help="product pack id")
    p.add_argument("--discovery", default="安徽,浙江,北京,上海")
    p.add_argument("--action", default="陕西,甘肃")
    p.add_argument("--api-budget", type=int, default=500)
    p.add_argument("--reuse-local", action="store_true", default=True)
    p.add_argument("--no-reuse-local", action="store_true")
    p.add_argument("--min-support", type=int, default=3)
    p.add_argument("--max-leads", type=int, default=40)
    p.add_argument("--max-age-years", type=float, default=3.0, help="只保留近N年公告，默认3年")
    args = p.parse_args(argv)

    reuse = not args.no_reuse_local
    discovery = [x.strip() for x in args.discovery.split(",") if x.strip()]
    action = [x.strip() for x in args.action.split(",") if x.strip()]

    result = run_fold(
        pack_id=args.pack,
        discovery_regions=discovery,
        action_regions=action,
        api_budget=args.api_budget,
        reuse_local=reuse,
        min_support=args.min_support,
        max_leads=args.max_leads,
        max_age_years=args.max_age_years,
    )
    print(f"run_dir: {result['run_dir']}")
    print(f"report: {result['report_path']}")
    print(f"cards: {len(result['rule_cards'])} leads: {len(result['leads'])}")
    print(f"api_used: {result['meta']['ingest'].get('api_used')}/{result['meta']['ingest'].get('api_budget')}")


if __name__ == "__main__":
    main()
