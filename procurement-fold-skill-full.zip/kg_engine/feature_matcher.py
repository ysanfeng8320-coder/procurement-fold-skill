"""
特征拟合引擎
基于"已购目标产品的单位画像" → 预测"哪些未购单位最可能买"

核心逻辑：
  1. 从图谱中提取已购目标产品的单位 → 构建特征分布（行业/级别/金额/采购方式）
  2. 对"有采购能力但没买过"的单位进行特征匹配
  3. 按匹配度评分排序 → 输出可执行的行动清单

新增：终端用户分类器
  区分"真正在用这个产品的单位"和"运营商/集成商自用"
"""
import json, os, re
from collections import Counter, defaultdict
from graph_store import GraphStore
from schema import EntityType, RelationType, company_id

KG_DIR = os.path.dirname(os.path.abspath(__file__))


def classify_end_user_type(name: str) -> str:
    """
    判断一个单位是"终端用户"还是"集成商/运营商"
    终端用户 = 真正在办公室/考场/监狱等场景使用设备的单位
    """
    import re
    
    # 运营商标识
    if re.search(r'中国.*(?:通信|联通|移动|电信|铁塔)', name):
        return "运营商/集成商"
    # 集成商标识
    if re.search(r'(?:科技|信息|技术|工程|建设|实业|商贸|网络|电子|智能)(?:有限)?公司$', name):
        return "集成商/供应商"
    if re.search(r'有限(?:责任)?公司$', name) and not any(kw in name for kw in ["学校","医院","监狱","中心","局","部","委","办","厅","处","所"]):
        return "企业"
    # 政府/事业终端
    if any(kw in name for kw in ["局","部","委","办","厅","院","校","学","监狱","戒毒","所","中心","站","处","队","庭","委"]):
        return "政府/事业单位"
    if "学校" in name or "学院" in name or "大学" in name:
        return "学校"
    if "医院" in name:
        return "医院"
    return "终端用户（其他）"


class BuyerFeatureExtractor:
    """从单个采购单位提取特征"""
    
    @staticmethod
    def purchase_type(title: str) -> str:
        if not title: return "其他"
        if "直接订购" in title: return "直接订购"
        if "竞争性磋商" in title: return "竞争性磋商"
        if "竞争性谈判" in title: return "竞争性谈判"
        if "公开招标" in title: return "公开招标"
        if "询价" in title: return "询价"
        if "单一来源" in title: return "单一来源"
        if "意向公开" in title: return "意向公开"
        if "成交" in title: return "成交"
        return "其他"
    
    @staticmethod
    def amount_bucket(money: float) -> str:
        if money < 1: return "<1万"
        if money < 5: return "1-5万"
        if money < 10: return "5-10万"
        if money < 30: return "10-30万"
        if money < 100: return "30-100万"
        return ">100万"

    @staticmethod
    def level_from_name(name: str) -> str:
        if not name: return "未知"
        if name.startswith("省"): return "省级"
        if "市" in name[:3] and "市委" not in name[:4]: return "市级"
        if name.startswith("区"): return "区级"
        if "县" in name[:3]: return "县级"
        if "街道" in name or "镇" in name or "乡" in name: return "乡镇级"
        if "学院" in name or "大学" in name or "学校" in name: return "学校"
        return "未知"


class FeatureMatcher:
    def __init__(self, store: GraphStore):
        self.store = store
        self.contacts = self._load_contacts()
    
    def _load_contacts(self):
        f = os.path.join(KG_DIR, "data/contacts.json")
        if os.path.exists(f):
            with open(f) as fh:
                return json.load(fh)
        return {}
    
    def extract_features(self, buyer_entity) -> dict:
        e = buyer_entity
        name = e.name
        props = e.properties
        
        f = {
            "name": name,
            "province": props.get("proviceCode", ""),
            "user_type": classify_end_user_type(name),
            "level": BuyerFeatureExtractor.level_from_name(name),
            "phone": self.contacts.get(name, "待确认"),
        }
        
        projects = []
        products = set()
        purchase_types = Counter()
        amounts = []
        
        for r, proj in self.store.get_neighbors(e.id, RelationType.ISSUES):
            if proj.type != EntityType.PROJECT:
                continue
            money_str = str(proj.properties.get("money", "0")).replace("万","").strip()
            try:
                money = float(money_str) if money_str else 0
            except:
                money = 0
            title = proj.properties.get("original_title", "")
            ptime = proj.properties.get("time", "")
            projects.append({"id": proj.id, "money": money, "time": ptime})
            amounts.append(money)
            purchase_types[BuyerFeatureExtractor.purchase_type(title)] += 1
            for r2, prod in self.store.get_neighbors(proj.id, RelationType.REQUIRES):
                if prod.type == EntityType.PRODUCT:
                    products.add(prod.name)
        
        f["project_count"] = len(projects)
        f["total_spend"] = sum(amounts)
        f["products"] = list(products)
        f["product_count"] = len(products)
        f["purchase_types"] = dict(purchase_types.most_common(3))
        f["amount_bucket"] = BuyerFeatureExtractor.amount_bucket(f["total_spend"])
        if amounts:
            f["avg_spend"] = sum(amounts) / len(amounts)
        return f
    
    def build_profile(self, target_product: str, filter_user_types: list = None,
                      province_code: str = None, family: list = None) -> dict:
        """
        构建买家画像
        filter_user_types: 只统计哪些用户类型（如["政府/事业单位","学校"]）
        province_code: 省码硬过滤（如 620000）
        family: 同义词族；命中族内任一产品即算已购
        """
        family_set = set(family or [target_product])
        buyers = self.store.find_entities(EntityType.COMPANY)
        target_features = []
        nontarget_features = []
        
        for b in buyers:
            if b.properties.get("type") != "buyer":
                continue
            if province_code:
                if b.properties.get("proviceCode") != province_code:
                    continue
            f = self.extract_features(b)
            if f["project_count"] == 0:
                continue
            
            # 用户类型过滤
            ut = f.get("user_type", "")
            if filter_user_types and ut not in filter_user_types:
                continue
            
            bought = bool(set(f.get("products", [])) & family_set)
            if bought:
                target_features.append(f)
            elif f["product_count"] > 0:
                nontarget_features.append(f)
        
        # 画像计算
        ind_dist = Counter()
        level_dist = Counter()
        amount_dist = Counter()
        user_type_dist = Counter()
        total_spends = []
        
        for f in target_features:
            user_type_dist[f.get("user_type", "未知")] += 1
            level_dist[f.get("level", "未知")] += 1
            amount_dist[f.get("amount_bucket", "无数据")] += 1
            for pt, cnt in f.get("purchase_types", {}).items():
                ind_dist[pt] += cnt
            total_spends.append(f.get("total_spend", 0))
        
        n = max(len(target_features), 1)
        return {
            "target_product": target_product,
            "target_count": len(target_features),
            "nontarget_count": len(nontarget_features),
            "user_type_profile": {t: {"count": c, "pct": round(c/n*100)} for t, c in user_type_dist.most_common()},
            "level_profile": {lv: {"count": c, "pct": round(c/n*100)} for lv, c in level_dist.most_common()},
            "amount_profile": {ab: {"count": c, "pct": round(c/n*100)} for ab, c in amount_dist.most_common()},
            "purchase_type_profile": {pt: {"count": c, "pct": round(c/n*100)} for pt, c in ind_dist.most_common()},
            "avg_spend": round(sum(total_spends)/n, 1) if total_spends else 0,
        }

    def list_integrators_for_buyer(self, buyer_name: str, product: str = None,
                                   family: list = None, top_n: int = 8) -> list:
        """
        某采购单位曾合作过的集成商/中标供应商（来自图谱 WON_BY）。
        若指定 product/family，优先列出本品类中标商，并附带其他品类合作（若有）。
        """
        family_set = set(family or ([product] if product else []))
        cid = company_id(buyer_name)
        if cid not in self.store.graph.entities:
            # 尝试按名查找
            for e in self.store.find_entities(EntityType.COMPANY, name_contains=buyer_name):
                if e.name == buyer_name or buyer_name in e.name:
                    cid = e.id
                    break
            else:
                return []

        # supplier -> stats
        stats = {}
        for r, proj in self.store.get_neighbors(cid, RelationType.ISSUES):
            if proj.type != EntityType.PROJECT:
                continue
            money_str = str(proj.properties.get("money", "0")).replace("万", "").strip()
            try:
                money = float(money_str) if money_str else 0
            except Exception:
                money = 0
            title = proj.properties.get("original_title", "") or proj.name
            ptime = proj.properties.get("time", "")
            prods = []
            for r2, prod in self.store.get_neighbors(proj.id, RelationType.REQUIRES):
                if prod.type == EntityType.PRODUCT:
                    prods.append(prod.name)
            for r2, sup in self.store.get_neighbors(proj.id, RelationType.WON_BY):
                if sup.type != EntityType.COMPANY:
                    continue
                sname = sup.name
                if sname not in stats:
                    stats[sname] = {
                        "name": sname,
                        "phone": self.contacts.get(sname, "待确认"),
                        "deal_count": 0,
                        "total_amount": 0.0,
                        "products": set(),
                        "last_time": "",
                        "sample_title": "",
                        "in_family": False,
                    }
                stats[sname]["deal_count"] += 1
                stats[sname]["total_amount"] += money
                stats[sname]["products"].update(prods)
                if family_set and (set(prods) & family_set):
                    stats[sname]["in_family"] = True
                if ptime and (not stats[sname]["last_time"] or str(ptime) > stats[sname]["last_time"]):
                    stats[sname]["last_time"] = str(ptime)
                    stats[sname]["sample_title"] = title[:60]

        rows = []
        for s in stats.values():
            rows.append({
                "name": s["name"],
                "phone": s["phone"],
                "deal_count": s["deal_count"],
                "total_amount": round(s["total_amount"], 1),
                "products": sorted(s["products"]),
                "last_time": s["last_time"],
                "sample_title": s["sample_title"],
                "in_family": s["in_family"],
            })
        # 本品类中标优先，再按次数/金额
        rows.sort(key=lambda x: (-int(x["in_family"]), -x["deal_count"], -x["total_amount"]))
        return rows[:top_n]

    def attach_integrators(self, buyers: list, product: str = None,
                           family: list = None) -> list:
        """给已购/潜客列表挂上曾合作集成商。"""
        out = []
        for b in buyers:
            row = dict(b)
            name = row.get("name") or ""
            integrators = self.list_integrators_for_buyer(
                name, product=product, family=family
            )
            row["integrators"] = integrators
            row["integrator_names"] = [i["name"] for i in integrators]
            out.append(row)
        return out

    def list_confirmed_buyers(self, target_product: str, province_code: str = None,
                              family: list = None, top_n: int = 50) -> list:
        """池 A：真买过目标品类族的单位（按金额排序）"""
        family_set = set(family or [target_product])
        results = []
        for b in self.store.find_entities(EntityType.COMPANY):
            if b.properties.get("type") != "buyer":
                continue
            if province_code and b.properties.get("proviceCode") != province_code:
                continue
            f = self.extract_features(b)
            if not (set(f.get("products", [])) & family_set):
                continue
            results.append({
                "name": f["name"],
                "phone": f["phone"],
                "user_type": f.get("user_type", ""),
                "level": f.get("level", ""),
                "amount_bucket": f["amount_bucket"],
                "total_spend": f.get("total_spend", 0),
                "project_count": f["project_count"],
                "existing_products": f.get("products", []),
                "industries": b.properties.get("industries", []),
                "province": f.get("province", ""),
            })
        results = sorted(results, key=lambda x: -x["total_spend"])[:top_n]
        return self.attach_integrators(results, product=target_product, family=family)

    def prospects_from_scene(self, scene_result: dict, top_n: int = 30,
                             product: str = None, family: list = None) -> list:
        """
        池 B：场景完备性中的「在数据中未购」+「盲区」作为潜客。
        对能在图谱中匹配到的单位，挂上曾合作集成商。
        """
        if not scene_result or scene_result.get("error"):
            return []
        prospects = []
        for name, phone, matched in scene_result.get("not_purchased", []):
            prospects.append({
                "name": matched or name,
                "expected_name": name,
                "phone": phone or "待确认",
                "user_type": classify_end_user_type(matched or name),
                "level": BuyerFeatureExtractor.level_from_name(matched or name),
                "amount_bucket": "-",
                "existing_products": [],
                "score": 80,
                "reasons": ["场景单位已在采购数据中出现，但未购目标品类"],
                "pool": "场景未购",
            })
        for name, phone, _ in scene_result.get("blind_spot", []):
            prospects.append({
                "name": name,
                "expected_name": name,
                "phone": phone or "待确认",
                "user_type": classify_end_user_type(name),
                "level": BuyerFeatureExtractor.level_from_name(name),
                "amount_bucket": "-",
                "existing_products": [],
                "score": 60,
                "reasons": ["场景穷举单位，采购数据中尚未出现（盲区）"],
                "pool": "场景盲区",
            })
        prospects = prospects[:top_n]
        return self.attach_integrators(prospects, product=product, family=family)
    
    def score_buyer(self, features: dict, profile: dict) -> dict:
        """特征匹配评分"""
        score = 0
        reasons = []
        
        # 1. 用户类型匹配
        ut = features.get("user_type", "")
        ut_pct = profile.get("user_type_profile", {}).get(ut, {}).get("pct", 0)
        if ut_pct >= 30:
            score += 30
            reasons.append(f"用户类型'{ut}'高度匹配（{ut_pct}%的已购客户）")
        elif ut_pct >= 15:
            score += 20
            reasons.append(f"用户类型'{ut}'匹配（{ut_pct}%）")
        elif ut_pct >= 5:
            score += 10
        
        # 2. 金额区间匹配
        bucket = features.get("amount_bucket", "")
        ab_pct = profile.get("amount_profile", {}).get(bucket, {}).get("pct", 0)
        if ab_pct >= 25:
            score += 25
            reasons.append(f"金额区间'{bucket}'高度匹配（{ab_pct}%）")
        elif ab_pct >= 10:
            score += 15
            reasons.append(f"金额区间'{bucket}'匹配（{ab_pct}%）")
        elif ab_pct >= 5:
            score += 8
        
        # 3. 采购方式匹配
        for pt, cnt in features.get("purchase_types", {}).items():
            pt_pct = profile.get("purchase_type_profile", {}).get(pt, {}).get("pct", 0)
            if pt_pct >= 25:
                score += 15
            elif pt_pct >= 10:
                score += 8
        
        # 4. 行政级别匹配
        level = features.get("level", "未知")
        lv_pct = profile.get("level_profile", {}).get(level, {}).get("pct", 0)
        if lv_pct >= 20:
            score += 10
            reasons.append(f"行政级别'{level}'匹配（{lv_pct}%）")
        elif lv_pct >= 10:
            score += 5
        
        # 5. 采购活跃度
        if features.get("project_count", 0) >= 3:
            score += 10
        elif features.get("project_count", 0) >= 1:
            score += 5
        
        # 6. 品类多样性
        if features.get("product_count", 0) >= 3:
            score += 5
            reasons.append(f"采购品类多样（{features['product_count']}类）")
        
        # 7. 历史采购额匹配买家画像平均
        avg = profile.get("avg_spend", 0)
        if avg > 0 and features.get("total_spend", 0) >= avg * 0.3:
            score += 5
        
        return {"score": min(score, 100), "reasons": reasons}
    
    def rank_prospects(self, target_product: str, top_n: int = 50,
                       filter_user_types: list = None,
                       min_score: int = 30,
                       province_code: str = None,
                       family: list = None,
                       allow_cross_product: bool = False) -> dict:
        """
        旧版跨品类 lookalike。v2 默认禁用（allow_cross_product=False）。
        单品类隔离子图下 nontarget 为空，应改用 prospects_from_scene。
        """
        if not allow_cross_product:
            profile = self.build_profile(
                target_product,
                filter_user_types=filter_user_types,
                province_code=province_code,
                family=family,
            )
            return {"profile": profile, "prospects": [], "disabled": True,
                    "reason": "跨品类特征拟合已禁用；请用场景未购/盲区作为潜客池"}

        family_set = set(family or [target_product])
        profile = self.build_profile(
            target_product,
            filter_user_types=filter_user_types,
            province_code=province_code,
            family=family,
        )
        buyers = self.store.find_entities(EntityType.COMPANY)
        
        prospects = []
        for b in buyers:
            if b.properties.get("type") != "buyer":
                continue
            if province_code and b.properties.get("proviceCode") != province_code:
                continue
            f = self.extract_features(b)
            if f["project_count"] == 0:
                continue
            if set(f.get("products", [])) & family_set:
                continue
            
            # 默认只推荐终端用户类型的单位
            ut = f.get("user_type", "")
            if ut in ("运营商/集成商", "集成商/供应商", "企业"):
                continue
            
            result = self.score_buyer(f, profile)
            if result["score"] >= min_score:
                prospects.append({
                    "name": f["name"],
                    "phone": f["phone"],
                    "user_type": ut,
                    "level": f.get("level", ""),
                    "amount_bucket": f["amount_bucket"],
                    "total_spend": f.get("total_spend", 0),
                    "project_count": f["project_count"],
                    "existing_products": f.get("products", []),
                    "score": result["score"],
                    "reasons": result["reasons"],
                })
        
        return {
            "profile": profile,
            "prospects": sorted(prospects, key=lambda x: -x["score"])[:top_n],
        }


if __name__ == "__main__":
    store = GraphStore()
    matcher = FeatureMatcher(store)
    
    target = "信号屏蔽器"
    print(f"=== {target} 买家画像（终端用户） ===\n")
    
    result = matcher.rank_prospects(
        target,
        top_n=30,
        filter_user_types=["政府/事业单位", "学校", "医院"],
    )
    profile = result["profile"]
    
    print(f"已购客户（终端用户）: {profile['target_count']}家")
    print(f"潜在客户池: {profile['nontarget_count']}家")
    print(f"平均采购额: {profile['avg_spend']}万")
    
    print(f"\n用户类型分布:")
    for t, info in sorted(profile["user_type_profile"].items(), key=lambda x: -x[1]["count"]):
        print(f"  {t}: {info['count']}家({info['pct']}%)")
    
    print(f"\n金额区间:")
    for ab, info in sorted(profile["amount_profile"].items(), key=lambda x: -x[1]["count"]):
        print(f"  {ab}: {info['count']}家({info['pct']}%)")
    
    print(f"\n行政级别:")
    for lv, info in sorted(profile["level_profile"].items(), key=lambda x: -x[1]["count"]):
        print(f"  {lv}: {info['count']}家({info['pct']}%)")
    
    print(f"\n=== 潜力客户排名（Top 20） ===\n")
    for p in result["prospects"][:20]:
        phone_str = f" ☎ {p['phone']}" if p['phone'] not in ("待确认", "") else ""
        print(f"  [{p['score']:2d}分] {p['name']}{phone_str}")
        print(f"    类型: {p['user_type']} | 级别: {p['level']} | 金额: {p['amount_bucket']}({p.get('total_spend','?')}万) | 项目: {p['project_count']}个")
        print(f"    已购: {p['existing_products'][:5]}")
        for r in p['reasons'][:3]:
            print(f"      → {r}")
        print()
