"""
统一查询接口（被 skill 调用）

v0.5 — 政策因子分析强制内置
  rank_prospects() 自动触发政策因子采集+分析
  输出始终附带 policy_impact 字段
"""
from graph_store import GraphStore
from matrix_ops import MatrixOps
from inference import InferenceEngine
from feature_matcher import FeatureMatcher
from policy_fetcher import PolicyFactorEngine, generate_mock_signals
from guidance_fetcher import GuidanceEngine
import os


class KGQuery:
    def __init__(self):
        self.store = GraphStore()
        self.mo = MatrixOps(self.store)
        self.engine = InferenceEngine(self.store)
        self.matcher = FeatureMatcher(self.store)
        self.policy_engine = None
        self.guidance_engine = None
    
    # ---------- 图谱统计 ----------
    
    def get_stats(self) -> dict:
        s = self.store.stats()
        s["products"] = list(self.mo.product_names.values())
        return s
    
    def get_all_products(self) -> list:
        return self.mo.product_names.values()
    
    # ---------- 符号层 ----------
    
    def get_symbol_table(self) -> dict:
        """返回各类型实体的数量"""
        return {
            "buyers": self.mo._n_buyers,
            "suppliers": self.mo._n_suppliers,
            "products": self.mo._n_products,
            "matrix_shapes": {
                "M_AD": list(self.mo.M_AD.shape) if self.mo.M_AD is not None else None,
                "M_BD": list(self.mo.M_BD.shape) if self.mo.M_BD is not None else None,
                "T_A_F": list(self.mo.T_A_F.shape) if self.mo.T_A_F is not None else None,
            }
        }
    
    # ---------- 矩阵运算 ----------
    
    def product_similarity(self, p1: str, p2: str) -> dict:
        return self.mo.product_similarity(p1, p2)
    
    def buyer_similarity(self, b1: str, b2: str) -> dict:
        return self.mo.buyer_similarity(b1, b2)
    
    def supplier_centrality(self, top_n: int = 20, product_filter: str = None) -> list:
        return self.mo.supplier_centrality(top_n, product_filter)
    
    def buyer_centrality(self, top_n: int = 20, product_filter: str = None) -> list:
        return self.mo.buyer_centrality(top_n, product_filter)
    
    def association_rules(self, min_support: int = 2, min_confidence: float = 0.1) -> list:
        return self.mo.association_rules(min_support, min_confidence)
    
    def recommend_suppliers_for_buyer(self, buyer: str, top_n: int = 10) -> list:
        return self.mo.recommend_suppliers_for_buyer(buyer, top_n)
    
    def recommend_suppliers_by_product(self, product: str, top_n: int = 10) -> list:
        return self.mo.recommend_suppliers_by_product(product, top_n)
    
    def recommend_products_for_buyer(self, buyer: str, top_n: int = 5) -> list:
        return self.mo.recommend_products_for_buyer(buyer, top_n)
    
    def recommend_products_for_industry(self, industry: str, top_n: int = 5) -> list:
        return self.mo.recommend_products_for_industry(industry, top_n)
    
    # ---------- 商业推理 ----------
    
    def predict_needs(self, product: str) -> list:
        return self.engine.predict_potential_needs(product)
    
    def find_suppliers(self, product: str) -> list:
        return self.engine.find_cooperatable_suppliers(product)
    
    def find_scene_buyers(self, product: str) -> dict:
        return self.engine.find_target_scene_buyers(product)
    
    def rank_prospects(self, product: str, top_n: int = 50, min_score: int = 30,
                       region: str = "陕西+甘肃") -> dict:
        """
        排名潜在客户——强制附带政策因子分析。
        无论是否提供厂商策略信号，政策因子分析始终执行。
        """
        # 【强制】政策因子分析 - 每次ranking必须执行
        try:
            policy = self.fetch_policy_signals(product, region=region)
        except Exception as e:
            import logging
            logging.getLogger("KGQuery").warning(f"政策因子分析失败: {e}")
        
        return self.matcher.rank_prospects(product, top_n, min_score)
    
    # ---------- 统一入口 ----------
    
    def search(self, query_type: str, **kwargs) -> dict:
        dispatch = {
            "stats": lambda: self.get_stats(),
            "symbols": lambda: self.get_symbol_table(),
            "products": lambda: list(self.get_all_products()),
            "product_sim": lambda: self.product_similarity(**kwargs),
            "buyer_sim": lambda: self.buyer_similarity(**kwargs),
            "suppliers": lambda: self.supplier_centrality(**kwargs),
            "buyers": lambda: self.buyer_centrality(**kwargs),
            "rules": lambda: self.association_rules(**kwargs),
            "rec_suppliers_for_buyer": lambda: self.recommend_suppliers_for_buyer(**kwargs),
            "rec_suppliers_by_product": lambda: self.recommend_suppliers_by_product(**kwargs),
            "rec_products": lambda: self.recommend_products_for_buyer(**kwargs),
            "rec_industry": lambda: self.recommend_products_for_industry(**kwargs),
            "predict_needs": lambda: self.predict_needs(**kwargs),
            "rank_prospects": lambda: self.rank_prospects(**kwargs),
        }
        handler = dispatch.get(query_type)
        if handler:
            return {"type": query_type, "data": handler()}
        return {"type": "error", "data": f"Unknown query: {query_type}"}



    # ---------- 政策因子 ----------
    
    def init_policy_engine(self, force_refresh: bool = False):
        """初始化政策引擎（懒加载，但 rank_prospects 会自动调用）"""
        self.policy_engine = PolicyFactorEngine(self.store)
        return self.policy_engine
    
    def fetch_policy_signals(self, product: str, region: str = "陕西") -> dict:
        """
        采集并分析政策信号。
        
        数据源说明：
          - 政策因子使用搜索引擎（Bing）采集政策文件，不走世舶API
          - 当前未配置 BING_SEARCH_API_KEY → 使用模拟信号
          - 配置后自动切换为真实搜索
        """
        if self.policy_engine is None:
            self.init_policy_engine()
        
        signals = generate_mock_signals(product, region)
        self.policy_engine.build_policy_matrices(signals)
        impact = self.policy_engine.analyze_policy_impact(signals)
        
        # 缓存最近一次政策影响，供报告输出使用
        self._last_policy_impact = impact
        self._last_policy_count = len(signals)
        return {"signals": signals, "impact": impact}
    
    def recommend_with_policy(self, buyer_name: str, top_n: int = 5, alpha: float = 0.25) -> list:
        """政策增强推荐"""
        return self.mo.recommend_with_policy(buyer_name, self.policy_engine, top_n, alpha)



    # ---------- 厂商策略信号 ----------
    
    def init_guidance_engine(self):
        """初始化策略信号引擎"""
        self.guidance_engine = GuidanceEngine(self.store)
        return self.guidance_engine
    
    def import_meeting_notes(self, notes: list) -> dict:
        """导入会议纪要 → 解析信号 → 构建G_matrix"""
        if self.guidance_engine is None:
            self.init_guidance_engine()
        count = self.guidance_engine.add_notes(notes)
        self.guidance_engine.build_guidance_matrix()
        return {
            "imported": len(notes),
            "parsed_signals": count,
            "summary": self.guidance_engine.get_signal_summary(),
        }
    
    def recommend_with_guidance(self, buyer_name: str, top_n: int = 5, alpha: float = 0.15) -> list:
        """策略信号增强推荐"""
        from matrix_ops import MatrixOps
        mo = MatrixOps(self.store)
        M_final = self.guidance_engine.apply_guidance_factor(mo.M_AD_norm, alpha)
        # 临时用mo的方法做推荐，但用增强后的矩阵
        results = mo.recommend_products_for_buyer(buyer_name, top_n)
        for r in results:
            expl = self.guidance_engine.generate_guidance_explanation(r["product"])
            if expl:
                r["guidance_signals"] = expl
        return results


if __name__ == "__main__":
    import json
    kg = KGQuery()
    
    print("=== 符号表状态 ===")
    print(json.dumps(kg.get_symbol_table(), ensure_ascii=False, indent=2))
    
    print("\n=== 全品类 ===")
    print(list(kg.get_all_products()))
    
    print("\n=== 关联规则 Top 5 ===")
    for r in kg.association_rules()[:5]:
        print(f"  {r['interpretation']}  置信度={r['confidence_label']}")
    
    print("\n=== 供应商中心度 Top 5 ===")
    for s in kg.supplier_centrality(5):
        print(f"  [{s['score']}] {s['name']}  置信度={s['confidence']}")
    
    print("\n=== 给陕师大推荐品类 ===")
    for r in kg.recommend_products_for_buyer("陕西师范大学"):
        print(f"  {r['product']}: {r['reason']}  置信度={r['confidence']}")
