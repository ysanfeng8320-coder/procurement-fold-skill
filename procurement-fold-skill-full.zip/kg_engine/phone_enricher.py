"""
联系方式补齐（v0.3）

直销客户（如某公安局）本身往往没有公开采购电话。
高 ROI 策略：优先拿到「常中标该客户的集成商」电话，作为联系路径。

优先级：
  1. 从 scout_data 公告 content HTML 抠号（世舶历史数据常有）
  2. 本地 contacts.json
  3. 世舶详情 API（Key 可用时）
  4. 知了列表（通常无电话，仅作兜底）

报告侧：
  - 客户本人有号 → 展示
  - 否则展示「经集成商联系：XX ☎…」
  - 都没有 → 待确认（禁止省略字段）
"""
import json, os, re, time, logging, glob, html
from typing import List

import requests

KG_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(KG_DIR, "..", "scout_data")
CONTACTS_FILE = os.path.join(KG_DIR, "data/contacts.json")
LOG = logging.getLogger("phone_enricher")

PHONE_RE = re.compile(r"(?<!\d)(1[3-9]\d{9}|0\d{2,3}-?\d{7,8})(?!\d)")
FAKE_PHONES = {"0000000000", "11111111111", "12345678901", "10000000000"}

SHIBO_KEY = (os.environ.get("SHIBO_API_KEY") or os.environ.get("GOVBID_API_KEY") or "").strip()
SHIBO_BASE = "https://gate.gov-bid.com/outer-gateway"
ZHILIAO_KEY = (
    os.environ.get("ZHILIAO_API_KEY")
    or os.environ.get("ZLBX_API_KEY")
    or ""
).strip()
ZHILIAO_BASE = "https://mcp-server.zhiliaobiaoxun.com"


def load_contacts() -> dict:
    if os.path.exists(CONTACTS_FILE):
        with open(CONTACTS_FILE) as f:
            return json.load(f)
    return {}


def save_contacts(contacts: dict):
    os.makedirs(os.path.dirname(CONTACTS_FILE), exist_ok=True)
    with open(CONTACTS_FILE, "w") as f:
        json.dump(contacts, f, ensure_ascii=False, indent=2)


def is_real_phone(phone: str) -> bool:
    if not phone or phone in ("待确认", "待补充", ""):
        return False
    m = PHONE_RE.search(str(phone))
    if not m:
        return False
    return m.group(1) not in FAKE_PHONES


def _clean_html(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", " ", str(text))
    return html.unescape(text)


def extract_phone_from_obj(obj) -> str:
    if obj is None:
        return ""
    if isinstance(obj, str):
        m = PHONE_RE.search(obj)
        if m and m.group(1) not in FAKE_PHONES:
            return m.group(1)
        return ""
    if isinstance(obj, dict):
        for k in ("partAPhone", "partBPhone", "phone", "mobile", "tel",
                  "buyerPhone", "supplierPhone", "contact_phone", "linkPhone"):
            v = obj.get(k)
            if v and is_real_phone(str(v)):
                return PHONE_RE.search(str(v)).group(1)
        for v in obj.values():
            p = extract_phone_from_obj(v)
            if p:
                return p
    if isinstance(obj, list):
        for v in obj:
            p = extract_phone_from_obj(v)
            if p:
                return p
    return ""


def _assign_phone_from_content(content: str, buyers: list, suppliers: list) -> dict:
    """从公告正文把电话挂到采购方/供应商。默认优先供应商。"""
    text = _clean_html(content)
    if not text:
        return {}
    assigned = {}
    for m in PHONE_RE.finditer(text):
        phone = m.group(1)
        if phone in FAKE_PHONES:
            continue
        start = max(0, m.start() - 40)
        end = min(len(text), m.end() + 40)
        window = text[start:end]
        hit = None
        for s in suppliers:
            if s and s[:6] in window:
                hit = s
                break
        if not hit:
            for b in buyers:
                if b and b[:6] in window:
                    hit = b
                    break
        if not hit:
            if any(k in window for k in ("供应商", "中标", "成交人", "乙方", "服务商")):
                if suppliers:
                    hit = suppliers[0]
            elif any(k in window for k in ("采购人", "采购单位", "甲方", "联系人")):
                if suppliers:
                    hit = suppliers[0]
                elif buyers:
                    hit = buyers[0]
            elif suppliers:
                hit = suppliers[0]
            elif buyers:
                hit = buyers[0]
        if hit and hit not in assigned:
            assigned[hit] = phone
    return assigned


def harvest_phones_from_scout_data(save: bool = True) -> dict:
    """扫描全部 scout_data，从 content/ext 抠电话写入 contacts.json。"""
    from builder import load_records_from_file

    contacts = load_contacts()
    before = sum(1 for v in contacts.values() if is_real_phone(v))
    new = 0
    files = sorted(glob.glob(os.path.join(DATA_DIR, "*.json")))
    for fpath in files:
        try:
            records = load_records_from_file(fpath)
        except Exception:
            continue
        for item in records:
            if not isinstance(item, dict):
                continue
            buyers = [n.strip() for n in (item.get("partANameList") or []) if n and n.strip()]
            if not buyers and item.get("partAName"):
                buyers = [item["partAName"].strip()]
            suppliers = [n.strip() for n in (item.get("partBNameList") or []) if n and n.strip()]
            if not suppliers and item.get("partBName"):
                suppliers = [item["partBName"].strip()]

            ext = item.get("extract") or item.get("ext") or {}
            if isinstance(ext, str):
                try:
                    ext = json.loads(ext)
                except Exception:
                    ext = {}
            if isinstance(ext, dict):
                pa = ext.get("partAPhone") or ext.get("buyerPhone")
                pb = ext.get("partBPhone") or ext.get("supplierPhone")
                if is_real_phone(str(pa or "")) and buyers:
                    phone = PHONE_RE.search(str(pa)).group(1)
                    if not is_real_phone(contacts.get(buyers[0], "")):
                        contacts[buyers[0]] = phone
                        new += 1
                if is_real_phone(str(pb or "")) and suppliers:
                    phone = PHONE_RE.search(str(pb)).group(1)
                    if not is_real_phone(contacts.get(suppliers[0], "")):
                        contacts[suppliers[0]] = phone
                        new += 1

            mapped = _assign_phone_from_content(item.get("content") or "", buyers, suppliers)
            for name, phone in mapped.items():
                if not is_real_phone(contacts.get(name, "")):
                    contacts[name] = phone
                    new += 1

    if save:
        save_contacts(contacts)
    after = sum(1 for v in contacts.values() if is_real_phone(v))
    return {
        "files_scanned": len(files),
        "new_assignments": new,
        "real_phones_before": before,
        "real_phones_after": after,
        "contacts": contacts,
    }


def build_contact_path(buyer_name: str, integrators: list = None,
                       contacts: dict = None) -> dict:
    """为直销/已购客户生成可执行联系路径（本人号 或 经集成商）。"""
    contacts = contacts or load_contacts()
    integrators = integrators or []
    buyer_phone = contacts.get(buyer_name, "")
    if not is_real_phone(buyer_phone):
        buyer_phone = "待确认"

    paths = []
    if is_real_phone(buyer_phone):
        paths.append({
            "role": "采购单位",
            "name": buyer_name,
            "phone": buyer_phone,
            "deal_count": None,
            "note": "单位公开联系方式",
        })

    for it in integrators:
        name = it.get("name") if isinstance(it, dict) else str(it)
        phone = (it.get("phone") if isinstance(it, dict) else None) or contacts.get(name, "")
        if not is_real_phone(phone):
            continue
        paths.append({
            "role": "曾合作集成商",
            "name": name,
            "phone": PHONE_RE.search(str(phone)).group(1),
            "deal_count": it.get("deal_count") if isinstance(it, dict) else None,
            "note": "经集成商转介绍/联合跟进该直销客户",
            "in_family": it.get("in_family") if isinstance(it, dict) else None,
        })

    if paths and paths[0]["role"] == "采购单位":
        path_type = "direct"
        display = f"直联 ☎ {paths[0]['phone']}"
        if len(paths) > 1:
            display += "；亦可经 " + "、".join(
                f"{p['name']}☎{p['phone']}" for p in paths[1:3]
            )
    elif paths:
        path_type = "via_integrator"
        display = "经集成商联系：" + "；".join(
            f"{p['name']}☎{p['phone']}"
            + (f"（合作{p['deal_count']}次）" if p.get("deal_count") else "")
            for p in paths[:3]
        )
    else:
        path_type = "none"
        display = "联系路径待补充（单位与集成商均无可用电话）"

    return {
        "buyer_phone": buyer_phone,
        "path_type": path_type,
        "paths": paths,
        "display": display,
    }


def attach_contact_paths(rows: list, contacts: dict = None) -> list:
    contacts = contacts or load_contacts()
    out = []
    for r in rows:
        row = dict(r)
        name = row.get("name", "")
        ints = []
        for it in row.get("integrators") or []:
            item = dict(it)
            sp = contacts.get(item.get("name", "")) or item.get("phone") or "待确认"
            item["phone"] = PHONE_RE.search(str(sp)).group(1) if is_real_phone(sp) else "待确认"
            ints.append(item)
        row["integrators"] = ints
        path = build_contact_path(name, ints, contacts)
        row["phone"] = path["buyer_phone"]
        row["contact_path"] = path
        row["contact_display"] = path["display"]
        out.append(row)
    return out


def get_phone_from_shibiao(company_name: str) -> str:
    if not SHIBO_KEY:
        return ""
    try:
        resp = requests.post(
            f"{SHIBO_BASE}/bid/getZTBStructreDetail",
            headers={"Content-Type": "application/json", "X-Api-Key": SHIBO_KEY},
            json={"keyWord": company_name},
            timeout=15,
        )
        if resp.status_code != 200:
            return ""
        data = resp.json()
        if data.get("code") == 403:
            return ""
        return extract_phone_from_obj(data)
    except Exception as e:
        LOG.warning("世舶电话查询失败 %s: %s", company_name, e)
        return ""


def get_phone_from_zhiliao(company_name: str, province: str = None) -> str:
    if not ZHILIAO_KEY:
        return ""
    try:
        payload = {"keywords": [company_name[:20]], "page_size": 5, "page": 1}
        if province:
            payload["provinces"] = [province]
        resp = requests.post(
            f"{ZHILIAO_BASE}/api_v2/search_bids",
            headers={"Content-Type": "application/json", "X-API-Key": ZHILIAO_KEY},
            json=payload,
            timeout=20,
        )
        if resp.status_code != 200:
            return ""
        return extract_phone_from_obj(resp.json())
    except Exception as e:
        LOG.warning("知了电话查询失败 %s: %s", company_name, e)
        return ""


def enrich_names(
    names: List[str],
    province: str = None,
    max_api_calls: int = 30,
    use_zhiliao: bool = True,
    use_shibiao: bool = True,
    harvest_first: bool = True,
) -> dict:
    if harvest_first:
        harvest_phones_from_scout_data(save=True)

    contacts = load_contacts()
    found = 0
    missing = 0
    api_calls = 0
    uniq, seen = [], set()
    for n in names:
        if not n or n in seen:
            continue
        seen.add(n)
        uniq.append(n)

    for name in uniq:
        cur = contacts.get(name, "")
        if is_real_phone(cur):
            found += 1
            continue

        phone = ""
        if use_shibiao and api_calls < max_api_calls:
            phone = get_phone_from_shibiao(name)
            api_calls += 1
            time.sleep(0.2)
        if not phone and use_zhiliao and api_calls < max_api_calls:
            phone = get_phone_from_zhiliao(name, province=province)
            api_calls += 1
            time.sleep(0.25)

        if is_real_phone(phone):
            contacts[name] = phone
            found += 1
        else:
            contacts[name] = contacts.get(name) or "待确认"
            missing += 1

    save_contacts(contacts)
    total = max(len(uniq), 1)
    return {
        "contacts": contacts,
        "found": found,
        "missing": missing,
        "api_calls": api_calls,
        "coverage": round(found / total, 3),
        "queried": len(uniq),
    }


def apply_phones_to_rows(rows: list, contacts: dict = None) -> list:
    return attach_contact_paths(rows, contacts or load_contacts())


def get_phone_from_api(company_name: str) -> str:
    return get_phone_from_shibiao(company_name) or get_phone_from_zhiliao(company_name)


def batch_enrich_phones(max_calls: int = 100):
    harvest_phones_from_scout_data(save=True)
    from builder import collect_scout_files, load_records_from_file
    names = set()
    for fpath, _ in collect_scout_files():
        for r in load_records_from_file(fpath):
            if not isinstance(r, dict):
                continue
            for pa in r.get("partANameList") or []:
                if pa:
                    names.add(pa.strip())
            for pb in r.get("partBNameList") or []:
                if pb:
                    names.add(pb.strip())
    return enrich_names(list(names), max_api_calls=max_calls, harvest_first=False)


def search_procurement_by_name(company_name: str, provice_code: str = "620000",
                               max_calls: int = 3) -> dict:
    result = {
        "found": False, "records": [], "phone": "",
        "total_procurement": 0.0, "api_calls_used": 0,
    }
    phone = get_phone_from_shibiao(company_name)
    result["api_calls_used"] = 1
    if phone:
        result["phone"] = phone
        result["found"] = True
    return result


def batch_backfill_blind_spots(blind_entities: list, max_calls: int = 50) -> dict:
    found, not_found, calls = [], [], 0
    for name in blind_entities:
        if calls >= max_calls:
            break
        r = search_procurement_by_name(name)
        calls += r.get("api_calls_used", 1)
        if r.get("phone") or r.get("found"):
            found.append({"name": name, "phone": r.get("phone", ""), "records_count": 0, "total_procurement": 0})
        else:
            not_found.append(name)
        time.sleep(0.3)
    return {"found": found, "not_found": not_found, "api_calls_used": calls}


if __name__ == "__main__":
    stats = harvest_phones_from_scout_data()
    print(json.dumps({k: v for k, v in stats.items() if k != "contacts"},
                     ensure_ascii=False, indent=2))
