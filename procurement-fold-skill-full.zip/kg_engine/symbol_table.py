"""
符号表（Symbol Table）
把每个实体映射为一个数值索引，建立实体↔索引的双向查找。
这是所有矩阵/张量计算的基础。

符号映射规则:
  A → 采购方（Buyer）
  B → 供应商/中标方（Winner/Supplier）
  C → 项目（Project）
  D → 产品/服务（Product）
  E → 地区（Region）
  F → 时间窗口（TimePeriod, 按月）
  G → 属性/量化特征（Attribute）
"""
import json, os
from collections import defaultdict

KG_DIR = os.path.dirname(os.path.abspath(__file__))
GRAPH_FILE = os.path.join(KG_DIR, "data/graph.json")
SYMBOL_FILE = os.path.join(KG_DIR, "data/symbol_table.json")


class SymbolTable:
    """符号表：实体ID ↔ 数值索引的双向映射"""
    
    def __init__(self):
        self.indices = {}       # entity_id → 整数索引
        self.entities = {}      # 整数索引 → entity_info
        self.dirty = False
    
    def register(self, entity_id: str, entity_type: str, name: str):
        """注册一个实体，自动分配递增索引"""
        if entity_id not in self.indices:
            idx = len(self.indices)
            self.indices[entity_id] = idx
            self.entities[idx] = {
                "id": entity_id,
                "type": entity_type,
                "name": name,
            }
            self.dirty = True
    
    def idx(self, entity_id: str) -> int:
        """获取实体ID对应的索引"""
        return self.indices.get(entity_id, -1)
    
    def entity(self, idx: int) -> dict:
        """获取索引对应的实体信息"""
        return self.entities.get(idx, {})
    
    def count(self) -> dict:
        """各类实体数量"""
        from collections import Counter
        return Counter(e["type"] for e in self.entities.values())
    
    def save(self):
        with open(SYMBOL_FILE, "w") as f:
            json.dump({
                "indices": self.indices,
                "entities": self.entities,
            }, f, ensure_ascii=False, indent=2)
    
    @classmethod
    def load(cls):
        st = cls()
        if os.path.exists(SYMBOL_FILE):
            with open(SYMBOL_FILE) as f:
                data = json.load(f)
            st.indices = data.get("indices", {})
            st.entities = {int(k): v for k, v in data.get("entities", {}).items()}
        return st
    
    @classmethod
    def build_from_graph(cls, graph_file: str = GRAPH_FILE) -> "SymbolTable":
        """从图谱JSON重建符号表"""
        from graph_store import GraphStore
        store = GraphStore()
        
        st = cls()
        for eid, entity in store.graph.entities.items():
            st.register(eid, entity.type.value, entity.name)
        
        st.save()
        print(f"符号表: {len(st.indices)}个实体")
        for t, c in st.count().most_common():
            print(f"  {t}: {c}")
        return st


def build_tensor_indices():
    """
    构建张量索引：把符号分离到不同类型
    返回:
      buyer_index: {entity_id → idx}
      supplier_index: {entity_id → idx}
      product_index: {entity_id → idx}
      project_index: {entity_id → idx}
      region_index: {entity_id → idx}
    """
    from graph_store import GraphStore
    from schema import EntityType
    
    store = GraphStore()
    
    buyer_index = {}
    supplier_index = {}
    product_index = {}
    project_index = {}
    region_index = {}
    
    for eid, e in store.graph.entities.items():
        if e.type == EntityType.COMPANY:
            if e.properties.get("type") == "buyer":
                buyer_index[eid] = len(buyer_index)
            elif e.properties.get("type") == "supplier":
                supplier_index[eid] = len(supplier_index)
        elif e.type == EntityType.PRODUCT:
            product_index[eid] = len(product_index)
        elif e.type == EntityType.PROJECT:
            project_index[eid] = len(project_index)
        elif e.type == EntityType.REGION:
            region_index[eid] = len(region_index)
    
    indices = {
        "buyer": buyer_index,
        "supplier": supplier_index,
        "product": product_index,
        "project": project_index,
        "region": region_index,
    }
    print("张量索引:")
    for name, idx in indices.items():
        print(f"  {name}: {len(idx)}")
    return indices


if __name__ == "__main__":
    print("=== 构建符号表 ===")
    st = SymbolTable.build_from_graph()
    
    print("\n=== 构建张量索引 ===")
    build_tensor_indices()
