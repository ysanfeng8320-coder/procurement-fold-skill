"""
单品类数据面（Product Scope）

每次侦察只允许一个同义词族进入图谱与推理。
"""
from typing import List, Optional, Set, Tuple

# 同义词族：key = 规范品类名（报告/矩阵用）
PRODUCT_FAMILIES = {
    "印控仪": [
        "印控仪", "印控台", "智能印章", "电子印章", "盖章机",
        "印章管理系统", "用印宝", "用印柜", "印章",
    ],
    "碎纸机": ["碎纸机", "销毁设备"],
    "信号屏蔽器": ["信号屏蔽器", "屏蔽器", "屏蔽设备"],
    "塑胶跑道": ["塑胶跑道", "跑道"],
    "旗杆": ["旗杆", "国旗杆"],
    "装订机": ["装订机"],
    "复印机": ["复印机"],
    "打印机": ["打印机"],
    "扫描仪": ["扫描仪"],
    "多功能一体机": ["多功能一体机", "一体机"],
    "支票打印机": ["支票打印机", "票据打印"],
    "办公设备": ["办公设备", "办公用品"],
}

# 永远不得进入「办公邻域」扩展
FORBIDDEN_PRODUCTS = {
    "塑胶跑道", "旗杆", "体育设施", "空调", "计算机/电脑", "服务器",
}

# 可选邻域（默认关闭）
OFFICE_NEIGHBORHOOD = {
    "碎纸机", "装订机", "复印机", "打印机", "扫描仪",
    "多功能一体机", "支票打印机",
}

REGION_CODES = {"陕西": "610000", "甘肃": "620000"}
CODE_TO_REGION = {v: k for k, v in REGION_CODES.items()}


def resolve_family(product: str) -> Tuple[str, List[str]]:
    """
    返回 (canonical, family_synonyms)。
    未知品类 → 自身作为单元素族。
    """
    if not product:
        raise ValueError("product 不能为空")
    if product in PRODUCT_FAMILIES:
        return product, list(PRODUCT_FAMILIES[product])
    for canonical, syns in PRODUCT_FAMILIES.items():
        if product in syns or any(product in s or s in product for s in syns):
            return canonical, list(syns)
    return product, [product]


def allowed_products(canonical: str, neighborhood: bool = False) -> Set[str]:
    _, family = resolve_family(canonical)
    allowed = set(family) | {canonical}
    if neighborhood:
        allowed |= OFFICE_NEIGHBORHOOD
    return allowed - FORBIDDEN_PRODUCTS


def scope_id(canonical: str, region: str) -> str:
    return f"{canonical}_{region}"


def qa_check_products(products: List[str], canonical: str,
                      neighborhood: bool = False) -> List[str]:
    """返回违规品类名列表；空列表 = 通过。"""
    allowed = allowed_products(canonical, neighborhood)
    bad = []
    for p in products:
        if p not in allowed:
            bad.append(p)
        if p in FORBIDDEN_PRODUCTS and canonical not in PRODUCT_FAMILIES.get(p, [p]):
            if p not in bad:
                bad.append(p)
    # 额外：规范品类不是体育族时，禁止出现禁品
    if canonical not in ("塑胶跑道", "旗杆"):
        for p in products:
            if p in FORBIDDEN_PRODUCTS and p not in bad:
                bad.append(p)
    return bad
