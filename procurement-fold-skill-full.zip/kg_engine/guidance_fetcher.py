"""
厂商策略信号模块（v0.1）

把厂家的会议纪要/培训笔记/业务沟通 → 结构化策略信号 → G矩阵。

符号定义：
  G — 厂商策略信号（Manufacturer Guidance）
    G_S: 策略方向（strategic）—— 厂家要主推的品类/行业
    G_P: 价格信号（pricing）  —— 价格调整/促销
    G_C: 竞争情报（competitive）—— 竞品动态
    G_R: 渠道政策（channel）  —— 返点/代理政策/考核
    G_T: 时间窗口（timing）   —— 季度重点/月底冲量

融合方式：
  M_AD_final = (1 - α - β) × M_AD_norm + α × (P_A @ P_D^T) + β × G_matrix

  其中 G_matrix = G_S + G_P + G_C + ... 加权后的增强矩阵
"""
import json, os, re, logging
from collections import defaultdict
from datetime import datetime

import numpy as np
from scipy.sparse import csr_matrix, coo_matrix

from graph_store import GraphStore
from schema import EntityType, RelationType

KG_DIR = os.path.dirname(os.path.abspath(__file__))
LOG = logging.getLogger("guidance_fetcher")

# ========== 策略信号类型 ==========

SIGNAL_TYPES = {
    "G_S": "策略方向（厂家主推品类/行业）",
    "G_P": "价格信号（降价/促销/涨价）",
    "G_C": "竞争情报（竞品动态/报价信息）",
    "G_R": "渠道政策（返点/考核/代理政策）",
    "G_T": "时间窗口（季度重点/冲量/限期）",
}

# ========== 会议纪要解析器 ==========

class MeetingNoteParser:
    """
    把厂家的会议纪要/培训笔记文本解析为结构化信号。
    
    输入：文字段落
    输出：结构化信号数组
    
    解析策略：
      - 关键词触发 → 识别信号类型
      - 数字/金额/百分比 → 提取量级
      - 品类名 → 对应到图谱中的产品实体
      - 行业/单位名 → 对应到图谱中的采购方/行业
    """
    
    def __init__(self, known_products: list = None, known_industries: list = None):
        self.known_products = known_products or []
        self.known_industries = known_industries or []
    
    def classify_signal_type(self, text: str) -> list:
        """
        从文本中识别信号类型。
        返回 [(signal_type, confidence_score), ...]
        """
        results = []
        
        # G_S 策略方向
        if any(kw in text for kw in ["主推", "重点推", "战略方向", "主打", "卖点", "推荐"]):
            results.append(("G_S", 0.8))
        if any(kw in text for kw in ["行业", "系统", "客户群体"]):
            results.append(("G_S", 0.5))
        
        # G_P 价格信号
        if any(kw in text for kw in ["降价", "涨价", "促销", "特价", "折扣", "优惠", "报价", 
                                       "价格调整", "成本", "预算", "金额", "万", "元"]):
            results.append(("G_P", 0.8))
        
        # G_C 竞争情报
        if any(kw in text for kw in ["竞品", "对手", "竞争", "XX厂", "XX公司", "别人家",
                                       "市场占有率", "低价", "打价格战"]):
            results.append(("G_C", 0.8))
        
        # G_R 渠道政策
        if any(kw in text for kw in ["返点", "代理", "渠道", "考核", "指标", "任务",
                                       "签约", "授权", "资质", "年度目标", "奖励"]):
            results.append(("G_R", 0.8))
        
        # G_T 时间窗口
        if any(kw in text for kw in ["季度", "月底", "年底", "本月", "本季度", "限期",
                                       "冲量", "截止", "deadline", "时间窗口"]):
            results.append(("G_T", 0.8))
        
        return results
    
    def extract_entities(self, text: str) -> dict:
        """
        从文本中提取提及的品类、行业、具体单位名。
        """
        entities = {"products": [], "industries": [], "buyers": []}
        
        # 品类匹配
        for prod in self.known_products:
            if prod in text:
                entities["products"].append(prod)
        
        # 行业匹配（如"公安系统"、"教育"）
        for ind in self.known_industries:
            if ind in text:
                entities["industries"].append(ind)
        
        # 单位名匹配（如"省高级人民法院"）
        return entities
    
    def extract_numeric(self, text: str) -> dict:
        """提取数值信息：金额、比例、时间"""
        info = {}
        
        # 金额：X万、X元
        money = re.findall(r'(\d+[.]?\d*)\s*万', text)
        if money:
            info["amount"] = float(money[0])
        
        # 百分比
        pct = re.findall(r'(\d+)\s*%', text)
        if pct:
            info["percentage"] = int(pct[0])
        
        return info
    
    def parse(self, text: str) -> list:
        """
        解析一条会议记录 → 一条或多条结构化信号。
        """
        signals = []
        
        # 按句号/换行分割
        sentences = re.split(r'[。\n]', text)
        
        for sent in sentences:
            sent = sent.strip()
            if not sent or len(sent) < 5:
                continue
            
            signal_types = self.classify_signal_type(sent)
            if not signal_types:
                continue
            
            entities = self.extract_entities(sent)
            numeric = self.extract_numeric(sent)
            
            for stype, confidence in signal_types:
                signals.append({
                    "signal_type": stype,
                    "signal_name": SIGNAL_TYPES.get(stype, stype),
                    "confidence": confidence,
                    "original_text": sent,
                    "entities": entities,
                    "numeric": numeric,
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M"),
                })
        
        return signals


# ========== 厂商策略信号引擎 ==========

class GuidanceEngine:
    """
    厂商策略信号引擎。
    
    数据来源：会议纪要文本（用户手动输入或文件导入）
    核心输出：G_matrix（采购方×品类 增强矩阵）
    
    使用方式：
      1. 用户导入会议纪要文本
      2. 引擎自动解析为结构化信号
      3. 构建G_matrix
      4. 融合到M_AD_final
    """
    
    def __init__(self, store: GraphStore = None):
        self.store = store or GraphStore()
        self.parser = None
        self.signals = []        # 全部已解析的信号
        self.G_matrix = None     # 增强矩阵（采购方×品类）
        self._built = False
        self._signal_count = 0
    
    def _ensure_parser(self):
        if self.parser is None:
            products = [e.name for e in self.store.find_entities(EntityType.PRODUCT)]
            industries = [e.name for e in self.store.find_entities(EntityType.INDUSTRY)]
            self.parser = MeetingNoteParser(products, industries)
    
    def add_notes(self, notes: list) -> int:
        """
        导入会议纪要。
        notes: [{"title": "XX会议纪要", "content": "厂家说主推碎纸机..."}, ...]
        
        或者直接传文本列表：["会议内容1", "会议内容2"]
        """
        self._ensure_parser()
        count = 0
        
        for item in notes:
            if isinstance(item, str):
                text = item
                title = "未命名纪要"
            elif isinstance(item, dict):
                text = item.get("content", "")
                title = item.get("title", "未命名纪要")
            else:
                continue
            
            signals = self.parser.parse(text)
            for sig in signals:
                sig["source_title"] = title
                self.signals.append(sig)
                count += 1
        
        self._signal_count = len(self.signals)
        LOG.info(f"导入 {len(notes)} 条会议记录，解析出 {count} 条策略信号")
        return count
    
    def get_signal_summary(self) -> list:
        """按信号类型汇总"""
        summary = defaultdict(lambda: {"count": 0, "samples": []})
        for sig in self.signals:
            st = sig["signal_type"]
            summary[st]["count"] += 1
            if len(summary[st]["samples"]) < 3:
                summary[st]["samples"].append(sig["original_text"][:50])
        
        return [
            {
                "type": st,
                "name": SIGNAL_TYPES.get(st, st),
                "count": info["count"],
                "samples": info["samples"],
            }
            for st, info in sorted(summary.items(), key=lambda x: -x[1]["count"])
        ]
    
    def build_guidance_matrix(self) -> csr_matrix:
        """
        构建G_matrix（采购方×品类的策略增强矩阵）。
        
        逻辑：
          1. G_S（策略方向）→ 某个品类获得全局增强 → G_matrix全列加权
          2. G_C（竞争情报）→ 某品类+某行业 → 该行业×该品类加权
          3. G_R（渠道政策）→ 某个区域的代理政策 → 该区域采购方加权
          4. 每条信号都有 confidence 权重
        """
        n_b = len([e for e in self.store.graph.entities.values()
                   if e.type == EntityType.COMPANY and e.properties.get("type") == "buyer"])
        n_p = len([e for e in self.store.graph.entities.values()
                   if e.type == EntityType.PRODUCT])
        
        if n_b == 0 or n_p == 0:
            self.G_matrix = csr_matrix((1, 1))
            self._built = True
            return self.G_matrix
        
        # 采购方→索引
        buyer_to_idx = {}
        for eid, e in self.store.graph.entities.items():
            if e.type == EntityType.COMPANY and e.properties.get("type") == "buyer":
                buyer_to_idx[e.name] = len(buyer_to_idx)
        
        # 品类→索引
        product_to_idx = {}
        self.product_names = {}
        for eid, e in self.store.graph.entities.items():
            if e.type == EntityType.PRODUCT:
                idx = len(product_to_idx)
                product_to_idx[e.name] = idx
                self.product_names[idx] = e.name
        
        # 收集矩阵项
        rows, cols, data = [], [], []
        
        for sig in self.signals:
            st = sig["signal_type"]
            conf = sig["confidence"]
            entities = sig.get("entities", {})
            
            # G_S：品类全局增强
            if st == "G_S":
                for pname in entities.get("products", []):
                    pj = product_to_idx.get(pname)
                    if pj is not None:
                        for bi in range(n_b):
                            rows.append(bi)
                            cols.append(pj)
                            data.append(conf * 0.5)  # 全局增强系数较低
            
            # G_S + 行业：特定行业+品类
            if st in ("G_S",):
                for ind in entities.get("industries", []):
                    # 找到属于该行业的采购方
                    for bname, bi in buyer_to_idx.items():
                        buyer_entity = self._get_buyer_entity(bname)
                        if buyer_entity and ind in buyer_entity.properties.get("industries", []):
                            for pname in entities.get("products", []):
                                pj = product_to_idx.get(pname)
                                if pj is not None:
                                    rows.append(bi)
                                    cols.append(pj)
                                    data.append(conf * 0.8)  # 行业定向增强
            
            # G_P：价格信号 → 品类全体加权略增
            if st == "G_P":
                for pname in entities.get("products", []):
                    pj = product_to_idx.get(pname)
                    if pj is not None:
                        for bi in range(n_b):
                            rows.append(bi)
                            cols.append(pj)
                            data.append(conf * 0.3)
            
            # G_C：竞争情报 → 品类全体加权（要抓紧占领）
            if st == "G_C":
                for pname in entities.get("products", []):
                    pj = product_to_idx.get(pname)
                    if pj is not None:
                        for bi in range(n_b):
                            rows.append(bi)
                            cols.append(pj)
                            data.append(conf * 0.6)
            
            # G_R：渠道政策 → 该区域的采购方全体加权
            if st == "G_R":
                for pi in range(n_p):
                    for bi in range(n_b):
                        rows.append(bi)
                        cols.append(pi)
                        data.append(conf * 0.4)
            
            # G_T：时间窗口 → 全局加权
            if st == "G_T":
                for pi in range(n_p):
                    for bi in range(n_b):
                        rows.append(bi)
                        cols.append(pi)
                        data.append(conf * 0.3)
        
        # 构建稀疏矩阵
        shape = (n_b, n_p)
        if data:
            self.G_matrix = coo_matrix((data, (rows, cols)), shape=shape).tocsr()
            # 归一化
            max_val = self.G_matrix.max()
            if max_val > 0:
                self.G_matrix = self.G_matrix / max_val
        else:
            self.G_matrix = csr_matrix(shape)
        
        self._built = True
        LOG.info(f"G_matrix构建完成: {self.G_matrix.shape}, 非零={self.G_matrix.nnz}")
        return self.G_matrix
    
    def _get_buyer_entity(self, name: str):
        """按名称找采购方实体"""
        cid = self.store.graph.entities.get(
            list(self.store.graph.entities.keys())[0], None
        )
        for e in self.store.graph.entities.values():
            if e.type == EntityType.COMPANY and e.name == name:
                return e
        return None
    
    def apply_guidance_factor(self, M_AD_current, alpha: float = 0.15) -> csr_matrix:
        """
        融合厂商策略信号到推荐矩阵。
        
        M_AD_final = (1 - alpha) × M_AD_current + alpha × G_matrix
        """
        if not self._built or self.G_matrix is None or self.G_matrix.nnz == 0:
            LOG.warning("G_matrix为空，跳过融合")
            return M_AD_current
        
        if self.G_matrix.shape != M_AD_current.shape:
            LOG.warning(f"维度不匹配: G={self.G_matrix.shape}, M_AD={M_AD_current.shape}")
            return M_AD_current
        
        M_AD_final = (1 - alpha) * M_AD_current + alpha * self.G_matrix
        LOG.info(f"策略信号融合: alpha={alpha}, G矩阵非零={self.G_matrix.nnz}")
        
        return M_AD_final
    
    def generate_guidance_explanation(self, product_name: str) -> list:
        """为某个品类生成策略信号解释。"""
        explanations = []
        for sig in self.signals:
            entities = sig.get("entities", {})
            if product_name in entities.get("products", []):
                st = sig["signal_type"]
                sname = SIGNAL_TYPES.get(st, st)
                text = sig["original_text"][:40]
                explanations.append(
                    f"[{sname}] {text}..."
                )
        return explanations
    
    def get_stats(self) -> dict:
        return {
            "total_signals": len(self.signals),
            "by_type": {
                st: sum(1 for s in self.signals if s["signal_type"] == st)
                for st in SIGNAL_TYPES
            },
            "built": self._built,
            "matrix_nnz": self.G_matrix.nnz if self.G_matrix is not None else 0,
        }


# ========== 测试入口 ==========

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    print("=" * 60)
    print("厂商策略信号模块测试")
    print("=" * 60)
    
    from graph_store import GraphStore
    store = GraphStore()
    engine = GuidanceEngine(store)
    
    # 模拟会议纪要
    notes = [
        "厂家说这个季度主推信号屏蔽器，教育行业是重点，学校项目给额外返点。",
        "竞品在陕西报低价冲击碎纸机市场，厂家说我们可以打价格战跟。",
        "厂家通知塑胶跑道新国标下月实施，成本上涨10%，但代理商可以申请补贴。",
        "公安部新政策要求县级单位配信号屏蔽器，是大的机会。",
        "月底冲量，信号屏蔽器完成指标额外奖励2个点。",
    ]
    
    print(f"\n导入 {len(notes)} 条会议纪要...")
    count = engine.add_notes(notes)
    print(f"解析出 {count} 条策略信号")
    
    print(f"\n信号汇总:")
    for item in engine.get_signal_summary():
        print(f"  {item['type']} ({item['name']}): {item['count']}条")
        for s in item['samples']:
            print(f"    例: {s}")
    
    print(f"\n构建 G_matrix...")
    gmat = engine.build_guidance_matrix()
    print(f"  G_matrix: {gmat.shape}, 非零={gmat.nnz}")
    
    print(f"\n为信号屏蔽器生成解释:")
    for e in engine.generate_guidance_explanation("信号屏蔽器")[:5]:
        print(f"  → {e}")
    
    # 在matrix_ops中融合
    from matrix_ops import MatrixOps
    mo = MatrixOps(store)
    M_final = engine.apply_guidance_factor(mo.M_AD_norm, alpha=0.15)
    print(f"\n融合后 M_AD_final: {M_final.shape}")
    
    print(f"\n引擎统计:")
    print(json.dumps(engine.get_stats(), ensure_ascii=False, indent=2))
