"""
数据采集层（v0.1）

统一两个API源：
  1. 世舶（优先）- 额度用完时自动降级
  2. 知了网（备胎）- 世舶不可用时自动切换

下游模块（builder.py）不感知数据来源——collector统一输出兼容格式存入 scout_data/。

字段映射（知了网→世舶）:
  知了网 bid_id          → 世舶 id
  知了网 title           → 世舶 title
  知了网 pub_time        → 世舶 publishTime
  知了网 money_wan       → 世舶 projectMoney（补"万"后缀）
  知了网 province        → 世舶 proviceCode（名称→编码）
  知了网 caller_name     → 世舶 partANameList（单字符串→列表）
  知了网 winner_names    → 世舶 partBNameList（列表→列表，不变）
  知了网 exists_bid_file → 世舶 hasFile
  知了网 sm_names        → 世舶 内容字段（产品名列表）
"""
import json, os, time, logging
from typing import Optional

import requests

KG_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(KG_DIR, "..", "scout_data")

LOG = logging.getLogger(__name__)

# ========== API配置（禁止硬编码 Key；仅读环境变量）==========

SHIBO_KEY = (os.environ.get("SHIBO_API_KEY") or os.environ.get("GOVBID_API_KEY") or "").strip()
SHIBO_BASE = "https://gate.gov-bid.com/outer-gateway"

ZHILIAO_KEY = (
    os.environ.get("ZHILIAO_API_KEY")
    or os.environ.get("ZLBX_API_KEY")
    or ""
).strip()
ZHILIAO_BASE = "https://mcp-server.zhiliaobiaoxun.com"

PROVINCE_NAME_TO_CODE = {
    "北京": "110000",
    "天津": "120000",
    "河北": "130000",
    "山西": "140000",
    "内蒙古": "150000",
    "辽宁": "210000",
    "吉林": "220000",
    "黑龙江": "230000",
    "上海": "310000",
    "江苏": "320000",
    "浙江": "330000",
    "安徽": "340000",
    "福建": "350000",
    "江西": "360000",
    "山东": "370000",
    "河南": "410000",
    "湖北": "420000",
    "湖南": "430000",
    "广东": "440000",
    "广西": "450000",
    "海南": "460000",
    "重庆": "500000",
    "四川": "510000",
    "贵州": "520000",
    "云南": "530000",
    "西藏": "540000",
    "陕西": "610000",
    "甘肃": "620000",
    "青海": "630000",
    "宁夏": "640000",
    "新疆": "650000",
}
PROVINCE_CODE_TO_NAME = {v: k for k, v in PROVINCE_NAME_TO_CODE.items()}


# ========== 世舶采集器 ==========

class ShibiaoCollector:
    def __init__(self):
        self.base = SHIBO_BASE
        self.key = SHIBO_KEY

    def _require_key(self) -> None:
        if not self.key:
            raise RuntimeError(
                "未配置世舶 API Key。请设置环境变量 SHIBO_API_KEY（或 GOVBID_API_KEY）。"
                "无 Key 时可先投喂产品介绍做简易报告，完整拉数分析需自备 Key。"
            )

    def health_check(self) -> bool:
        """检查世舶API是否可用"""
        if not self.key:
            return False
        try:
            r = requests.post(
                f"{self.base}/bid/searchProjectApi",
                headers={"Content-Type": "application/json", "X-Api-Key": self.key},
                json={"keyWord": "碎纸机", "searchType": 2, "proviceCode": "610000",
                      "pageNum": 1, "pageSize": 1},
                timeout=10,
            )
            if r.status_code == 200:
                data = r.json()
                return data.get("code") != 403
            return False
        except Exception:
            return False
    
    def search(self, keyword: str, province_code: str,
               page_num: int = 1, page_size: int = 50) -> dict:
        """世舶搜索，返回原始JSON"""
        self._require_key()
        r = requests.post(
            f"{self.base}/bid/searchProjectApi",
            headers={"Content-Type": "application/json", "X-Api-Key": self.key},
            json={
                "keyWord": keyword,
                "searchType": 2,
                "proviceCode": province_code,
                "pageNum": page_num,
                "pageSize": min(page_size, 50),
            },
            timeout=20,
        )
        r.raise_for_status()
        return r.json()


# ========== 知了网采集器 ==========

class ZhiliaoCollector:
    def __init__(self):
        self.base = ZHILIAO_BASE
        self.key = ZHILIAO_KEY

    def _require_key(self) -> None:
        if not self.key:
            raise RuntimeError(
                "未配置知了网 API Key。请设置环境变量 ZHILIAO_API_KEY（或 ZLBX_API_KEY）。"
                "无 Key 时可先投喂产品介绍做简易报告，完整拉数分析需自备 Key。"
            )

    def health_check(self) -> bool:
        """检查知了网API是否可用"""
        if not self.key:
            return False
        for attempt in range(3):
            try:
                r = requests.post(
                    f"{self.base}/api_v2/search_bids",
                    headers={"Content-Type": "application/json", "X-API-Key": self.key},
                    json={"keywords": ["碎纸机"], "page_size": 1, "page": 1},
                    timeout=15,
                )
                if r.status_code == 200 and r.json().get("success", False):
                    return True
            except Exception:
                time.sleep(0.8 * (attempt + 1))
        return False
    
    def search(self, keyword: str, province_code: str = None,
               page: int = 1, page_size: int = 50,
               begin_date: str = None, end_date: str = None) -> dict:
        """知了网搜索。begin_date/end_date 格式 YYYY-MM-DD，可按发布时间窗过滤。"""
        self._require_key()
        payload = {
            "keywords": [keyword],
            "match_modes": ["all"],
            "page": page,
            "page_size": min(page_size, 100),
            "bid_type": "全部",
        }
        if province_code and province_code in PROVINCE_CODE_TO_NAME:
            payload["provinces"] = [PROVINCE_CODE_TO_NAME[province_code]]
        if begin_date:
            payload["begin_date"] = begin_date
        if end_date:
            payload["end_date"] = end_date

        last_err = None
        for attempt in range(4):
            try:
                r = requests.post(
                    f"{self.base}/api_v2/search_bids",
                    headers={"Content-Type": "application/json", "X-API-Key": self.key},
                    json=payload,
                    timeout=30,
                )
                r.raise_for_status()
                return r.json()
            except Exception as e:
                last_err = e
                time.sleep(1.2 * (attempt + 1))
        raise last_err


# ========== 字段映射器 ==========

def zl_to_shibiao(zl_item: dict) -> dict:
    """将知了网单条数据映射为世舶兼容格式"""
    province_name = (zl_item.get("province") or "").strip()
    province_code = PROVINCE_NAME_TO_CODE.get(province_name, "")
    
    # 金额处理
    money_wan = zl_item.get("money_wan") or 0.0
    money_str = f"{money_wan}万" if money_wan > 0 else "0万"
    
    return {
        "id": zl_item.get("bid_id"),
        "newsTypeID": 1,
        "title": zl_item.get("title", ""),
        "publishTime": zl_item.get("pub_time", ""),
        "projectMoney": money_str,
        "proviceCode": province_code,
        "province": province_name,
        "cityCode": zl_item.get("city", ""),
        "hasFile": zl_item.get("exists_bid_file", 0),
        "partANameList": [zl_item["caller_name"]] if zl_item.get("caller_name") else [],
        "partBNameList": zl_item.get("winner_names", []) or [],
        "content": "",
        # 保留知了网特有字段，供builder使用
        "_source": "zhiliao",
        "_sm_names": zl_item.get("sm_names", []),
        "_brand_names": zl_item.get("brand_names", []),
    }


def shibiao_to_standard(item: dict) -> dict:
    """世舶数据标准化（已有格式就是标准格式，加来源标记）"""
    item["_source"] = "shibiao"
    return item


# ========== 统一采集器 ==========

class UnifiedCollector:
    """
    统一采集器。
    
    自动选择可用的 API 源：
      1. 优先世舶
      2. 世舶不可用 → 知了网
      3. 都不通 → 返回 False
    
    用法:
      collector = UnifiedCollector()
      result = collector.collect_one_page("碎纸机", "610000", page=1, size=50)
      collector.save(result, "碎纸机", "陕西")
    """
    
    def __init__(self):
        self.shibiao = ShibiaoCollector()
        self.zhiliao = ZhiliaoCollector()
        self._active = None  # "shibiao" or "zhiliao"
    
    def _detect_source(self) -> str:
        """检测可用数据源"""
        if self.shibiao.health_check():
            return "shibiao"
        if self.zhiliao.health_check():
            return "zhiliao"
        return None
    
    def collect_one_page(self, keyword: str, province_code: str = None,
                         page: int = 1, page_size: int = 50,
                         begin_date: str = None, end_date: str = None,
                         prefer_zhiliao: bool = False) -> dict:
        """
        采集一页数据。province_code=None 表示全国检索。
        带 begin_date/end_date 时强制走知了网（世舶无可靠时间窗）。
        返回: {"source": "shibiao"|"zhiliao", "records": [...], "total": N}
        """
        force_zl = prefer_zhiliao or bool(begin_date or end_date)
        if force_zl:
            try:
                raw = self.zhiliao.search(
                    keyword, province_code, page, page_size,
                    begin_date=begin_date, end_date=end_date,
                )
            except Exception as e:
                return {"error": f"知了网请求失败: {e}", "records": [], "total": 0}
            if not raw.get("success", True) and raw.get("data") is None:
                return {"error": f"知了网返回异常: {raw}", "records": [], "total": 0}
            items = raw.get("data", {}).get("items", [])
            total = raw.get("data", {}).get("total", 0)
            return {
                "source": "zhiliao",
                "records": [zl_to_shibiao(item) for item in items],
                "total": total,
            }

        if self._active is None:
            self._active = self._detect_source()
        
        if self._active is None:
            return {"error": "所有API源不可用", "records": [], "total": 0}
        
        if self._active == "shibiao":
            # 世舶需要省码；无省码时用陕西占位再靠买方名回填（不理想但可降级）
            code = province_code or "610000"
            raw = self.shibiao.search(keyword, code, page, page_size)
            records = raw.get("data", {}).get("data", [])
            total = raw.get("data", {}).get("total", 0)
            return {
                "source": "shibiao",
                "records": [shibiao_to_standard(r) for r in records],
                "total": total,
            }
        
        elif self._active == "zhiliao":
            raw = self.zhiliao.search(
                keyword, province_code, page, page_size,
                begin_date=begin_date, end_date=end_date,
            )
            items = raw.get("data", {}).get("items", [])
            total = raw.get("data", {}).get("total", 0)
            return {
                "source": "zhiliao",
                "records": [zl_to_shibiao(item) for item in items],
                "total": total,
            }
        
        return {"error": "未知错误", "records": [], "total": 0}
    
    def save(self, result: dict, keyword: str, region: str,
             page: int = 1) -> str:
        """
        将采集结果保存为 scout_data/ 兼容格式JSON。
        返回文件路径。
        """
        os.makedirs(DATA_DIR, exist_ok=True)
        fname = f"{keyword}_{region}_p{page}.json"
        fpath = os.path.join(DATA_DIR, fname)
        
        output = {
            "data": {
                "data": result["records"],
                "total": result["total"],
            },
            "code": 0,
            "_source": result.get("source", "unknown"),
            "_keyword": keyword,
            "_region": region,
        }
        
        with open(fpath, "w") as f:
            json.dump(output, f, ensure_ascii=False, indent=2)
        
        return fpath
    
    def status(self) -> dict:
        """返回当前数据源状态"""
        shibiao_ok = self.shibiao.health_check()
        zhiliao_ok = self.zhiliao.health_check()
        return {
            "shibiao": "OK" if shibiao_ok else "不可用",
            "zhiliao": "OK" if zhiliao_ok else "不可用",
            "active": self._active or "未检测",
        }


# ========== 测试 ==========

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    print("=" * 60)
    print("统一采集器测试")
    print("=" * 60)
    
    c = UnifiedCollector()
    
    print("\n1. 数据源状态:")
    print(f"  世舶: {c.status()['shibiao']}")
    print(f"  知了网: {c.status()['zhiliao']}")
    
    print("\n2. 采集测试（碎纸机/陕西/page=1/size=5）:")
    result = c.collect_one_page("碎纸机", "610000", page=1, page_size=5)
    print(f"  数据源: {result.get('source')}")
    print(f"  总数: {result.get('total')}")
    print(f"  返回: {len(result['records'])}条")
    
    if result['records']:
        r = result['records'][0]
        print(f"  第一条: id={r.get('id')} buyer={r.get('partANameList',[])} supplier={r.get('partBNameList',[])} money={r.get('projectMoney')}")
    
    print("\n3. 保存测试:")
    fpath = c.save(result, "碎纸机", "陕西", page=1)
    print(f"  保存到: {fpath}")
    print(f"\n4. 最终状态: {c.status()}")
