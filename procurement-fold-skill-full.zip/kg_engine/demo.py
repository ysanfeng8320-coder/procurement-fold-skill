#!/usr/bin/env python3
"""
demo.py — 符号化KG系统完整演示

演示4个核心场景：
  1. 产品关联发现（Jaccard + 置信度）
  2. 供应商中心度排名（渠道商推荐）
  3. 采购方相似度 + 品类推荐（交叉销售）
  4. 关联规则挖掘（买A→买B的概率）

用法：
  python3 demo.py                           # 默认品类=信号屏蔽器
  python3 demo.py --product 塑胶跑道        # 指定品类
  python3 demo.py --buyer "陕西省安康监狱"  # 指定采购方
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from graph_store import GraphStore
from matrix_ops import MatrixOps, SimilarityMatrix, confidence_label
from feature_matcher import FeatureMatcher
from validator import Validator


def section(title):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")


def demo_product_associations(mo, product: str):
    """场景1：产品关联发现"""
    section(f"场景1: {product} 的产品关联")
    
    # 全品类对比
    sims = mo.all_product_similarities()
    related = [s for s in sims if s["product_a"] == product or s["product_b"] == product]
    
    if not related:
        print(f"  {product} 在现有数据中未发现关联")
        return
    
    print(f"  {product} 与以下品类存在共现关系：")
    for r in related[:8]:
        other = r["product_b"] if r["product_a"] == product else r["product_a"]
        print(f"    {other:12s} → Jaccard={r['jaccard']:.4f}  共{r['n_common']}家  置信度={r['confidence']}")
    
    # 批量相似矩阵
    sm = SimilarityMatrix(mo)
    print(f"\n  [批量相似度] 与{product}最相似的品类：")
    for r in sm.most_similar_products(product, 5):
        print(f"    {r['product']}: Jaccard={r['jaccard']}  置信度={r['confidence']}")


def demo_supplier_centrality(mo, product: str = None):
    """场景2：供应商中心度"""
    section(f"场景2: 活跃供应商 Top 15{' (品类='+product+')' if product else ''}")
    
    suppliers = mo.supplier_centrality(15, product_filter=product)
    print(f"  {'排名':<4} {'供应商':<30} {'品类':<6} {'中标次数':<8} {'置信度'}")
    print(f"  {'-'*60}")
    for i, s in enumerate(suppliers, 1):
        print(f"  {i:<4} {s['name']:<30} {s['product_types']:<6} {s['deal_count']:<8} {s['confidence']}")


def demo_buyer_centrality(mo, product: str = None):
    """场景2b：采购方中心度"""
    section(f"场景2b: 活跃采购方 Top 10{' (品类='+product+')' if product else ''}")
    
    buyers = mo.buyer_centrality(10, product_filter=product)
    for b in buyers:
        print(f"  [{b['score']:5.0f}] {b['name']:<30} {b['product_count']}品类 {b['total_spend']:>8.1f}万  置信度={b['confidence']}")


def demo_buyer_similarity(mo, buyer1: str, buyer2: str):
    """场景3a：采购方相似度"""
    section(f"场景3a: 采购方相似度")
    
    r = mo.buyer_similarity(buyer1, buyer2)
    print(f"  {buyer1}")
    print(f"  {buyer2}")
    print(f"  余弦相似度: {r['cosine']:.4f}")
    print(f"  共同品类:   {r['common_products']}")
    print(f"  置信度:     {r['confidence']}")


def demo_recommend_products(mo, buyer: str):
    """场景3b：给采购方推荐品类"""
    section(f"场景3b: 给 {buyer} 推荐品类")
    
    products = mo.recommend_products_for_buyer(buyer, top_n=5)
    if not products:
        print(f"  {buyer} 暂无推荐（可能无采购记录）")
        return
    
    print(f"  {'品类':<16} {'匹配同行':<8} {'均价(万)':<10} {'置信度':<6} {'推荐理由'}")
    print(f"  {'-'*60}")
    for p in products:
        print(f"  {p['product']:<16} {p['peer_count']:<8} {p['avg_spend']:<10} {p['confidence']:<6} {p['reason']}")


def demo_association_rules(mo, product: str = None):
    """场景4：关联规则"""
    section(f"场景4: 关联规则挖掘{' (包含 '+product+')' if product else ''}")
    
    rules = mo.association_rules(min_support=2, min_confidence=0.1)
    if product:
        rules = [r for r in rules if product in r["antecedent"] or product in r["consequent"]]
    
    if not rules:
        print(f"  未发现高置信度关联规则")
        return
    
    for r in rules[:10]:
        print(f"  {r['interpretation']}")
        print(f"    Lift={r['lift']}  置信度={r['confidence_label']}  支持度={r['support']}")


def demo_profile(target_product: str):
    """买家画像 + 特征拟合"""
    section(f"买家画像: {target_product}")
    
    matcher = FeatureMatcher(GraphStore())
    result = matcher.rank_prospects(target_product, top_n=10, min_score=30)
    profile = result["profile"]
    
    print(f"  已购客户: {profile['target_count']}家")
    print(f"  潜在客户池: {profile['nontarget_count']}家")
    print(f"  平均采购额: {profile['avg_spend']}万")
    print(f"\n  金额分布:")
    for ab, info in sorted(profile["amount_profile"].items(), key=lambda x: -x[1]["count"]):
        print(f"    {ab}: {info['count']}家({info['pct']}%)")
    
    print(f"\n  潜力客户 Top 5:")
    for p in result["prospects"][:5]:
        phone = f" ☎ {p['phone']}" if p['phone'] not in ("待确认", "") else ""
        print(f"    [{p['score']:2d}分] {p['name']}{phone}")
        for r in p['reasons'][:2]:
            print(f"      → {r}")


def main():
    product = "信号屏蔽器"
    buyer = "陕西省安康监狱"
    
    # 解析命令行参数
    args = sys.argv[1:]
    for i, a in enumerate(args):
        if a == "--product" and i+1 < len(args):
            product = args[i+1]
        if a == "--buyer" and i+1 < len(args):
            buyer = args[i+1]
    
    print(f"\n  KG 符号化系统 v0.2 Demo")
    print(f"  目标品类: {product}")
    print(f"  目标采购方: {buyer}")
    
    store = GraphStore()
    mo = MatrixOps(store)
    
    # 场景1
    demo_product_associations(mo, product)
    
    # 场景2
    demo_supplier_centrality(mo)
    demo_supplier_centrality(mo, product)
    demo_buyer_centrality(mo)
    
    # 场景3
    if buyer:
        demo_recommend_products(mo, buyer)
    
    # 场景4
    demo_association_rules(mo, product)
    
    # 买家画像
    demo_profile(product)
    
    print(f"\n{'='*60}")
    print(f"  演示完成。按品类查看:")
    print(f"    python3 demo.py --product 塑胶跑道")
    print(f"    python3 demo.py --product 碎纸机")
    print(f"    python3 demo.py --buyer '陕西师范大学'")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
