"""
矩阵运算层（v0.3）
基于符号表，把关系转化为可计算的矩阵/张量。

核心矩阵：
  M_AD:      采购方(A)×产品(D) — 金额加权偏好矩阵
  M_AD_count:采购方(A)×产品(D) — 频次矩阵
  M_AD_norm: 采购方(A)×产品(D) — L2行归一化后的综合特征矩阵  [v0.3]
  M_BD:      供应商(B)×产品(D) — 供应商覆盖矩阵
  AA_cooc:   采购方(A)×采购方(A) — 共现矩阵
  T_A_F:     采购方(A)×时间窗口(F) — 时序活跃度矩阵

v0.3 优化：
  - M_AD_norm: 金额×频次的加权融合 (0.7×金额归一化 + 0.3×频次归一化)
  - 余弦相似度前做 L2 行归一化
  - 供应商评分改用加权混合评分（品类数×5 + 中标次数×2 + 金额分×0.1）
  - confidence_label 加入新鲜度因子
"""
import json, os, math
from collections import defaultdict, Counter
from datetime import datetime
import numpy as np
from scipy.sparse import csr_matrix, coo_matrix, csc_matrix
from graph_store import GraphStore
from schema import EntityType, RelationType

KG_DIR = os.path.dirname(os.path.abspath(__file__))

# ========== 置信度工具 ==========

def confidence_label(n_samples: int, consistency: float = 1.0,
                     freshness: float = 1.0) -> str:
    """
    根据样本量、一致性、新鲜度返回可信度标签。
    n_samples: 支撑该结论的样本数
    consistency: 0~1，数据内部一致性
    freshness: 0~1，数据新鲜度（1=全部是近6个月的数据）
    """
    score = 0
    if n_samples >= 10: score += 3
    elif n_samples >= 5: score += 2
    elif n_samples >= 3: score += 1
    
    if consistency >= 0.7: score += 2
    elif consistency >= 0.4: score += 1
    
    if freshness >= 0.7: score += 1
    
    if score >= 5: return "高"
    elif score >= 3: return "中"
    else: return "低"


def l2_normalize_rows(mat):
    """对稀疏矩阵的行做L2归一化 """
    if mat is None: return None
    row_norms = np.sqrt(np.array(mat.power(2).sum(axis=1)).flatten())
    row_norms[row_norms == 0] = 1  # 避免除零
    diag = csr_matrix((1.0 / row_norms, (range(len(row_norms)), range(len(row_norms)))))
    return diag.dot(mat)


# =============================================================

class MatrixOps:
    """矩阵运算引擎 (v0.3)"""
    
    def __init__(self, store: GraphStore = None):
        self.store = store or GraphStore()
        self._build_indices()
        self._build_matrices()
    
    # ========== 索引构建 ==========
    
    def _build_indices(self):
        self.buyer_idx = {}
        self.supplier_idx = {}
        self.product_idx = {}
        self.project_idx = {}
        self.buyer_names = {}
        self.supplier_names = {}
        self.product_names = {}
        self.buyer_props = {}
        
        for eid, e in self.store.graph.entities.items():
            if e.type == EntityType.COMPANY:
                if e.properties.get("type") == "buyer":
                    idx = len(self.buyer_idx)
                    self.buyer_idx[eid] = idx
                    self.buyer_names[idx] = e.name
                    self.buyer_props[idx] = e.properties
                elif e.properties.get("type") == "supplier":
                    idx = len(self.supplier_idx)
                    self.supplier_idx[eid] = idx
                    self.supplier_names[idx] = e.name
            elif e.type == EntityType.PRODUCT:
                idx = len(self.product_idx)
                self.product_idx[eid] = idx
                self.product_names[idx] = e.name
            elif e.type == EntityType.PROJECT:
                idx = len(self.project_idx)
                self.project_idx[eid] = idx
    
    # ========== 矩阵构建（v0.3 加权融合） ==========
    
    def _build_matrices(self):
        n_b = len(self.buyer_idx)
        n_p = len(self.product_idx)
        n_s = len(self.supplier_idx)
        
        # 稀疏矩阵数据收集
        ad_rows, ad_cols, ad_data = [], [], []
        adc_rows, adc_cols, adc_data = [], [], []
        bd_rows, bd_cols, bd_data = [], [], []
        aa_rows, aa_cols, aa_data = [], [], []
        af_rows, af_cols, af_data = [], [], []
        bd_money_rows, bd_money_cols, bd_money_data = [], [], []  # 供应商×金额
        
        proj_to_buyers = defaultdict(set)
        proj_to_suppliers = defaultdict(set)
        proj_to_products = defaultdict(set)
        proj_to_money = {}
        proj_to_time = {}
        
        for r in self.store.graph.relations:
            if r.type == RelationType.ISSUES:
                proj_to_buyers[r.target_id].add(r.source_id)
            elif r.type == RelationType.WON_BY:
                proj_to_suppliers[r.source_id].add(r.target_id)
            elif r.type == RelationType.REQUIRES:
                proj_to_products[r.source_id].add(r.target_id)
        
        for r in self.store.graph.relations:
            if r.type == RelationType.ISSUES:
                proj = self.store.graph.entities.get(r.target_id)
                if proj and proj.type == EntityType.PROJECT:
                    ms = str(proj.properties.get("money", "0")).replace("万","").strip()
                    try:
                        money = float(ms) if ms else 0
                    except:
                        money = 0
                    proj_to_money[r.target_id] = money
                    proj_to_time[r.target_id] = str(proj.properties.get("time", ""))[:7]
        
        for proj_id, buyers in proj_to_buyers.items():
            products = proj_to_products.get(proj_id, set())
            money = proj_to_money.get(proj_id, 0)
            ptime = proj_to_time.get(proj_id, "")
            for bid in buyers:
                bi = self.buyer_idx.get(bid)
                if bi is None: continue
                for pid in products:
                    pj = self.product_idx.get(pid)
                    if pj is None: continue
                    ad_rows.append(bi); ad_cols.append(pj); ad_data.append(money)
                    adc_rows.append(bi); adc_cols.append(pj); adc_data.append(1)
                if ptime and len(ptime) == 7:
                    month_idx = self._month_to_idx(ptime)
                    af_rows.append(bi); af_cols.append(month_idx); af_data.append(1)
        
        for proj_id, suppliers in proj_to_suppliers.items():
            products = proj_to_products.get(proj_id, set())
            money = proj_to_money.get(proj_id, 0)
            for sid in suppliers:
                si = self.supplier_idx.get(sid)
                if si is None: continue
                for pid in products:
                    pj = self.product_idx.get(pid)
                    if pj is None: continue
                    bd_rows.append(si); bd_cols.append(pj); bd_data.append(1)
                    bd_money_rows.append(si); bd_money_cols.append(pj); bd_money_data.append(money)
        
        for proj_id, buyers in proj_to_buyers.items():
            b_list = [b for b in buyers if b in self.buyer_idx]
            for i in range(len(b_list)):
                for j in range(i+1, len(b_list)):
                    bi = self.buyer_idx[b_list[i]]
                    bj = self.buyer_idx[b_list[j]]
                    aa_rows.append(bi); aa_cols.append(bj); aa_data.append(1)
                    aa_rows.append(bj); aa_cols.append(bi); aa_data.append(1)
        
        shape_ad = (n_b, n_p) if n_b > 0 and n_p > 0 else (1, 1)
        shape_bd = (n_s, n_p) if n_s > 0 and n_p > 0 else (1, 1)
        shape_aa = (n_b, n_b) if n_b > 0 else (1, 1)
        
        self.M_AD = coo_matrix((ad_data, (ad_rows, ad_cols)), shape=shape_ad).tocsr() if ad_data else None
        self.M_AD_count = coo_matrix((adc_data, (adc_rows, adc_cols)), shape=shape_ad).tocsr() if adc_data else None
        self.M_BD = coo_matrix((bd_data, (bd_rows, bd_cols)), shape=shape_bd).tocsr() if bd_data else None
        self.M_BD_money = coo_matrix((bd_money_data, (bd_money_rows, bd_money_cols)), shape=shape_bd).tocsr() if bd_money_data else None
        self.AA_cooc = coo_matrix((aa_data, (aa_rows, aa_cols)), shape=shape_aa).tocsr() if aa_data else None
        
        max_month = 12
        shape_af = (n_b, max_month) if n_b > 0 else (1, 1)
        self.T_A_F = coo_matrix((af_data, (af_rows, af_cols)), shape=shape_af).tocsr() if af_data else None
        
        # ====== v0.3: 加权融合特征矩阵 M_AD_norm ======
        pass  # _build_weighted_matrix called below
        
        self._n_buyers = n_b
        self._n_products = n_p
        self._build_weighted_matrix()
        self._n_suppliers = n_s
        
        print(f"矩阵构建:")
        if self.M_AD is not None:
            print(f"  M_AD(金额):        {str(self.M_AD.shape):12s} {self.M_AD.nnz}非零")
        if self.M_AD_norm is not None:
            print(f"  M_AD_norm(加权融合): {str(self.M_AD_norm.shape):12s} [v0.3]")
        if self.M_BD is not None:
            print(f"  M_BD(供应商×产品):  {str(self.M_BD.shape):12s} {self.M_BD.nnz}非零")
        if self.AA_cooc is not None:
            print(f"  AA_cooc(共现):    {str(self.AA_cooc.shape):12s} {self.AA_cooc.nnz}非零")
        if self.T_A_F is not None:
            print(f"  T_A_F(时序):      {str(self.T_A_F.shape):12s} {self.T_A_F.nnz}非零")
    
    def _build_weighted_matrix(self):
        """
        v0.3: 构建加权融合矩阵
        M_AD_norm = 0.7 × normalize(M_AD) + 0.3 × normalize(M_AD_count)
        """
        if self.M_AD is None or self.M_AD_count is None:
            self.M_AD_norm = None
            return
        
        # 列归一化（min-max per column）——按品类标准化，消除品类间金额量级差异
        ad_dense = self.M_AD.toarray()
        adc_dense = self.M_AD_count.toarray()
        
        # 每种品类，做列内 min-max 归一化
        for pj in range(self._n_products):
            col = ad_dense[:, pj]
            mx, mn = col.max(), col.min()
            if mx > mn:
                ad_dense[:, pj] = (col - mn) / (mx - mn)
            else:
                ad_dense[:, pj] = np.where(col > 0, 1.0, 0.0)
            
            col2 = adc_dense[:, pj]
            mx2, mn2 = col2.max(), col2.min()
            if mx2 > mn2:
                adc_dense[:, pj] = (col2 - mn2) / (mx2 - mn2)
            else:
                adc_dense[:, pj] = np.where(col2 > 0, 1.0, 0.0)
        
        # 加权融合：金额(0.7) + 频次(0.3)
        self.M_AD_norm = csr_matrix(0.7 * ad_dense + 0.3 * adc_dense)
        
        # 余弦计算用的 L2 行归一化版本
        self.M_AD_cosine = l2_normalize_rows(self.M_AD_norm)
    
    @staticmethod
    def _month_to_idx(ym: str) -> int:
        try: return max(0, min(11, int(ym[5:7]) - 1))
        except: return 0
    
    def _product_by_name(self, name: str) -> int:
        for idx, n in self.product_names.items():
            if n == name: return idx
        return -1
    
    def _buyer_by_name(self, name: str) -> int:
        for idx, n in self.buyer_names.items():
            if n == name: return idx
        return -1
    
    # ========== 1. Jaccard / 余弦相似度（v0.3 用归一化矩阵） ==========
    
    def product_similarity(self, p1_name: str, p2_name: str) -> dict:
        if self.M_AD_count is None:
            return {"jaccard": 0, "cosine": 0, "confidence": "无数据", "n_common": 0}
        
        pj1 = self._product_by_name(p1_name)
        pj2 = self._product_by_name(p2_name)
        if pj1 < 0 or pj2 < 0:
            return {"jaccard": 0, "cosine": 0, "confidence": "无数据", "n_common": 0}
        
        # Jaccard 用 M_AD_count（原始频次矩阵）
        c1 = set(np.where(self.M_AD_count[:, pj1].toarray().flatten() > 0)[0])
        c2 = set(np.where(self.M_AD_count[:, pj2].toarray().flatten() > 0)[0])
        common = c1 & c2
        union = c1 | c2
        jaccard = len(common) / len(union) if union else 0
        
        # 余弦用 M_AD_cosine（L2归一化后的加权矩阵） [v0.3]
        cosine = 0.0
        if self.M_AD_cosine is not None:
            v1 = self.M_AD_cosine[:, pj1].toarray().flatten()
            v2 = self.M_AD_cosine[:, pj2].toarray().flatten()
            cosine = float(np.dot(v1, v2))
            cosine = max(0.0, min(1.0, cosine))  # 钳制到[0,1]
        
        return {
            "product_a": p1_name, "product_b": p2_name,
            "jaccard": round(jaccard, 4), "cosine": round(cosine, 4),
            "n_common": len(common), "n_total_buyers": len(union),
            "confidence": confidence_label(len(common)),
        }
    
    def all_product_similarities(self) -> list:
        names = list(self.product_names.values())
        results = []
        for i in range(len(names)):
            for j in range(i+1, len(names)):
                r = self.product_similarity(names[i], names[j])
                if r["n_common"] > 0:
                    results.append(r)
        return sorted(results, key=lambda x: -x["jaccard"])
    
    def buyer_similarity(self, b1_name: str, b2_name: str) -> dict:
        """
        两个采购方的产品偏好相似度。
        v0.3: 余弦计算从 M_AD 改为 M_AD_cosine（L2归一化+加权融合后的向量）
        """
        if self.M_AD_cosine is None:
            return {"cosine": 0, "confidence": "无数据", "common_products": []}
        
        bi1 = self._buyer_by_name(b1_name)
        bi2 = self._buyer_by_name(b2_name)
        if bi1 < 0 or bi2 < 0:
            return {"cosine": 0, "confidence": "无数据", "common_products": []}
        
        v1 = self.M_AD_cosine[bi1, :].toarray().flatten()
        v2 = self.M_AD_cosine[bi2, :].toarray().flatten()
        cosine = float(np.dot(v1, v2))
        cosine = max(0.0, min(1.0, cosine))
        
        # 共同品类（从原始M_AD_count看）
        raw1 = self.M_AD_count[bi1, :].toarray().flatten() if self.M_AD_count is not None else v1
        raw2 = self.M_AD_count[bi2, :].toarray().flatten() if self.M_AD_count is not None else v2
        common_products = []
        for pj in range(self._n_products):
            if raw1[pj] > 0 and raw2[pj] > 0:
                common_products.append(self.product_names.get(pj, "?"))
        
        n_common = len(common_products)
        n1 = int(np.sum(raw1 > 0))
        n2 = int(np.sum(raw2 > 0))
        consistency = n_common / max(max(n1, n2), 1)
        
        return {
            "buyer_a": b1_name, "buyer_b": b2_name,
            "cosine": round(cosine, 4),
            "common_products": common_products,
            "n_common": n_common,
            "n_a_products": n1, "n_b_products": n2,
            "confidence": confidence_label(n_common, consistency),
        }
    
    # ========== 2. 中心度（v0.3 加权评分） ==========
    
    def buyer_centrality(self, top_n: int = 20, product_filter: str = None) -> list:
        if self.M_AD_norm is None: return []
        
        scores = []
        for bi in range(self._n_buyers):
            row = self.M_AD_norm[bi, :].toarray().flatten()
            if product_filter:
                pj = self._product_by_name(product_filter)
                count = 1 if pj >= 0 and row[pj] > 0 else 0
                spend = float(row[pj]) if pj >= 0 else 0
            else:
                count = int(np.sum(row > 0))
                spend = float(np.sum(row))
            
            if count > 0 or spend > 0:
                # v0.3: 加权评分 = 品类数×10 + 归一化强度×30
                score = count * 10 + spend * 30
                name = self.buyer_names.get(bi, "?")
                industry = self.buyer_props.get(bi, {}).get("industries", [])
                scores.append({
                    "name": name,
                    "score": round(score, 1),
                    "product_count": count,
                    "total_spend_norm": round(spend, 3),
                    "industries": industry,
                    "confidence": confidence_label(count),
                })
        
        return sorted(scores, key=lambda x: -x["score"])[:top_n]
    
    def supplier_centrality(self, top_n: int = 20, product_filter: str = None) -> list:
        """
        v0.3: 加权混合评分
        score = 品类覆盖×5 + 中标次数×2 + 金额分×0.01
        """
        if self.M_BD is None: return []
        
        scores = []
        for si in range(self._n_suppliers):
            row = self.M_BD[si, :].toarray().flatten()
            money_row = self.M_BD_money[si, :].toarray().flatten() if self.M_BD_money is not None else row
            
            if product_filter:
                pj = self._product_by_name(product_filter)
                count = int(row[pj]) if pj >= 0 else 0
                money = float(money_row[pj]) if pj >= 0 else 0
            else:
                count = int(np.sum(row))
                money = float(np.sum(money_row))
            product_types = int(np.sum(row > 0))
            
            if count > 0:
                # v0.3 加权评分
                score = product_types * 5 + count * 2 + min(money * 0.01, 10)
                name = self.supplier_names.get(si, "?")
                scores.append({
                    "name": name,
                    "score": round(score, 1),
                    "product_types": product_types,
                    "deal_count": count,
                    "total_amount": round(money, 1),
                    "confidence": confidence_label(count),
                })
        
        return sorted(scores, key=lambda x: -x["score"])[:top_n]
    
    # ========== 3. 关联规则 ==========
    
    def association_rules(self, min_support: int = 2, min_confidence: float = 0.1) -> list:
        if self.M_AD_count is None: return []
        
        n_p = self._n_products
        rules = []
        total_buyers = max(self._n_buyers, 1)
        
        for pi in range(n_p):
            buyers_pi = set(np.where(self.M_AD_count[:, pi].toarray().flatten() > 0)[0])
            if len(buyers_pi) < min_support: continue
            for pj in range(n_p):
                if pi == pj: continue
                buyers_pj = set(np.where(self.M_AD_count[:, pj].toarray().flatten() > 0)[0])
                both = len(buyers_pi & buyers_pj)
                if both < min_support: continue
                
                p1_name = self.product_names[pi]
                p2_name = self.product_names[pj]
                confidence = both / len(buyers_pi) if len(buyers_pi) > 0 else 0
                lift = both * total_buyers / (len(buyers_pi) * len(buyers_pj)) if len(buyers_pi) * len(buyers_pj) > 0 else 0
                
                if confidence >= min_confidence:
                    rules.append({
                        "antecedent": p1_name, "consequent": p2_name,
                        "support": both,
                        "confidence": round(confidence, 3),
                        "lift": round(lift, 2),
                        "n_buyers_a": len(buyers_pi),
                        "n_buyers_b": len(buyers_pj),
                        "confidence_label": confidence_label(both, confidence),
                        "interpretation": f"买{p1_name}的单位中{confidence:.0%}也买了{p2_name}（{both}/{len(buyers_pi)}）",
                    })
        
        return sorted(rules, key=lambda x: -x["confidence"])
    
    # ========== 4. 链路预测 ==========
    
    def recommend_suppliers_for_buyer(self, buyer_name: str, top_n: int = 10) -> list:
        bi = self._buyer_by_name(buyer_name)
        if bi < 0 or self.M_AD is None: return []
        buyer_products = set(np.where(self.M_AD[bi, :].toarray().flatten() > 0)[0])
        if not buyer_products: return []
        buyer_industry = self.buyer_props.get(bi, {}).get("industries", [])
        
        similar_buyers = set()
        for bj in range(self._n_buyers):
            if bj == bi: continue
            bj_ind = self.buyer_props.get(bj, {}).get("industries", [])
            if set(buyer_industry) & set(bj_ind): similar_buyers.add(bj)
            bj_products = set(np.where(self.M_AD[bj, :].toarray().flatten() > 0)[0])
            if buyer_products & bj_products: similar_buyers.add(bj)
        
        supplier_scores = defaultdict(lambda: {"count": 0, "used_by": [], "categories": set()})
        for r in self.store.graph.relations:
            if r.type != RelationType.WON_BY: continue
            sid = r.target_id
            if sid not in self.supplier_idx: continue
            si = self.supplier_idx[sid]
            for r2 in self.store.graph.relations:
                if r2.type != RelationType.ISSUES: continue
                if r2.target_id != r.source_id: continue
                bid = r2.source_id
                if bid not in self.buyer_idx: continue
                bj = self.buyer_idx[bid]
                if bj in similar_buyers:
                    sname = self.supplier_names.get(si, "?")
                    bname = self.buyer_names.get(bj, "?")
                    supplier_scores[sname]["count"] += 1
                    supplier_scores[sname]["used_by"].append(bname)
                    for r3 in self.store.graph.relations:
                        if r3.type == RelationType.REQUIRES and r3.source_id == r.source_id:
                            prod = self.store.graph.entities.get(r3.target_id)
                            if prod and prod.type == EntityType.PRODUCT:
                                supplier_scores[sname]["categories"].add(prod.name)
        
        existing = set()
        for r in self.store.graph.relations:
            if r.type != RelationType.ISSUES: continue
            if r.source_id not in self.buyer_idx: continue
            if self.buyer_idx[r.source_id] != bi: continue
            for r2 in self.store.graph.relations:
                if r2.type == RelationType.WON_BY and r2.source_id == r.target_id:
                    if r2.target_id in self.supplier_idx:
                        existing.add(self.supplier_names[self.supplier_idx[r2.target_id]])
        
        results = []
        for sname, info in supplier_scores.items():
            if sname in existing: continue
            results.append({
                "supplier": sname,
                "match_count": info["count"],
                "categories": list(info["categories"]),
                "used_by": list(set(info["used_by"])),
                "confidence": confidence_label(info["count"]),
                "reason": f"相似采购方{info['used_by'][:2]}在用他（{info['count']}次合作）",
            })
        
        return sorted(results, key=lambda x: -x["match_count"])[:top_n]
    
    def recommend_suppliers_by_product(self, product_name: str, top_n: int = 10) -> list:
        pj = self._product_by_name(product_name)
        if pj < 0 or self.M_BD is None: return []
        col = self.M_BD[:, pj].toarray().flatten()
        candidates = [(si, col[si]) for si in range(self._n_suppliers) if col[si] > 0]
        candidates.sort(key=lambda x: -x[1])
        results = []
        for si, deals in candidates[:top_n]:
            sname = self.supplier_names.get(si, "?")
            results.append({
                "supplier": sname,
                "deal_count": int(deals),
                "confidence": confidence_label(int(deals)),
                "reason": f"在{product_name}品类中标{int(deals)}次",
            })
        return results
    
    def recommend_products_for_buyer(self, buyer_name: str, top_n: int = 5) -> list:
        bi = self._buyer_by_name(buyer_name)
        if bi < 0 or self.M_AD_norm is None: return []
        
        buyer_vector = self.M_AD_norm[bi, :].toarray().flatten()
        buyer_products = set(np.where(buyer_vector > 0)[0])
        if not buyer_products: return []
        buyer_industry = self.buyer_props.get(bi, {}).get("industries", [])
        
        product_scores = defaultdict(lambda: {"count": 0, "total_money": 0.0, "buyers": []})
        for bj in range(self._n_buyers):
            if bj == bi: continue
            bj_ind = self.buyer_props.get(bj, {}).get("industries", [])
            if not (set(buyer_industry) & set(bj_ind)): continue
            row = self.M_AD_norm[bj, :].toarray().flatten()
            for pj in range(self._n_products):
                if pj in buyer_products: continue
                if row[pj] > 0:
                    pname = self.product_names.get(pj, "?")
                    bname = self.buyer_names.get(bj, "?")
                    product_scores[pname]["count"] += 1
                    product_scores[pname]["total_money"] += row[pj]
                    product_scores[pname]["buyers"].append(bname)
        
        results = []
        for pname, info in product_scores.items():
            avg = info["total_money"] / max(info["count"], 1)
            score = info["count"] * 10 + avg * 30
            results.append({
                "product": pname,
                "score": round(score, 1),
                "peer_count": info["count"],
                "avg_spend_norm": round(avg, 3),
                "peer_examples": list(set(info["buyers"]))[:5],
                "confidence": confidence_label(info["count"]),
                "reason": f"{info['count']}家同行采购",
            })
        
        return sorted(results, key=lambda x: -x["score"])[:top_n]
    
    def recommend_products_for_industry(self, industry_name: str, top_n: int = 5) -> list:
        if self.M_AD_norm is None: return []
        industry_buyers = [bi for bi in range(self._n_buyers)
                          if industry_name in self.buyer_props.get(bi, {}).get("industries", [])]
        if not industry_buyers: return []
        product_scores = defaultdict(lambda: {"count": 0, "total_money": 0.0})
        for bi in industry_buyers:
            row = self.M_AD_norm[bi, :].toarray().flatten()
            for pj in range(self._n_products):
                if row[pj] > 0:
                    pname = self.product_names.get(pj, "?")
                    product_scores[pname]["count"] += 1
                    product_scores[pname]["total_money"] += row[pj]
        results = []
        for pname, info in product_scores.items():
            coverage = info["count"] / len(industry_buyers)
            score = coverage * 100 + info["total_money"] * 10
            results.append({
                "product": pname, "score": round(score, 1),
                "buyer_count": info["count"],
                "coverage": round(coverage, 2),
                "total_spend_norm": round(info["total_money"], 3),
                "confidence": confidence_label(info["count"], coverage),
            })
        return sorted(results, key=lambda x: -x["score"])[:top_n]
    

    # ========== 政策因子融合（v0.4） ==========
    
    def apply_policy_factor(self, M_AD_current, policy_engine, alpha: float = 0.25):
        """
        将政策因子融合到当前推荐矩阵。
        调用 policy_fetcher.PolicyFactorEngine 构建 P_A、P_D，
        然后 M_AD_final = (1-alpha) × M_AD_current + alpha × (P_A @ P_D^T)
        
        返回: (M_AD_final, policy_impact_report)
        """
        if policy_engine is None or not policy_engine._built:
            return M_AD_current, {"note": "政策引擎未初始化，跳过"}
        
        pa = policy_engine.P_A
        pd = policy_engine.P_D
        
        if pa is None or pd is None or pa.nnz == 0 or pd.nnz == 0:
            return M_AD_current, {"note": "政策矩阵为空，跳过融合"}
        
        # 政策增强矩阵
        policy_boost = pa.dot(pd.T)
        
        # 归一化
        if policy_boost.nnz > 0:
            max_val = policy_boost.max()
            if max_val > 0:
                policy_boost = policy_boost / max_val
        
        # 维度检查
        n_b, n_p = M_AD_current.shape
        if policy_boost.shape != (n_b, n_p):
            return M_AD_current, {"note": f"维度不匹配: policy={policy_boost.shape}, M_AD={(n_b, n_p)}"}
        
        # 加权融合
        M_AD_final = (1 - alpha) * M_AD_current + alpha * policy_boost
        
        boost_nnz = policy_boost.nnz
        impact = {
            "alpha": alpha,
            "policy_boost_nnz": boost_nnz,
            "note": f"政策因子融合: alpha={alpha}, {boost_nnz}个采购方-品类对被增强",
        }
        
        return M_AD_final, impact
    
    def recommend_with_policy(self, buyer_name: str, policy_engine, 
                               top_n: int = 5, alpha: float = 0.25) -> list:
        """
        在推荐中引入政策因子。
        相当于 recommend_products_for_buyer 的政策增强版。
        """
        if policy_engine is None:
            return self.recommend_products_for_buyer(buyer_name, top_n)
        
        # 用政策增强后的矩阵做推荐
        if self.M_AD_norm is None:
            return []
        
        M_AD_policy, _ = self.apply_policy_factor(self.M_AD_norm, policy_engine, alpha)
        
        bi = self._buyer_by_name(buyer_name)
        if bi < 0:
            return []
        
        buyer_vector = M_AD_policy[bi, :].toarray().flatten()
        buyer_original = self.M_AD_norm[bi, :].toarray().flatten()
        buyer_products = set(np.where(buyer_original > 0)[0])
        buyer_industry = self.buyer_props.get(bi, {}).get("industries", [])
        
        # 找同行
        product_scores = defaultdict(lambda: {"count": 0, "total": 0.0, "buyers": []})
        for bj in range(self._n_buyers):
            if bj == bi: continue
            bj_ind = self.buyer_props.get(bj, {}).get("industries", [])
            if not (set(buyer_industry) & set(bj_ind)): continue
            row = M_AD_policy[bj, :].toarray().flatten()
            for pj in range(self._n_products):
                if pj in buyer_products: continue
                if row[pj] > 0:
                    pname = self.product_names.get(pj, "?")
                    bname = self.buyer_names.get(bj, "?")
                    product_scores[pname]["count"] += 1
                    product_scores[pname]["total"] += row[pj]
                    product_scores[pname]["buyers"].append(bname)
        
        # 政策解释
        policy_expl = {}
        if hasattr(policy_engine, 'generate_policy_explanation'):
            signals = getattr(policy_engine, 'cache', None)
            if signals:
                all_sigs = signals.get_all_signals() if hasattr(signals, 'get_all_signals') else []
                for pname in list(product_scores.keys())[:top_n]:
                    expl = policy_engine.generate_policy_explanation(
                        buyer_name, pname, all_sigs
                    )
                    if expl:
                        policy_expl[pname] = expl
        
        results = []
        for pname, info in product_scores.items():
            avg = info["total"] / max(info["count"], 1)
            score = info["count"] * 10 + avg * 30
            item = {
                "product": pname,
                "score": round(score, 1),
                "peer_count": info["count"],
                "avg_policy_score": round(avg, 3),
                "peer_examples": list(set(info["buyers"]))[:5],
                "confidence": confidence_label(info["count"]),
                "reason": f"{info['count']}家同行采购（政策增强）",
                "policy_boost": policy_expl.get(pname, []),
            }
            results.append(item)
        
        return sorted(results, key=lambda x: -x["score"])[:top_n]


    def incremental_update(self, new_store: GraphStore):
        self.store = new_store
        self._build_indices()
        self._build_matrices()


if __name__ == "__main__":
    from graph_store import GraphStore
    store = GraphStore()
    
    print("=" * 60)
    print("MatrixOps v0.3 完整测试")
    print("=" * 60)
    
    mo = MatrixOps(store)
    
    print("\n--- 1. 产品关联（v0.3 余弦用归一化矩阵）---")
    r = mo.product_similarity("复印机", "碎纸机")
    print(f"  复印机↔碎纸机: Jaccard={r['jaccard']:.4f} Cosine={r['cosine']:.4f} 置信度={r['confidence']}")
    r = mo.product_similarity("体育设施", "塑胶跑道")
    print(f"  体育设施↔塑胶跑道: Jaccard={r['jaccard']:.4f} Cosine={r['cosine']:.4f} 置信度={r['confidence']}")
    
    print("\n--- 2. 采购方相似度（v0.3 L2归一化后）---")
    r = mo.buyer_similarity("陕西师范大学", "西安理工大学")
    print(f"  陕师大↔西安理工: 余弦={r['cosine']:.4f} 置信度={r['confidence']} 共同={r['common_products']}")
    
    print("\n--- 3. 供应商中心度（v0.3 加权评分）---")
    for s in mo.supplier_centrality(10):
        print(f"  [{s['score']:5.1f}] {s['name']:<30} {s['product_types']}品类 {s['deal_count']:2d}次 {s['total_amount']:>8.1f}万 置信度={s['confidence']}")
    
    print("\n--- 4. 采购方中心度（v0.3 归一化后）---")
    for b in mo.buyer_centrality(10):
        print(f"  [{b['score']:5.1f}] {b['name']:<30} {b['product_count']}品类 置信度={b['confidence']}")
    
    print("\n--- 5. 关联规则 ---")
    for r in mo.association_rules(min_support=2, min_confidence=0.1)[:5]:
        print(f"  {r['interpretation']} Lift={r['lift']} 置信度={r['confidence_label']}")
