"""
政策因子模块（v0.1）

从公开搜索引擎采集政府政策/规划/通知等文档，
解析为量化信号（支持度、相关性、时间衰减），
构建 P_A（采购方×政策主题）和 P_D（品类×政策主题）矩阵，
融合到现有 M_AD_norm 矩阵中。

设计原则：
  1. 不依赖任何付费API——用 requests + 公开搜索引擎爬取
  2. 可离线——搜索引擎不可用时用缓存兜底
  3. 模块化——policy_fetcher 自身完成采集+解析，只输出矩阵给 matrix_ops
  4. 增量友好——每次只查新品类/新区域的政策
"""
import json, os, re, time, hashlib, logging
from collections import defaultdict
from datetime import datetime, timedelta
from typing import Optional

import numpy as np
from scipy.sparse import csr_matrix, coo_matrix

from graph_store import GraphStore
from schema import EntityType, RelationType, company_id

KG_DIR = os.path.dirname(os.path.abspath(__file__))
CACHE_FILE = os.path.join(KG_DIR, "data/policy_cache.json")
LOG = logging.getLogger("policy_fetcher")

# ========== 政策主题分类体系 ==========

POLICY_TOPICS = {
    # 主题ID   显示名                   关键词集
    "funding":   ("专项资金/补贴",        ["专项资金", "补贴", "拨款", "财政支持", "经费"]),
    "mandate":   ("强制要求/标准升级",    ["强制", "必须配备", "标准", "规范", "要求"]),
    "replace":   ("淘汰/替换计划",        ["淘汰", "替换", "更新换代", "升级改造"]),
    "digital":   ("数字化转型",           ["数字化", "智能化", "信息化", "智慧"]),
    "security":  ("安全/保密要求",        ["安全", "保密", "涉密", "防护"]),
    "education": ("教育/学校建设",        ["教育", "学校", "校园", "教学"]),
    "procure":   ("政府采购/集采目录",    ["集中采购", "集采目录", "政府采购"]),
    "budget":    ("预算/规划",            ["预算", "规划", "十四五", "十五五", "计划"]),
}

# ========== 时间衰减函数 ==========

def time_decay_weight(publish_date: str) -> float:
    """
    根据政策发布时间计算衰减权重。
    近6个月: 1.0
    6-12个月: 0.7
    1-2年: 0.4
    2年以上: 0.1
    """
    if not publish_date or len(publish_date) < 10:
        return 0.5
    try:
        pub = datetime.strptime(publish_date[:10], "%Y-%m-%d")
    except:
        try:
            pub = datetime.strptime(publish_date[:7], "%Y-%m")
        except:
            return 0.5
    
    now = datetime.now()
    months = (now.year - pub.year) * 12 + (now.month - pub.month)
    
    if months <= 6: return 1.0
    if months <= 12: return 0.7
    if months <= 24: return 0.4
    return 0.1


# ========== 搜索引擎采集器 ==========

class SearchEngineCrawler:
    """
    公开搜索引擎采集器。
    用 requests 模拟搜索，不依赖任何付费 API。
    
    当前实现：返回模拟数据（生产环境替换为真实搜索引擎调用）
    """
    
    def __init__(self):
        self.session = None  # 生产环境初始化 requests.Session()
    
    def _init_session(self):
        """生产环境初始化带 headers 的 session"""
        if self.session is None:
            import requests
            self.session = requests.Session()
            self.session.headers.update({
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                              "AppleWebKit/537.36 (KHTML, like Gecko) "
                              "Chrome/120.0.0.0 Safari/537.36",
            })
    
    def search_bing(self, query: str, count: int = 10) -> list:
        """
        调用 Bing 搜索获取政策文档。
        生产环境使用真实API（bing-search-service 等）。
        
        返回: [{"title": ..., "snippet": ..., "url": ..., "date": ...}, ...]
        """
        self._init_session()
        results = []
        
        # === 占位符：生产环境替换为真实搜索调用 ===
        # url = f"https://api.bing.microsoft.com/v7.0/search?q={query}&count={count}"
        # resp = self.session.get(url, headers={"Ocp-Apim-Subscription-Key": "YOUR_KEY"})
        # data = resp.json()
        # for item in data.get("webPages", {}).get("value", []):
        #     results.append({
        #         "title": item["name"],
        #         "snippet": item["snippet"],
        #         "url": item["url"],
        #         "date": item.get("datePublished", ""),
        #     })
        
        # 模拟返回（后续替换）
        LOG.info(f"[占位符] 搜索: {query}")
        return []
    
    def search_baidu(self, query: str, count: int = 10) -> list:
        """百度搜索。"""
        self._init_session()
        # 生产环境实现
        return []
    
    def search_google(self, query: str, count: int = 10) -> list:
        """Google搜索。"""
        self._init_session()
        return []
    
    def search(self, query: str, engine: str = "bing", count: int = 10) -> list:
        engines = {
            "bing": self.search_bing,
            "baidu": self.search_baidu,
            "google": self.search_google,
        }
        fetcher = engines.get(engine, self.search_bing)
        try:
            return fetcher(query, count)
        except Exception as e:
            LOG.warning(f"搜索引擎 {engine} 查询失败: {e}")
            return []


# ========== 政策信号解析器 ==========

class PolicySignalParser:
    """
    从搜索结果中解析政策信号。
    同时支持：
      A) 规则匹配（关键词命中）
      B) 摘要语义判断（简单版）
    """
    
    def __init__(self):
        self.topic_map = POLICY_TOPICS
    
    def classify_topics(self, title: str, snippet: str) -> list:
        """
        标题+摘要 → 命中哪些政策主题。
        返回: [(topic_id, relevance_score), ...]
        """
        text = (title + " " + snippet).lower()
        hits = []
        
        for tid, (tname, keywords) in self.topic_map.items():
            score = 0
            matched = []
            for kw in keywords:
                if kw.lower() in text:
                    matched.append(kw)
                    score += 0.3  # 每个命中关键词+0.3
            
            if matched:
                # 多个关键词命中加分
                score = min(score, 1.0)
                hits.append((tid, round(score, 2), matched))
        
        return hits
    
    def extract_affected_entities(self, snippet: str, 
                                   known_buyers: list,
                                   known_products: list) -> dict:
        """
        从摘要中提取受影响的采购方和品类。
        返回: {"buyers": [...], "products": [...]}
        """
        result = {"buyers": [], "products": []}
        text = snippet.lower()
        
        for buyer in known_buyers:
            # 单位名可能包含核心关键词
            bname = buyer.lower()[:6]  # 取前6个字
            if bname in text:
                result["buyers"].append(buyer)
        
        for prod in known_products:
            pname = prod.lower()
            if pname in text:
                result["products"].append(prod)
        
        return result
    
    def parse(self, search_results: list, 
              known_buyers: list = None,
              known_products: list = None) -> list:
        """
        解析搜索结果 → 结构化政策信号。
        
        每条信号: {
            "title": str,       # 政策标题
            "url": str,         # 来源链接
            "date": str,        # 发布时间
            "topics": [(id, score, matched_kws)],  # 主题分类
            "affected_buyers": [...],  # 受影响的采购方
            "affected_products": [...], # 受影响的品类
            "decay_weight": float,     # 时间衰减权重
            "source": str,            # 来源
        }
        """
        if known_buyers is None:
            known_buyers = []
        if known_products is None:
            known_products = []
        
        signals = []
        for item in search_results:
            title = item.get("title", "")
            snippet = item.get("snippet", "")
            url = item.get("url", "")
            date = item.get("date", "")
            
            topics = self.classify_topics(title, snippet)
            if not topics:
                continue  # 未命中任何政策主题 → 跳过
            
            affected = self.extract_affected_entities(snippet, known_buyers, known_products)
            
            decay = time_decay_weight(date)
            
            signals.append({
                "title": title,
                "url": url,
                "date": date,
                "topics": topics,
                "affected_buyers": affected["buyers"],
                "affected_products": affected["products"],
                "decay_weight": decay,
                "source": "search_engine",
            })
        
        return signals


# ========== 缓存管理 ==========

class PolicyCache:
    """政策缓存（避免重复搜索相同品类）"""
    
    def __init__(self, cache_file: str = CACHE_FILE):
        self.cache_file = cache_file
        self._cache = self._load()
    
    def _load(self) -> dict:
        if os.path.exists(self.cache_file):
            with open(self.cache_file) as f:
                return json.load(f)
        return {"queries": {}, "signals": []}
    
    def save(self):
        os.makedirs(os.path.dirname(self.cache_file), exist_ok=True)
        with open(self.cache_file, "w") as f:
            json.dump(self._cache, f, ensure_ascii=False, indent=2)
    
    def get_query(self, query: str) -> Optional[list]:
        return self._cache.get("queries", {}).get(query)
    
    def set_query(self, query: str, results: list):
        self._cache.setdefault("queries", {})[query] = results
        self.save()
    
    def get_all_signals(self) -> list:
        return self._cache.get("signals", [])
    
    def add_signals(self, new_signals: list):
        self._cache.setdefault("signals", []).extend(new_signals)
        self.save()
    
    def clear(self):
        self._cache = {"queries": {}, "signals": []}
        self.save()


# ========== 政策因子主引擎 ==========

class PolicyFactorEngine:
    """
    政策因子引擎。
    
    入口: fetch_and_apply(product_name, region_code)
    流程:
      1. 生成搜索词 → 搜索引擎采集 → 缓存
      2. 解析政策信号
      3. 构建 P_A 和 P_D 矩阵
      4. 融合到 M_AD_norm
    """
    
    def __init__(self, store: GraphStore = None):
        self.store = store or GraphStore()
        self.crawler = SearchEngineCrawler()
        self.parser = PolicySignalParser()
        self.cache = PolicyCache()
        
        # 矩阵
        self.P_A = None     # 采购方×政策主题 (n_buyers × n_topics)
        self.P_D = None     # 品类×政策主题 (n_products × n_topics)
        self.topic_names = [tid for tid in list(POLICY_TOPICS.keys())]
        self._built = False
    
    def get_known_buyers(self) -> list:
        """从图谱获取已知采购方列表"""
        buyers = []
        for e in self.store.graph.entities.values():
            if e.type == EntityType.COMPANY and e.properties.get("type") == "buyer":
                buyers.append(e.name)
        return buyers[:100]  # 限制数量，避免查询过大
    
    def get_known_products(self) -> list:
        products = set()
        for e in self.store.graph.entities.values():
            if e.type == EntityType.PRODUCT:
                products.add(e.name)
        return sorted(products)
    
    def build_search_queries(self, product_name: str, region: str = "陕西") -> list:
        """
        根据品类和区域生成多角度搜索词。
        覆盖：政策文件、行业规划、标准更新、预算相关。
        """
        queries = []
        
        # 1. 品类+区域政策
        queries.append(f"{region} {product_name} 政策 通知 2026")
        
        # 2. 品类行业标准
        queries.append(f"{product_name} 标准 规范 最新")
        
        # 3. 品类+常用场景
        from inference import _scene_for_product
        scenes = _scene_for_product(product_name)
        for scene in scenes[:3]:
            queries.append(f"{region} {scene} {product_name} 采购")
        
        # 4. 集采/预算相关
        queries.append(f"{product_name} 集中采购 目录")
        queries.append(f"{region} 政府采购 {product_name}")
        
        # 5. 行业规划
        queries.append(f"{product_name} 十四五 规划 十五五 规划")
        
        # 去重
        return list(set(queries))
    
    def fetch_policies(self, product_name: str, region: str = "陕西",
                       force_refresh: bool = False) -> list:
        """
        采集政策文档。
        1. 先生成搜索词
        2. 查缓存（命中则跳过）
        3. 调搜索引擎采集
        4. 解析信号
        5. 缓存
        6. 返回信号列表
        """
        queries = self.build_search_queries(product_name, region)
        known_buyers = self.get_known_buyers()
        known_products = self.get_known_products()
        
        all_signals = []
        for query in queries:
            # 缓存检查
            cached = self.cache.get_query(query)
            if cached and not force_refresh:
                LOG.info(f"[缓存命中] {query}")
                results = cached
            else:
                LOG.info(f"[采集] {query}")
                results = self.crawler.search(query, count=10)
                self.cache.set_query(query, results)
                time.sleep(1)  # 防限流
            
            if not results:
                continue
            
            # 解析信号
            signals = self.parser.parse(results, known_buyers, known_products)
            all_signals.extend(signals)
        
        self.cache.add_signals(all_signals)
        LOG.info(f"共获取 {len(all_signals)} 条政策信号")
        return all_signals
    
    def analyze_policy_impact(self, signals: list) -> dict:
        """
        分析政策影响 → 输出影响摘要。
        每条政策: {主题, 支持度, 受影响品类, 受影响行业, 时间衰减}
        """
        summary = defaultdict(lambda: {
            "count": 0,
            "avg_relevance": 0.0,
            "affected_products": set(),
            "affected_buyers": set(),
            "max_decay": 0.0,
        })
        
        for sig in signals:
            for tid, score, matched in sig.get("topics", []):
                summary[tid]["count"] += 1
                summary[tid]["avg_relevance"] += score
                for p in sig.get("affected_products", []):
                    summary[tid]["affected_products"].add(p)
                for b in sig.get("affected_buyers", []):
                    summary[tid]["affected_buyers"].add(b)
                summary[tid]["max_decay"] = max(
                    summary[tid]["max_decay"],
                    sig.get("decay_weight", 0.5)
                )
        
        result = []
        for tid, info in summary.items():
            if info["count"] > 0:
                info["avg_relevance"] = round(
                    info["avg_relevance"] / info["count"], 2
                )
                tname = POLICY_TOPICS.get(tid, ("未知", ""))[0]
                result.append({
                    "topic_id": tid,
                    "topic_name": tname,
                    "document_count": info["count"],
                    "avg_relevance": info["avg_relevance"],
                    "affected_products": list(info["affected_products"]),
                    "time_freshness": info["max_decay"],
                    "impact_score": round(
                        info["count"] * info["avg_relevance"] * info["max_decay"], 2
                    ),
                })
        
        return sorted(result, key=lambda x: -x["impact_score"])
    
    def build_policy_matrices(self, signals: list) -> tuple:
        """
        构建政策因子矩阵。
        
        P_A: 采购方×政策主题
          P_A[i, j] = max(采购方i受政策j影响的信号数 × 衰减权重)
        
        P_D: 品类×政策主题
          P_D[k, j] = sum(品类k在政策j中被提及的权重)
        """
        n_b = len(self.store.find_entities(EntityType.COMPANY))
        n_p = len(self.store.find_entities(EntityType.PRODUCT))
        n_t = len(self.topic_names)
        
        # 采购方→索引
        buyer_to_idx = {}
        for eid, e in self.store.graph.entities.items():
            if e.type == EntityType.COMPANY and e.properties.get("type") == "buyer":
                buyer_to_idx[e.name] = len(buyer_to_idx)
        
        # 品类→索引
        product_to_idx = {}
        for eid, e in self.store.graph.entities.items():
            if e.type == EntityType.PRODUCT:
                product_to_idx[e.name] = len(product_to_idx)
        
        # 构建 P_A 稀疏矩阵
        pa_rows, pa_cols, pa_data = [], [], []
        for sig in signals:
            decay = sig.get("decay_weight", 0.5)
            for bid, score, _ in sig.get("topics", []):
                col = self.topic_names.index(bid)
                for bname in sig.get("affected_buyers", []):
                    row = buyer_to_idx.get(bname)
                    if row is not None:
                        val = score * decay
                        pa_rows.append(row)
                        pa_cols.append(col)
                        pa_data.append(val)
        
        shape_pa = (n_b, n_t) if n_b > 0 and n_t > 0 else (1, 1)
        self.P_A = coo_matrix((pa_data, (pa_rows, pa_cols)),
                               shape=shape_pa).tocsr() if pa_data else csr_matrix(shape_pa)
        
        # 构建 P_D 稀疏矩阵
        pd_rows, pd_cols, pd_data = [], [], []
        for sig in signals:
            decay = sig.get("decay_weight", 0.5)
            for bid, score, _ in sig.get("topics", []):
                col = self.topic_names.index(bid)
                for pname in sig.get("affected_products", []):
                    row = product_to_idx.get(pname)
                    if row is not None:
                        val = score * decay
                        pd_rows.append(row)
                        pd_cols.append(col)
                        pd_data.append(val)
        
        shape_pd = (n_p, n_t) if n_p > 0 and n_t > 0 else (1, 1)
        self.P_D = coo_matrix((pd_data, (pd_rows, pd_cols)),
                               shape=shape_pd).tocsr() if pd_data else csr_matrix(shape_pd)
        
        self._built = True
        LOG.info(f"政策矩阵构建完成: P_A={self.P_A.shape}, P_D={self.P_D.shape}")
        
        return self.P_A, self.P_D
    
    def apply_policy_factor(self, M_AD_norm, alpha: float = 0.25) -> csr_matrix:
        """
        把政策因子加权融合到推荐矩阵。
        
        M_AD_final = (1-alpha) × M_AD_norm + alpha × (P_A @ P_D^T)
        
        其中 P_A @ P_D^T 是：采购方的政策偏好 × 品类的政策关联 → 采购方×品类的政策增强矩阵
        """
        if not self._built or self.P_A is None or self.P_D is None:
            LOG.warning("政策矩阵未构建，跳过融合")
            return M_AD_norm
        
        # 政策增强矩阵 = P_A × P_D^T
        # 语义：采购方i受政策j影响 × 品类k被政策j提及 → 品类k对采购方i的政策推荐强度
        policy_boost = self.P_A.dot(self.P_D.T)
        
        # 归一化 policy_boost
        if policy_boost.nnz > 0:
            max_val = policy_boost.max()
            if max_val > 0:
                policy_boost = policy_boost / max_val
        
        # 融合
        n_b, n_p = M_AD_norm.shape
        if policy_boost.shape != (n_b, n_p):
            LOG.warning(f"政策增强矩阵维度不匹配: {policy_boost.shape} vs {(n_b, n_p)}")
            return M_AD_norm
        
        M_AD_final = (1 - alpha) * M_AD_norm + alpha * policy_boost
        
        LOG.info(f"政策因子融合完成: alpha={alpha}, "
                 f"policy_boost非零={policy_boost.nnz}")
        
        return M_AD_final
    
    def generate_policy_explanation(self, buyer_name: str, product_name: str,
                                    signals: list) -> str:
        """
        为推荐结果生成政策解释。
        例如: "该推荐受《陕西省学校体育设施建设标准》(2026)支持，
               政策相关性0.73，加权+18%。"
        """
        explanations = []
        
        for sig in signals:
            topics = sig.get("topics", [])
            for tid, score, matched in topics:
                tname = POLICY_TOPICS.get(tid, ("未知", ""))[0]
                affected_b = sig.get("affected_buyers", [])
                affected_p = sig.get("affected_products", [])
                
                # 检查是否匹配当前推荐
                buyer_match = buyer_name in affected_b if affected_b else False
                product_match = product_name in affected_p if affected_p else False
                
                if buyer_match or product_match:
                    title = sig.get("title", "")[:30]
                    date = sig.get("date", "")[:10]
                    decay = sig.get("decay_weight", 0.5)
                    explanations.append(
                        f"《{title}...》({date})→{tname}, "
                        f"相关性{score:.0%}, "
                        f"时效{decay:.0%}, "
                        f"匹配词:{matched}"
                    )
        
        if not explanations:
            # 通用政策说明
            for sig in signals[:2]:
                title = sig.get("title", "")[:20]
                date = sig.get("date", "")[:10]
                topics = sig.get("topics", [])
                for tid, score, matched in topics:
                    tname = POLICY_TOPICS.get(tid, ("未知", ""))[0]
                    explanations.append(
                        f"相关趋势:《{title}...》→{tname}（相关性{score:.0%}）"
                    )
        
        return explanations
    
    def fetch_and_apply(self, product_name: str, region: str = "陕西",
                        alpha: float = 0.25, force_refresh: bool = False) -> dict:
        """
        一站式入口：采集政策 → 构建矩阵 → 融合 → 返回影响报告。
        
        返回 {
            "product": product_name,
            "region": region,
            "policy_count": n,
            "impact_summary": [...],
            "policy_explanations": {...},
            "alpha": alpha,
        }
        """
        # 1. 采集
        signals = self.fetch_policies(product_name, region, force_refresh)
        
        # 2. 分析影响
        impact = self.analyze_policy_impact(signals)
        
        # 3. 构建矩阵
        self.build_policy_matrices(signals)
        
        # 4. 策略解释（按采购方维度预生成）
        known_buyers = self.get_known_buyers()[:10]
        explanations = {}
        for b in known_buyers:
            explanations[b] = self.generate_policy_explanation(b, product_name, signals)
        
        return {
            "product": product_name,
            "region": region,
            "policy_count": len(signals),
            "impact_summary": impact,
            "policy_explanations": explanations,
            "alpha": alpha,
        }


# ========== 模拟数据（用于离线测试） ==========

def generate_mock_signals(product_name: str, region: str) -> list:
    """生产环境中替换为真实搜索结果。"""
    import random
    signals = []
    templates = [
        {
            "title": f"{region}省{product_name}质量安全提升行动方案",
            "snippet": f"为加强{region}省{product_name}质量安全监管，省市场监管局印发方案，要求各地加大{product_name}采购力度。",
            "url": "https://example.gov.cn/policy/1",
            "date": "2026-03-15",
        },
        {
            "title": f"教育部关于推进学校{product_name}标准化建设的通知",
            "snippet": f"学校{product_name}建设标准升级，要求2026年底前所有中小学完成{product_name}配置。强制要求。",
            "url": "https://example.gov.cn/policy/2",
            "date": "2026-01-20",
        },
        {
            "title": f"{region}省财政厅关于印发{product_name}集中采购目录的通知",
            "snippet": f"{product_name}纳入{region}省集中采购目录，采购金额超过5万元需通过集采平台。",
            "url": "https://example.gov.cn/policy/3",
            "date": "2025-11-01",
        },
        {
            "title": f"{region}省{product_name}更新改造专项资金管理办法",
            "snippet": f"安排专项资金用于{region}省{product_name}更新改造，各单位可申请补贴。",
            "url": "https://example.gov.cn/policy/4",
            "date": "2026-06-01",
        },
        {
            "title": f"关于推进教育数字化战略中{product_name}配套建设的指导意见",
            "snippet": f"教育数字化转型中要求同步推进{product_name}数字化配套建设，纳入学校信息化标准。",
            "url": "https://example.gov.cn/policy/5",
            "date": "2025-08-15",
        },
    ]
    
    # 适当变形，使不同品类的政策不同
    DATE = f"2026-{random.randint(1,6):02d}-{random.randint(1,28):02d}"
    for t in templates:
        s = dict(t)
        s["title"] = s["title"].replace(f"{region}", region).replace("{product_name}", product_name)
        s["snippet"] = s["snippet"].replace(f"{region}", region).replace("{product_name}", product_name)
        s["date"] = DATE
        signals.append(s)
    
    return signals


# ========== 测试入口 ==========

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    print("=" * 60)
    print("政策因子模块测试")
    print("=" * 60)
    
    store = GraphStore()
    engine = PolicyFactorEngine(store)
    
    # 测试品类
    for product in ["塑胶跑道", "信号屏蔽器"]:
        print(f"\n--- {product} ---")
        
        # 使用模拟数据（生产环境改为真实采集）
        signals = generate_mock_signals(product, "陕西")
        print(f"模拟政策文档: {len(signals)}条")
        
        # 分析
        impact = engine.analyze_policy_impact(signals)
        print("政策影响分析:")
        for item in impact[:4]:
            print(f"  [{item['impact_score']:.1f}] {item['topic_name']}: "
                  f"{item['document_count']}篇, 相关性{item['avg_relevance']:.0%}, "
                  f"影响品类{item['affected_products']}")
        
        # 构建矩阵
        pa, pd = engine.build_policy_matrices(signals)
        print(f"P_A矩阵: {pa.shape}, 非零={pa.nnz}")
        print(f"P_D矩阵: {pd.shape}, 非零={pd.nnz}")
    
    # 政策解释
    print(f"\n--- 政策解释示例（陕西师范大学←塑胶跑道）---")
    signals = generate_mock_signals("塑胶跑道", "陕西")
    engine.build_policy_matrices(signals)
    expl = engine.generate_policy_explanation("陕西师范大学", "塑胶跑道", signals)
    for e in expl[:3]:
        print(f"  → {e}")
