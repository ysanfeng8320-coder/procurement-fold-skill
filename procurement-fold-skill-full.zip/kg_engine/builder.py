"""
从采集数据构建/更新图谱
修复：
  1. 产品发现：从文件名品类前缀推断，而非硬编码关键词表
  2. 文件收集：支持 *品类*_p*.json, *品类*_deduped.json, *品类*_陕西_p*.json 等格式
  3. 去重：以项目id去重，同项目多阶段公告合并为一条
  4. 省份过滤：支持只构建指定省份的数据
  5. 联系人：从contacts.json + 每条记录ext字段采集
"""
import json, os, glob, re
from collections import defaultdict
from schema import (
    Entity, Relation, EntityType, RelationType,
    company_id, project_id, product_id, region_id, industry_id, person_key
)
from graph_store import GraphStore

DATA_DIR = os.path.dirname(os.path.abspath(__file__)) + "/../scout_data"

SYSTEM_KEYWORDS = {
    "法院系统": ["法院"],
    "检察院系统": ["检察院", "检察"],
    "公安系统": ["公安", "交警", "派出所"],
    "司法/监狱系统": ["司法", "监狱", "戒毒"],
    "纪检监察系统": ["纪委", "纪检", "监察"],
    "党委/机关": ["省委", "市委", "县委", "委", "办公厅", "机关"],
    "财政系统": ["财政"],
    "教育系统": ["学校", "学院", "大学", "教育"],
    "卫健系统": ["医院", "卫生", "疾控", "医疗"],
    "人社系统": ["人社", "社保", "养老", "保险"],
    "保密系统": ["保密", "机要"],
    "考试系统": ["考试", "考务"],
    "市场监管系统": ["市场监管", "工商"],
    "税务系统": ["税务"],
    "自然资源系统": ["自然资源", "国土"],
}

CATEGORY_KEYWORDS = {
    "碎纸机": ["碎纸"],
    "复印机": ["复印"],
    "多功能一体机": ["一体机"],
    "打印机": ["打印"],
    "扫描仪": ["扫描"],
    "计算机/电脑": ["计算机", "电脑"],
    "服务器": ["服务器"],
    "装订机": ["装订"],
    "切纸机": ["切纸"],
    "UPS电源": ["UPS"],
    "销毁设备": ["销毁", "粉碎"],
    "空调": ["空调"],
    "办公设备": ["办公设备", "办公用品"],
    "信号屏蔽器": ["信号屏蔽", "屏蔽器", "屏蔽设备"],
    "印控仪": ["印控", "印章管理", "盖章", "印章", "用印"],
    "钢印机": ["钢印"],
    "支票打印机": ["支票打印", "票据打印"],
    "旗杆": ["旗杆", "国旗杆"],
    "塑胶跑道": ["塑胶跑道", "跑道", "操场"],
    "体育设施": ["体育", "篮球架", "健身器材"],
}


def classify_industry(name: str) -> list:
    results = []
    for sys_name, kws in SYSTEM_KEYWORDS.items():
        for kw in kws:
            if kw in name:
                results.append(sys_name)
                break
    return results if results else ["其他"]


def extract_product(title: str, source_category: str) -> list:
    products = set()
    for prod_name, kws in CATEGORY_KEYWORDS.items():
        for kw in kws:
            if kw in title:
                products.add(prod_name)
                break
    if source_category and source_category not in products:
        for prod_name, kws in CATEGORY_KEYWORDS.items():
            if source_category in prod_name:
                for kw in kws:
                    if kw in title:
                        products.add(prod_name)
                        break
    return list(products)


def detect_category_from_filename(fname: str) -> str:
    for cat in [
        "信号屏蔽器", "碎纸机", "复印机", "装订机", "切纸机",
        "印控仪", "打印机", "扫描仪", "旗杆", "钢印机", "支票打印机",
        "塑胶跑道", "体育设施",
        "办公设备", "旗杆",
    ]:
        if cat in fname:
            return cat
    # Extended filename mapping
    for ext, canonical in [
        ("智能印章", "印控仪"),
        ("电子印章", "印控仪"),
        ("盖章机", "印控仪"),
        ("印控台", "印控仪"),
    ]:
        if ext in fname:
            return canonical
    return ""


def collect_scout_files(categories: list = None, region: str = None) -> list:
    """
    收集采集数据文件。

    categories: 同义词族列表（如印控仪族）。为 None 时保持旧行为（全量，不推荐）。
    region: 如「甘肃」「陕西」。给定时文件名必须包含该区域。
    """
    files = sorted(glob.glob(os.path.join(DATA_DIR, "*.json")))
    result = []
    for f in files:
        fname = os.path.basename(f)
        if region and region not in fname:
            continue

        cat = detect_category_from_filename(fname)
        if categories:
            hit = None
            for syn in categories:
                if syn and syn in fname:
                    hit = syn
                    break
            if not hit:
                continue
            # 文件名同义词 → 规范检测结果（智能印章→印控仪），否则用命中的同义词
            cat = cat or hit
        elif not cat:
            continue

        result.append((f, cat))
    return result


def load_records_from_file(fpath: str) -> list:
    """
    加载一个文件中的所有记录，不管它的结构是：
      {data: {data: [...]}}
      {data: [...]}
      [...]  (flat list)
    都统一返回 list of dict
    """
    with open(fpath) as fp:
        raw = json.load(fp)

    if isinstance(raw, list):
        return raw

    if isinstance(raw, dict):
        # try {data: {data: [...]}}
        inner = raw.get("data")
        if isinstance(inner, dict):
            inner2 = inner.get("data")
            if isinstance(inner2, list):
                return inner2
        # try {data: [...]}
        if isinstance(inner, list):
            return inner
        # try raw directly
        for key in ["data", "records", "list", "rows"]:
            val = raw.get(key)
            if isinstance(val, list):
                return val

    return []


def build_from_scout_data(
    store: GraphStore,
    filter_province: str = None,
    categories: list = None,
    region: str = None,
    canonical_product: str = None,
):
    """
    从 scout_data 构建图谱。

    categories + region: 单品类数据面过滤（v2 推荐）。
    canonical_product: 族内产品统一映射到此规范名（如「印控仪」）。
    filter_province: 按 proviceCode 硬过滤。
    """
    all_records = []
    seen_project_ids = set()

    files = collect_scout_files(categories=categories, region=region)
    print(f"找到 {len(files)} 个数据文件"
          f"{' [scope=' + ','.join(categories[:3]) + ('...' if len(categories)>3 else '') + ']' if categories else ' [全量-不推荐]'}"
          f"{' [region=' + region + ']' if region else ''}")

    for fpath, category in files:
        fname = os.path.basename(fpath)
        records = load_records_from_file(fpath)
        if not records:
            print(f"  [警告] {fname}: 没有有效记录")
            continue
        print(f"  + {fname}: {len(records)} 条 → {category}")

        for item in records:
            if not isinstance(item, dict):
                continue
            iid = item.get("id")
            if not iid:
                continue
            if iid in seen_project_ids:
                continue
            seen_project_ids.add(iid)
            item["_file"] = fname
            item["_category"] = category
            all_records.append(item)

    print(f"读取 {len(all_records)} 条去重后的记录")

    # ----- 1. 构建实体 -----
    region_nodes = {}
    industry_nodes = {}
    company_nodes = {}
    product_nodes = {}
    project_count = 0

    for item in all_records:
        prov = item.get("proviceCode", "")
        city = item.get("cityCode", "")
        title = item.get("title", "") or ""
        category = item.get("_category", "")

        # 省码硬过滤：有 filter 时，缺省码或码不匹配一律跳过
        if filter_province:
            if not prov or prov != filter_province:
                continue

        # 地区实体
        for code, _ in [(prov, f"省_{prov}"), (city, f"市_{city}")]:
            if code and code not in region_nodes:
                rid = region_id(code)
                rname = code_to_name(code)
                region_nodes[code] = rid
                store.add_entity(Entity(
                    id=rid, type=EntityType.REGION,
                    name=rname, properties={"code": code}
                ))

        # 采购单位
        buyer_names = item.get("partANameList", [])
        if not buyer_names:
            buyer_names = [item.get("partAName", "")] if item.get("partAName") else []
        buyer_names = [n.strip() for n in buyer_names if n and n.strip()]

        for name in buyer_names:
            cid = company_id(name)
            if cid not in company_nodes:
                company_nodes[name] = cid
                industries = classify_industry(name)
                store.add_entity(Entity(
                    id=cid, type=EntityType.COMPANY, name=name,
                    properties={"type": "buyer", "industries": industries,
                                 "proviceCode": prov, "cityCode": city}
                ))
                for ind in industries:
                    iid = industry_id(ind)
                    if ind not in industry_nodes:
                        industry_nodes[ind] = iid
                        store.add_entity(Entity(
                            id=iid, type=EntityType.INDUSTRY, name=ind
                        ))
                    store.add_relation(Relation(
                        source_id=cid, target_id=iid,
                        type=RelationType.BELONGS_TO
                    ))
                if prov and prov in region_nodes:
                    store.add_relation(Relation(
                        source_id=cid, target_id=region_nodes[prov],
                        type=RelationType.LOCATED_IN
                    ))

        # 供应商
        supplier_names = item.get("partBNameList", [])
        if not supplier_names:
            supplier_names = [item.get("partBName", "")] if item.get("partBName") else []
        supplier_names = [n.strip() for n in supplier_names if n and n.strip()]

        for name in supplier_names:
            cid = company_id(name)
            if cid not in company_nodes:
                company_nodes[name] = cid
                store.add_entity(Entity(
                    id=cid, type=EntityType.COMPANY, name=name,
                    properties={"type": "supplier"}
                ))

        # 产品实体：scope 模式下统一映射到规范品类，禁止标题关键词引入族外品类
        if canonical_product:
            products = [canonical_product]
        else:
            products = extract_product(title, category)
            if not products and category:
                products = [category]
            if categories:
                # 只保留族内；否则回落到文件品类/规范名
                family_set = set(categories)
                products = [p for p in products if p in family_set or p == category]
                if not products:
                    products = [canonical_product or category]
        for pname in products:
            pid = product_id(pname)
            if pname not in product_nodes:
                product_nodes[pname] = pid
                store.add_entity(Entity(
                    id=pid, type=EntityType.PRODUCT, name=pname
                ))

        # 项目实体
        pid = item.get("id")
        if pid:
            proj_eid = project_id(pid)
            money = item.get("projectMoney")
            if isinstance(money, str) and "万" in money:
                money = money.replace("万", "").strip()
            pub_time = item.get("publishTime")
            store.add_entity(Entity(
                id=proj_eid, type=EntityType.PROJECT,
                name=title[:80],
                properties={
                    "money": money,
                    "time": pub_time,
                    "original_title": title,
                    "category": category,
                    "hasFile": item.get("hasFile"),
                }
            ))
            project_count += 1

            for name in buyer_names:
                cid = company_nodes.get(name)
                if cid:
                    store.add_relation(Relation(
                        source_id=cid, target_id=proj_eid,
                        type=RelationType.ISSUES
                    ))

            for name in supplier_names:
                cid = company_nodes.get(name)
                if cid:
                    store.add_relation(Relation(
                        source_id=proj_eid, target_id=cid,
                        type=RelationType.WON_BY
                    ))

            for pname in products:
                pid = product_nodes.get(pname)
                if pid:
                    store.add_relation(Relation(
                        source_id=proj_eid, target_id=pid,
                        type=RelationType.REQUIRES
                    ))

    print(f"\n构建统计:")
    print(f"  - 公司实体: {len(company_nodes)}")
    print(f"  - 项目实体: {project_count}")
    print(f"  - 产品实体: {len(product_nodes)}")
    print(f"  - 地区实体: {len(region_nodes)}")
    print(f"  - 行业实体: {len(industry_nodes)}")

    # ----- 2. 联系人实体 -----
    contacts = {}
    contacts_file = os.path.join(os.path.dirname(DATA_DIR), "kg_engine/data/contacts.json")
    if os.path.exists(contacts_file):
        with open(contacts_file) as f:
            contacts.update(json.load(f))

    for item in all_records:
        prov = item.get("proviceCode", "")
        if filter_province and (not prov or prov != filter_province):
            continue
        ext = item.get("extract") or item.get("ext") or {}
        if isinstance(ext, str):
            try:
                ext = json.loads(ext)
            except:
                ext = {}
        for name in item.get("partANameList", []):
            if not name or not name.strip():
                continue
            n = name.strip()
            phone = ext.get("partAPhone") or ext.get("buyerPhone") or ext.get("phone")
            if not phone:
                phone = contacts.get(n, "待确认")
            if n not in contacts or contacts[n] == "待确认":
                contacts[n] = phone
        for name in item.get("partBNameList", []):
            if not name or not name.strip():
                continue
            n = name.strip()
            phone = ext.get("partBPhone") or ext.get("supplierPhone") or ext.get("phone")
            if not phone:
                phone = contacts.get(n, "待确认")
            if n not in contacts or contacts[n] == "待确认":
                contacts[n] = phone

    os.makedirs(os.path.dirname(contacts_file), exist_ok=True)
    with open(contacts_file, "w") as f:
        json.dump(contacts, f, ensure_ascii=False, indent=2)

    person_count = 0
    for name, phone in contacts.items():
        if phone == "待确认" or not phone:
            continue
        cid = company_id(name)
        if cid in store.graph.entities:
            person_entity = Entity(
                id=person_key(name, phone),
                type=EntityType.PERSON,
                name=name,
                properties={"phone": phone, "role": "采购/供应商联系人"}
            )
            store.add_entity(person_entity)
            store.add_relation(Relation(
                source_id=person_entity.id, target_id=cid,
                type=RelationType.CONTACT_OF
            ))
            person_count += 1

    print(f"  - 联系人实体: {person_count}")
    print(f"  - 联系人字典: {len(contacts)} 条")

    store.save()
    stats = store.stats()
    print(f"\n图谱构建完成：{stats['entities']}个实体，{stats['relations']}条关系")


def code_to_name(code: str) -> str:
    mapping = {
        "610000": "陕西", "610100": "西安", "610200": "铜川",
        "610300": "宝鸡", "610400": "咸阳", "610500": "渭南",
        "610600": "延安", "610700": "汉中", "610800": "榆林",
        "610900": "安康", "611000": "商洛",
        "620000": "甘肃", "620100": "兰州", "620200": "嘉峪关",
        "620300": "金昌", "620400": "白银", "620500": "天水",
        "620600": "武威", "620700": "张掖", "620800": "平凉",
        "620900": "酒泉", "621000": "庆阳", "621100": "定西",
        "621200": "陇南", "622900": "临夏",
    }
    return mapping.get(code, code)


if __name__ == "__main__":
    store = GraphStore()
    build_from_scout_data(store)
