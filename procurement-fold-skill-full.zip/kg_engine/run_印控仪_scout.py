"""
印控仪侦察脚本 - 陕西+甘肃（v2 单品类隔离）
"""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from orchestrator import run_scout

guidance_signals = [
    {"title": "策略-主攻方向", "content": "厂家建议主攻基层治理市场，纪委和组织部是核心突破口，要把精力集中在纪委党风廉政室。公安系统从分局到末端乡镇均有大用量需求。"},
    {"title": "策略-新客群", "content": "社会工作部（2024年新设）是新增客群，其骨干多抽调自信访局，核心职能聚焦基层维稳和便民减负，建议用信访局人脉切入。"},
    {"title": "策略-示范项目", "content": "宿迁纪委侧的智慧印章纪录片已经获国家纪委网站背书，萧山区村级智慧用章是国家级示范项目，浙江模式可全国推广。"},
    {"title": "渠道-移动合作", "content": "中国移动是深度渠道伙伴，独家协议，移动具备网格直达基层和垫资保障回款两大核心优势。"},
    {"title": "产品-核心卖点", "content": "设备核心是合规风控工具（不是效率工具），实现用印过程可追溯。数字水印+OCR双轨并行的文件校验机制。"},
]

os.makedirs("../reports", exist_ok=True)

for region in ("陕西", "甘肃"):
    print("=" * 60)
    print(f"印控仪侦察 v2 - {region}")
    print("=" * 60)
    result = run_scout(
        product="印控仪",
        region=region,
        guidance_notes=guidance_signals,
        customer_type="政务市场",
        sales_method="渠道商合作+直销",
        enable_policy=False,
        enable_scene="公安系统",
        rebuild_scope=True,
    )
    path = f"../reports/印控仪_{region}_侦察报告.md"
    with open(path, "w") as f:
        f.write(result["markdown"])
    print(f"报告已保存: {path}")
    print(f"QA失败: {result.get('qa_failed')}")
    print(json.dumps(result["data_summary"], ensure_ascii=False, indent=2))
    for s in result.get("skipped_steps", [])[:5]:
        print(f"  ⊕ {s}")
