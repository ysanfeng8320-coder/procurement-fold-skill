"""
图谱持久化层
当前：JSON文件存储
未来：可替换为Neo4j驱动
"""
import json, os
from collections import Counter
from schema import Entity, Relation, Graph, EntityType, RelationType

DATA_DIR = os.path.dirname(os.path.abspath(__file__)) + "/data"
GRAPH_FILE = os.path.join(DATA_DIR, "graph.json")

class GraphStore:
    def __init__(self, graph_file: str = None, load: bool = True):
        self.graph_file = graph_file or GRAPH_FILE
        self.graph = Graph(entities={}, relations=[])
        if load:
            self._load()

    def clear(self):
        self.graph = Graph(entities={}, relations=[])

    def _load(self):
        if os.path.exists(self.graph_file):
            with open(self.graph_file) as f:
                raw = json.load(f)
            self.graph.entities = {}
            for k, v in raw.get("entities", {}).items():
                v["type"] = EntityType(v["type"])
                self.graph.entities[k] = Entity(**v)
            self.graph.relations = []
            for r in raw.get("relations", []):
                r["type"] = RelationType(r["type"])
                self.graph.relations.append(Relation(**r))
        else:
            self.graph = Graph(entities={}, relations=[])

    def save(self):
        os.makedirs(os.path.dirname(self.graph_file) or ".", exist_ok=True)
        raw = {
            "entities": {k: asdict_inner(v) for k, v in self.graph.entities.items()},
            "relations": [asdict_inner(r) for r in self.graph.relations]
        }
        with open(self.graph_file, "w") as f:
            json.dump(raw, f, ensure_ascii=False, indent=2)

    def add_entity(self, entity: Entity):
        if entity.id not in self.graph.entities:
            self.graph.entities[entity.id] = entity
        else:
            existing = self.graph.entities[entity.id]
            existing.properties.update(entity.properties)

    def add_relation(self, relation: Relation):
        for r in self.graph.relations:
            if (r.source_id == relation.source_id and
                r.target_id == relation.target_id and
                r.type == relation.type):
                return
        self.graph.relations.append(relation)

    def get_entity(self, eid: str):
        return self.graph.entities.get(eid)

    def find_entities(self, etype: EntityType = None, name_contains: str = None) -> list:
        results = []
        for e in self.graph.entities.values():
            if etype and e.type != etype:
                continue
            if name_contains and name_contains not in e.name:
                continue
            results.append(e)
        return results

    def find_relations(self, source_id: str = None, target_id: str = None,
                       rtype: RelationType = None) -> list:
        results = []
        for r in self.graph.relations:
            if source_id and r.source_id != source_id:
                continue
            if target_id and r.target_id != target_id:
                continue
            if rtype and r.type != rtype:
                continue
            results.append(r)
        return results

    def get_neighbors(self, entity_id: str, rtype: RelationType = None) -> list:
        """获取某实体的邻居"""
        results = []
        for r in self.graph.relations:
            if r.source_id == entity_id:
                if rtype and r.type != rtype:
                    continue
                target = self.graph.entities.get(r.target_id)
                if target:
                    results.append((r, target))
            elif r.target_id == entity_id:
                if rtype and r.type != rtype:
                    continue
                source = self.graph.entities.get(r.source_id)
                if source:
                    results.append((r, source))
        return results

    def stats(self) -> dict:
        type_count = Counter(e.type.value for e in self.graph.entities.values())
        rel_count = Counter(r.type.value for r in self.graph.relations)
        return {
            "entities": len(self.graph.entities),
            "relations": len(self.graph.relations),
            "by_type": dict(type_count),
            "by_relation": dict(rel_count),
        }


def asdict_inner(obj):
    if hasattr(obj, '__dataclass_fields__'):
        result = {}
        for k, v in obj.__dataclass_fields__.items():
            val = getattr(obj, k)
            if isinstance(val, dict):
                result[k] = {kk: asdict_inner(vv) for kk, vv in val.items()}
            elif isinstance(val, list):
                result[k] = [asdict_inner(vv) for vv in val]
            elif isinstance(val, (EntityType, RelationType)):
                result[k] = val.value
            else:
                result[k] = val
        return result
    return obj
