"""
推理引擎
规则推理 + 路径查询 + 关联发现 + 预测
修复：
  1. 全品类自动关联 - 不硬编码品类名
  2. 联系人电话自动带上
  3. 潜在需求预测逻辑：买了X但没买Y → 推Y（而非列已买过Y的）
  4. 场景化推荐：按品类自动识别推荐场景
"""
from collections import defaultdict, Counter
from schema import EntityType, RelationType, company_id, product_id
from graph_store import GraphStore


def _scene_for_product(product_name: str) -> list:
    """返回该产品可能的目标客户场景标签"""
    scene_map = {
        "碎纸机": ["保密系统", "机要单位", "办公室", "档案馆"],
        "复印机": ["办公室", "文印室", "窗口单位"],
        "信号屏蔽器": ["学校", "考场", "监狱", "会议室", "保密会议"],
        "印控仪": ["办公室", "财务", "行政审批"],
        "装订机": ["教育系统", "法院系统", "检察院系统", "公安系统", "保密系统", "档案", "学校", "学院", "大学", "检察院", "法院", "公安"],
        "切纸机": ["文印室", "印刷厂"],
        "钢印机": ["公证处", "学校", "教务处"],
        "支票打印机": ["财务", "银行", "出纳"],
        "打印机": ["办公室"],
        "扫描仪": ["档案室", "办公室"],
        "多功能一体机": ["办公室"],
        "办公设备": ["办公室"],
        "塑胶跑道": ["学校", "体育局", "教育局"],
        "体育设施": ["学校", "体育局", "体育馆"],
    }
    return scene_map.get(product_name, ["办公"])


class InferenceEngine:
    def __init__(self, store: GraphStore):
        self.store = store

    # ========== 1. 产品关联推理（全品类自动发现） ==========

    def discover_product_associations(self, min_cooccurrence: int = 1) -> list:
        """
        发现产品关联：同一家采购单位同时买了品类A和品类B
        返回：[("碎纸机", "复印机", 关联度, 验证单位数), ...]
        """
        buyers = self.store.find_entities(EntityType.COMPANY)
        buyer_product_map = defaultdict(set)

        for b in buyers:
            if b.properties.get("type") != "buyer":
                continue
            for r, target in self.store.get_neighbors(b.id, RelationType.ISSUES):
                for r2, product in self.store.get_neighbors(target.id, RelationType.REQUIRES):
                    if product.type == EntityType.PRODUCT:
                        buyer_product_map[b.id].add(product.name)

        product_pairs = defaultdict(lambda: {"cooccur": 0, "buyers": set()})
        for bid, products in buyer_product_map.items():
            plist = list(products)
            for i in range(len(plist)):
                for j in range(i+1, len(plist)):
                    a, b = sorted([plist[i], plist[j]])
                    key = f"{a} → {b}"
                    product_pairs[key]["cooccur"] += 1
                    product_pairs[key]["buyers"].add(bid)

        results = []
        for key, info in product_pairs.items():
            if info["cooccur"] >= min_cooccurrence:
                parts = key.split(" → ")
                count_a = sum(1 for pset in buyer_product_map.values() if parts[0] in pset)
                count_b = sum(1 for pset in buyer_product_map.values() if parts[1] in pset)
                denom = max(count_a, count_b)
                ratio = info["cooccur"] / denom if denom > 0 else 0
                results.append((parts[0], parts[1], round(ratio, 2), info["cooccur"], len(info["buyers"])))

        return sorted(results, key=lambda x: -x[2])

    def get_all_product_names(self) -> list:
        """获取图谱中所有产品品类"""
        products = self.store.find_entities(EntityType.PRODUCT)
        return sorted(set(p.name for p in products))

    # ========== 2. 兄弟单位发现 ==========

    def find_sibling_units(self, industry_name: str) -> dict:
        """找出同一个行业系统内的所有采购单位"""
        industry_entities = self.store.find_entities(EntityType.INDUSTRY, name_contains=industry_name)
        members = []
        for ind in industry_entities:
            for r, company in self.store.get_neighbors(ind.id, RelationType.BELONGS_TO):
                if company.type == EntityType.COMPANY:
                    members.append(company)

        result = []
        for m in members:
            products = set()
            for r, proj in self.store.get_neighbors(m.id, RelationType.ISSUES):
                for r2, prod in self.store.get_neighbors(proj.id, RelationType.REQUIRES):
                    if prod.type == EntityType.PRODUCT:
                        products.add(prod.name)
            result.append((m.name, products))
        return {"total": len(result), "members": result}

    # ========== 3. 潜在需求推理 ==========

    def predict_potential_needs(self, target_product: str) -> list:
        """
        预测哪些单位可能需要target_product
        逻辑：买了任何关联产品的单位 → 也可能需要这个
        """
        associations = self.discover_product_associations(min_cooccurrence=1)
        related = [a for a in associations if a[0] == target_product or a[1] == target_product]

        candidates = []
        for a in related:
            other = a[1] if a[0] == target_product else a[0]
            for e in self.store.find_entities(EntityType.COMPANY):
                if e.properties.get("type") != "buyer":
                    continue
                bought_other = False
                bought_target = False
                for r, proj in self.store.get_neighbors(e.id, RelationType.ISSUES):
                    for r2, prod in self.store.get_neighbors(proj.id, RelationType.REQUIRES):
                        if prod.name == other:
                            bought_other = True
                        if prod.name == target_product:
                            bought_target = True
                if bought_other and not bought_target:
                    candidates.append((e.name, other, a[2], a[3]))

        seen = set()
        deduped = []
        for c in candidates:
            key = (c[0], c[1])
            if key not in seen:
                seen.add(key)
                deduped.append(c)
        return sorted(deduped, key=lambda x: -x[2])

    # ========== 4. 可合作的供应商 ==========

    def find_cooperatable_suppliers(self, target_product: str) -> list:
        """
        哪些供应商在给已经执行target_product的客户供其他产品
        → 可以找他们谈渠道合作
        """
        target_buyers = set()
        for e in self.store.find_entities(EntityType.COMPANY):
            if e.properties.get("type") != "buyer":
                continue
            for r, proj in self.store.get_neighbors(e.id, RelationType.ISSUES):
                for r2, prod in self.store.get_neighbors(proj.id, RelationType.REQUIRES):
                    if prod.name == target_product:
                        target_buyers.add(e.name)

        supplier_map = defaultdict(lambda: {"buyers": set(), "other_products": set()})
        for buyer_name in target_buyers:
            cid = company_id(buyer_name)
            for r, proj in self.store.get_neighbors(cid, RelationType.ISSUES):
                for r2, supplier in self.store.get_neighbors(proj.id, RelationType.WON_BY):
                    if supplier.type == EntityType.COMPANY:
                        for r3, prod in self.store.get_neighbors(proj.id, RelationType.REQUIRES):
                            if prod.name != target_product:
                                supplier_map[supplier.name]["buyers"].add(buyer_name)
                                supplier_map[supplier.name]["other_products"].add(prod.name)

        contacts = self._load_contacts()
        results = []
        for sname, info in supplier_map.items():
            if info["other_products"]:
                results.append({
                    "supplier": sname,
                    "phone": contacts.get(sname, "待确认"),
                    "serves_buyers": list(info["buyers"]),
                    "other_products": list(info["other_products"]),
                    "opportunity": f"他在给{list(info['buyers'])[:2]}做交付，你可以补充{target_product}"
                })
        return sorted(results, key=lambda x: -len(x["serves_buyers"]))

    # ========== 5. 产品按场景找关联客户（替代predict_potential_needs的补充） ==========

    def find_target_scene_buyers(self, target_product: str) -> dict:
        """
        基于场景匹配的潜在客户发现
        场景（如学校/考场/监狱）→ 买了办公设备但没买目标产品的单位
        """
        scenes = _scene_for_product(target_product)
        scene_buyers = defaultdict(list)

        for e in self.store.find_entities(EntityType.COMPANY):
            if e.properties.get("type") != "buyer":
                continue
            industries = e.properties.get("industries", [])
            # 检查是否匹配场景
            matched_scenes = []
            for ind in industries:
                for scene in scenes:
                    if scene in ind or scene in e.name:
                        matched_scenes.append(scene)
            if not matched_scenes:
                continue

            # 检查是否已买过目标产品
            bought_target = False
            bought_anything = False
            for r, proj in self.store.get_neighbors(e.id, RelationType.ISSUES):
                for r2, prod in self.store.get_neighbors(proj.id, RelationType.REQUIRES):
                    bought_anything = True
                    if prod.name == target_product:
                        bought_target = True

            if not bought_target and bought_anything:
                for scene in matched_scenes:
                    scene_buyers[scene].append(e.name)

        contacts = self._load_contacts()
        result = {}
        for scene, buyers in scene_buyers.items():
            result[scene] = []
            for bname in buyers:
                phone = contacts.get(bname, "待确认")
                result[scene].append({"name": bname, "phone": phone})

        return result

    # ========== 辅助 ==========

    def _load_contacts(self) -> dict:
        import json, os
        f = os.path.join(os.path.dirname(__file__), "data/contacts.json")
        if os.path.exists(f):
            with open(f) as fp:
                return json.load(fp)
        return {}

    def get_all_stats(self) -> dict:
        """完整统计"""
        stats = self.store.stats()
        products = self.get_all_product_names()
        associations = self.discover_product_associations(min_cooccurrence=1)
        return {
            "stats": stats,
            "products": products,
            "associations": [f"{a[0]} → {a[1]} ({a[2]:.0%}, {a[3]}项目)" for a in associations],
        }


if __name__ == "__main__":
    store = GraphStore()
    engine = InferenceEngine(store)

    stats = engine.get_all_stats()
    print(f"产品品类: {stats['products']}")
    print(f"\n=== 产品关联推理 ===")
    for a in stats["associations"]:
        print(f"  {a}")

    print(f"\n=== 全品类潜在客户 ===")
    for prod in stats['products']:
        needs = engine.predict_potential_needs(prod)
        if needs:
            print(f"\n  [{prod}] 潜在客户 {len(needs)} 家")
            for n in needs[:5]:
                print(f"    {n[0]}（买了{n[1]}但没买{prod}）")
