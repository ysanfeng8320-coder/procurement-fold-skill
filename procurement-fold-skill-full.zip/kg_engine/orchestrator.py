"""
编排引擎（v2 · 单品类数据面）

统一入口，串联：Scope 锁定 → 隔离子图构建 → 推理 → 质检 → 报告。

用法:
  from orchestrator import run_scout
  report = run_scout("印控仪", "甘肃", enable_scene="公安系统")
  print(report["markdown"])

真实性原则（贯穿全过程）:
  1. 无数据 → 输出"无数据"，不推测、不补全
  2. 外部依赖不可用 → 报告中明确标注
  3. 电话缺失 → 标注"待补充"
  4. 样本量不足 → 标注"数据不足"
  5. 品类隔离：禁止无关品类进入本次图谱与报告
"""
import json, os, sys
from typing import Optional

KG_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, KG_DIR)

from graph_store import GraphStore
from matrix_ops import MatrixOps, confidence_label
from inference import InferenceEngine
from feature_matcher import FeatureMatcher
from collector import UnifiedCollector
from builder import build_from_scout_data
from scope import (
    resolve_family, scope_id, qa_check_products,
    REGION_CODES, FORBIDDEN_PRODUCTS,
)


class TruthGuard:
    def __init__(self):
        self.warnings = []
        self.skips = []

    def wrap(self, label: str, fn, *args, **kwargs):
        try:
            result = fn(*args, **kwargs)
            if result is None:
                self.skips.append(f"{label}: 返回None")
                return None, f"{label}未执行（无可用数据）"
            if isinstance(result, dict) and result.get("error"):
                self.skips.append(f"{label}: {result['error']}")
                return result, f"{label}失败: {result['error']}"
            if isinstance(result, (list, tuple)) and len(result) == 0:
                self.skips.append(f"{label}: 返回空结果")
                return result, f"{label}已完成，但结果为0条"
            return result, None
        except Exception as e:
            self.skips.append(f"{label}: {e}")
            return None, f"{label}异常: {str(e)}"

    def get_notes(self) -> list:
        notes = []
        for w in self.warnings:
            notes.append(f"⚠️ {w}")
        for s in self.skips:
            notes.append(f"⊙ {s}")
        return notes


def _check_scene_available(province_code: str, scene: str) -> dict:
    from scene_completer import SceneCompleter, load_admin_regions, SCENE_RULES
    regions = load_admin_regions()
    available = province_code in regions
    scene_supported = scene in SCENE_RULES
    return {
        "available": available and scene_supported,
        "province_in_data": available,
        "scene_supported": scene_supported,
        "reason": None if (available and scene_supported)
                  else (f"省份{province_code}不在行政区划数据中" if not available
                   else f"场景'{scene}'不在支持的场景列表中"),
    }


def _build_scoped_store(canonical: str, family: list, region: str, prov_code: str) -> GraphStore:
    """Phase 2: 只加载 族×区域 数据，写入 scopes/ 隔离子图。"""
    sid = scope_id(canonical, region)
    scope_path = os.path.join(KG_DIR, "data", "scopes", sid, "graph.json")
    store = GraphStore(graph_file=scope_path, load=False)
    store.clear()
    build_from_scout_data(
        store,
        filter_province=prov_code,
        categories=family,
        region=region,
        canonical_product=canonical,
    )
    return store


def run_scout(
    product: str,
    region: str = "陕西",
    guidance_notes: list = None,
    customer_type: str = None,
    sales_method: str = None,
    enable_policy: bool = False,
    enable_scene: str = None,
    enable_neighborhood: bool = False,
    rebuild_scope: bool = True,
) -> dict:
    """
    一站式侦察入口（v2）。

    参数:
      product: 品类名（必填）
      region: "陕西" 或 "甘肃"
      enable_scene: 如 "公安系统" — 潜客池来源
      enable_neighborhood: 是否纳入办公设备邻域（默认 False）
      rebuild_scope: 是否重建隔离子图（默认 True）
    """
    guard = TruthGuard()
    steps_skipped = []

    # ===== Phase 0: Scope 锁定 =====
    canonical, family = resolve_family(product)
    prov_code = REGION_CODES.get(region)
    if not prov_code:
        return {
            "markdown": f"# 错误\n\n不支持的区域: {region}。当前支持: {list(REGION_CODES)}",
            "data_summary": {},
            "truth_notes": [f"区域无效: {region}"],
            "skipped_steps": [],
            "qa_failed": True,
        }
    sid = scope_id(canonical, region)

    target_spec = {
        "product": canonical,
        "product_input": product,
        "family": family,
        "region": region,
        "province_code": prov_code,
        "scope_id": sid,
        "customer_type": customer_type or "通用",
        "sales_method": sales_method or "通用",
        "neighborhood": enable_neighborhood,
    }

    # ===== Phase 2: 隔离子图 =====
    if rebuild_scope:
        store = _build_scoped_store(canonical, family, region, prov_code)
    else:
        scope_path = os.path.join(KG_DIR, "data", "scopes", sid, "graph.json")
        store = GraphStore(graph_file=scope_path, load=True)
        if store.stats()["entities"] == 0:
            store = _build_scoped_store(canonical, family, region, prov_code)

    stats = store.stats()
    if stats["entities"] == 0:
        md = (
            f"# {canonical} 侦察报告 — {region}\n\n"
            f"⊙ 无数据：scout_data 中没有「{'/'.join(family[:4])}… × {region}」的采集文件。\n"
            f"请先采集后再跑。\n"
        )
        return {
            "markdown": md,
            "data_summary": {"entities": 0, "scope_id": sid},
            "truth_notes": ["无可用 scope 数据"],
            "skipped_steps": steps_skipped,
            "qa_failed": True,
        }

    mo = MatrixOps(store)
    engine = InferenceEngine(store)
    matcher = FeatureMatcher(store)

    all_products = [name for _, name in sorted(mo.product_names.items())]
    product_in_graph = canonical in all_products

    # ===== 质检：品类隔离 =====
    qa_bad = qa_check_products(all_products, canonical, neighborhood=enable_neighborhood)
    qa_failed = bool(qa_bad)
    if qa_failed:
        guard.warnings.append(
            f"QA失败：图谱出现违规品类 {qa_bad}。scope={sid} 应只有族内产品。"
        )

    # ===== Phase 3: 推理 =====
    # 买家画像（本省 + 本族）
    profile, profile_note = guard.wrap(
        "买家画像",
        matcher.build_profile,
        canonical,
        province_code=prov_code,
        family=family,
    )
    if profile_note:
        profile = {}

    # 池 A: 已购
    confirmed, conf_note = guard.wrap(
        "已购清单",
        matcher.list_confirmed_buyers,
        canonical,
        province_code=prov_code,
        family=family,
        top_n=50,
    )
    if conf_note:
        confirmed = []

    # 场景完备性（潜客主来源）
    scene_result = None
    scene_note = None
    if enable_scene:
        scene_check = _check_scene_available(prov_code, enable_scene)
        if scene_check["available"]:
            try:
                from scene_completer import SceneCompleter
                sc = SceneCompleter(store)
                scene_result = sc.analyze(enable_scene, prov_code, target_product=canonical)
            except Exception as e:
                scene_note = f"场景完备性覆盖异常: {e}"
        else:
            scene_note = scene_check["reason"]
            steps_skipped.append(f"场景完备性覆盖（{scene_check['reason']}）")
    else:
        steps_skipped.append("场景完备性覆盖（未启用，可通过 enable_scene='公安系统' 开启）")

    # 池 B: 潜客（场景未购/盲区）
    prospects_list = []
    if scene_result and not scene_result.get("error"):
        prospects_list = matcher.prospects_from_scene(
            scene_result, top_n=40, product=canonical, family=family
        )
    else:
        steps_skipped.append("直销潜客：无场景数据，已禁用跨品类特征拟合")

    # 渠道商：必须带 product_filter
    suppliers, sup_note = guard.wrap(
        "渠道商推荐",
        mo.supplier_centrality,
        20,
        product_filter=canonical,
    )
    if sup_note:
        suppliers = []

    product_suppliers, _ = guard.wrap(
        "按品类供应商",
        mo.recommend_suppliers_by_product,
        canonical,
        15,
    )

    # ===== 联系方式补齐（已购 + 其集成商 + 渠道商 + 潜客）=====
    phone_stats = {"found": 0, "missing": 0, "api_calls": 0, "coverage": 0, "queried": 0}
    try:
        from phone_enricher import enrich_names, apply_phones_to_rows, is_real_phone
        name_pool = []
        for b in (confirmed or []):
            name_pool.append(b["name"])
            for it in b.get("integrators") or []:
                name_pool.append(it["name"])
        for s in (suppliers or []):
            name_pool.append(s["name"])
        for p in prospects_list[:20]:
            name_pool.append(p["name"])
            for it in p.get("integrators") or []:
                name_pool.append(it["name"])
        phone_stats = enrich_names(
            name_pool,
            province=region,
            max_api_calls=int(os.environ.get("SCOUT_PHONE_API_BUDGET", "25")),
            use_zhiliao=True,
            use_shibiao=True,
            harvest_first=True,
        )
        confirmed = apply_phones_to_rows(confirmed or [], phone_stats["contacts"])
        prospects_list = apply_phones_to_rows(prospects_list, phone_stats["contacts"])
        for s in (suppliers or []):
            ph = phone_stats["contacts"].get(s["name"], "")
            s["phone"] = ph if is_real_phone(ph) else "待确认"
        # 联系路径覆盖：本人有号 或 经集成商有号
        path_ok = sum(
            1 for b in (confirmed or [])
            if (b.get("contact_path") or {}).get("path_type") in ("direct", "via_integrator")
        )
        phone_stats["path_reachable"] = path_ok
        phone_stats["path_coverage"] = round(path_ok / max(len(confirmed or []), 1), 3)
        if path_ok == 0 and phone_stats["found"] == 0:
            guard.warnings.append(
                "联系方式覆盖率为0：公告未抠到号且API无号。"
                "直销客户将优先尝试「经集成商联系」路径。"
            )
        else:
            guard.warnings.append(
                f"联系方式：实体有号 {phone_stats['found']}/{phone_stats['queried']}；"
                f"已购客户可触达路径 {path_ok}/{len(confirmed or [])}"
                f"（含经集成商）；API {phone_stats['api_calls']}次"
            )
    except Exception as e:
        guard.warnings.append(f"联系方式补齐异常: {e}")

    prospects = {"prospects": prospects_list, "profile": profile or {}}

    # 关联规则：仅本图（已是单品类，通常为空或极少）
    rules, rule_note = guard.wrap("关联规则", mo.association_rules, min_support=2, min_confidence=0.1)
    if rule_note:
        rules = []
    product_rules = [
        r for r in (rules or [])
        if r["antecedent"] == canonical or r["consequent"] == canonical
    ] if rules else []

    # 政策（可选）
    policy_impact = None
    policy_note = None
    if enable_policy:
        try:
            from policy_fetcher import PolicyFactorEngine, generate_mock_signals
            pe = PolicyFactorEngine(store)
            signals = generate_mock_signals(canonical, region)
            pe.build_policy_matrices(signals)
            policy_impact = pe.analyze_policy_impact(signals)
        except Exception as e:
            policy_note = f"政策因子分析异常: {e}"
    else:
        steps_skipped.append("政策因子分析（未启用，可通过 enable_policy=True 开启）")

    # 厂商策略信号（可选）
    guidance_summary = None
    if guidance_notes:
        try:
            from guidance_fetcher import GuidanceEngine as GE2
            geng = GE2(store)
            geng.add_notes(guidance_notes)
            geng.build_guidance_matrix()
            gstats = geng.get_stats()
            gsummary = geng.get_signal_summary()
            guidance_summary = {
                "total_signals": gstats["total_signals"],
                "by_type": {item["type"]: item["count"] for item in gsummary},
            }
        except Exception as e:
            guard.warnings.append(f"策略信号: {e}")

    # 二次质检：潜客已购字段不得含禁品
    for p in prospects_list:
        bad = [x for x in p.get("existing_products", []) if x in FORBIDDEN_PRODUCTS]
        if bad:
            qa_failed = True
            guard.warnings.append(f"QA失败：潜客 {p['name']} 带有禁品 {bad}")

    markdown = _build_report(
        target_spec=target_spec,
        stats=stats,
        product_in_graph=product_in_graph,
        all_products=all_products,
        rules=product_rules,
        profile=profile or {},
        confirmed=confirmed or [],
        prospects=prospects,
        suppliers=suppliers or [],
        product_suppliers=product_suppliers or [],
        policy_impact=policy_impact,
        policy_note=policy_note,
        scene_result=scene_result,
        scene_note=scene_note,
        guidance_summary=guidance_summary,
        truth_notes=guard.get_notes(),
        steps_skipped=steps_skipped,
        qa_failed=qa_failed,
        qa_bad=qa_bad,
        phone_stats=phone_stats,
    )

    return {
        "markdown": markdown,
        "data_summary": {
            "entities": stats["entities"],
            "relations": stats["relations"],
            "products": all_products,
            "product_in_graph": product_in_graph,
            "scope_id": sid,
            "confirmed_buyers": len(confirmed or []),
            "prospects": len(prospects_list),
            "suppliers": len(suppliers or []),
            "phone_coverage": {
                k: v for k, v in (phone_stats or {}).items() if k != "contacts"
            },
        },
        "truth_notes": guard.get_notes(),
        "skipped_steps": steps_skipped,
        "qa_failed": qa_failed,
    }


def _build_report(**ctx) -> str:
    lines = []
    spec = ctx["target_spec"]
    product = spec["product"]
    region = spec["region"]
    family = spec.get("family", [product])

    lines.append(f"# {product} 侦察报告 — {region}")
    lines.append("")
    lines.append(
        f"品类: {product} | 区域: {region} | 客户类型: {spec['customer_type']} | "
        f"销售方式: {spec['sales_method']} | scope: `{spec.get('scope_id', '')}`"
    )
    lines.append("")

    if ctx.get("qa_failed"):
        lines.append("## ❌ QA 未通过")
        lines.append("")
        lines.append(f"- 违规品类: {ctx.get('qa_bad', [])}")
        lines.append("- 本报告数据面可能仍有污染，请检查 builder scope。")
        lines.append("")

    truth_notes = ctx.get("truth_notes", [])
    skipped = ctx.get("steps_skipped", [])
    if truth_notes or skipped:
        lines.append("## ⚠️ 真实性标注")
        lines.append("")
        for n in truth_notes:
            lines.append(f"- {n}")
        for s in skipped:
            lines.append(f"- ⊕ {s}")
        lines.append("")

    stats = ctx["stats"]
    lines.append("## 数据基础")
    lines.append("")
    lines.append(f"- 数据面: **单品类隔离**（仅 `{product}` 同义词族 × {region}）")
    lines.append(f"- 同义词族: {', '.join(family)}")
    lines.append(f"- 图谱实体: {stats['entities']}个, 关系: {stats['relations']}条")
    lines.append(f"- 本 scope 品类: {', '.join(ctx.get('all_products', [])) or '无'}")
    lines.append(f'  "{product}"在 scope 中: {"[YES]" if ctx.get("product_in_graph") else "[NO]"}')
    ps = ctx.get("phone_stats") or {}
    if ps:
        lines.append(
            f"- 联系方式: 实体有号 {ps.get('found', 0)}/{ps.get('queried', 0)}；"
            f"已购可触达路径 {ps.get('path_reachable', 0)}"
            f"（含经集成商，覆盖率 {ps.get('path_coverage', 0)}）"
        )
    else:
        lines.append("- 电话覆盖率: 需补充")
    lines.append("")

    profile = ctx.get("profile", {})
    if profile and profile.get("target_count", 0) > 0:
        lines.append("## 买家画像")
        lines.append("")
        lines.append(f"- 已购客户: {profile['target_count']}家")
        lines.append(f"- 平均采购额: {profile.get('avg_spend', '-')}万")
        lines.append("")
        if profile.get("level_profile"):
            lines.append("**行政级别分布:**")
            for lv, info in sorted(profile["level_profile"].items(), key=lambda x: -x[1]["count"])[:5]:
                lines.append(f"- {lv}: {info['count']}家 ({info['pct']}%)")
            lines.append("")
        if profile.get("amount_profile"):
            lines.append("**金额分布:**")
            for ab, info in sorted(profile["amount_profile"].items(), key=lambda x: -x[1]["count"])[:5]:
                lines.append(f"- {ab}: {info['count']}家 ({info['pct']}%)")
            lines.append("")
    else:
        lines.append("## 买家画像")
        lines.append("")
        lines.append("⊙ 数据不足，无法构建画像")
        lines.append("")

    # 池 A
    confirmed = ctx.get("confirmed", [])
    lines.append(f"## 已购清单（证据 · Top {min(len(confirmed), 20)}）")
    lines.append("")
    if confirmed:
        for i, p in enumerate(confirmed[:20], 1):
            phone = p.get("phone") or "待确认"
            phone_str = f" ☎ {phone}" if phone not in ("待确认", "待补充", "") else ""
            inds = ", ".join(p.get("industries") or []) or "-"
            lines.append(f"{i}. **{p['name']}**{phone_str}")
            lines.append(
                f"   系统: {inds} | 级别: {p.get('level', '-')} | "
                f"金额: {p.get('amount_bucket', '-')}（{p.get('total_spend', 0)}万）| "
                f"项目: {p.get('project_count', 0)}个"
            )
            lines.append(f"   已购: {', '.join(p.get('existing_products', [])[:5])}")
            # 联系路径（直销关键）：本人号 或 经集成商
            cd = p.get("contact_display") or (p.get("contact_path") or {}).get("display")
            if cd:
                lines.append(f"   联系路径: {cd}")
            ints = p.get("integrators") or []
            if ints:
                bits = []
                for it in ints[:4]:
                    ip = it.get("phone") or "待确认"
                    ip_s = ip if ip not in ("待确认", "") else "待确认"
                    tag = "本品类" if it.get("in_family") else "其他"
                    bits.append(f"{it['name']}（{tag}·{it.get('deal_count', 0)}次·☎{ip_s}）")
                lines.append(f"   曾合作集成商: {'；'.join(bits)}")
            else:
                lines.append("   曾合作集成商: 无记录")
    else:
        lines.append("⊙ 本 scope 内无已购客户")
    lines.append("")

    # 池 B
    prospect_list = (ctx.get("prospects") or {}).get("prospects", [])
    lines.append(f"## 直销潜客（场景未购/盲区 · Top {min(len(prospect_list), 20)}）")
    lines.append("")
    if prospect_list:
        for i, p in enumerate(prospect_list[:20], 1):
            phone = p.get("phone") or "待确认"
            phone_str = f" ☎ {phone}" if phone not in ("待确认", "待补充", "") else " ☎ 待确认"
            lines.append(f"{i}. **[{p.get('score', '-')}分] {p['name']}**{phone_str}")
            lines.append(f"   来源: {p.get('pool', '-')} | 类型: {p.get('user_type', '-')}")
            for r in p.get("reasons", [])[:2]:
                lines.append(f"   → {r}")
            ints = p.get("integrators") or []
            if ints:
                bits = [f"{it['name']}（{it.get('deal_count', 0)}次）" for it in ints[:3]]
                lines.append(f"   曾合作集成商: {'；'.join(bits)}")
            else:
                lines.append("   曾合作集成商: 无本品类合作记录（盲区单位常见）")
    else:
        lines.append("⊙ 无潜客清单（请启用 enable_scene，或补充场景行政区划数据）")
        lines.append("⊙ 已禁用跨品类特征拟合，不会再推荐「买过塑胶跑道/旗杆」的单位")
    lines.append("")

    # 渠道商
    suppliers = ctx.get("suppliers") or []
    lines.append(f"## 渠道商清单（{product} 中标供应商 Top {min(len(suppliers), 15)}）")
    lines.append("")
    if suppliers:
        lines.append("| 供应商 | 联系方式 | 本品类中标次数 | 金额(万) | 置信度 |")
        lines.append("|-------|---------|---------------|---------|-------|")
        for s in suppliers[:15]:
            phone = s.get("phone") or "待确认"
            lines.append(
                f"| {s['name']} | {phone} | {s['deal_count']} | "
                f"{s.get('total_amount', '-')} | {s['confidence']} |"
            )
    else:
        lines.append("⊙ 无本品类中标供应商数据")
    lines.append("")

    rules = ctx.get("rules") or []
    if rules:
        lines.append("## 关联产品推荐")
        lines.append("")
        for r in rules[:5]:
            lines.append(f"- {r['interpretation']} 置信度={r['confidence_label']}")
        lines.append("")

    scene_result = ctx.get("scene_result")
    if scene_result:
        from scene_completer import SceneCompleter
        sc = SceneCompleter()
        lines.append(sc.format_report(scene_result))
        lines.append("")
    elif ctx.get("scene_note"):
        lines.append("## 场景完备性覆盖")
        lines.append("")
        lines.append(f"⊙ {ctx['scene_note']}")
        lines.append("")

    if ctx.get("guidance_summary"):
        gs = ctx["guidance_summary"]
        lines.append("## 厂商策略信号")
        lines.append("")
        lines.append(f"- 信号条数: {gs.get('total_signals', 0)}")
        lines.append("")

    policy_impact = ctx.get("policy_impact")
    if policy_impact:
        lines.append("## 政策影响分析")
        lines.append("")
        for item in policy_impact[:5]:
            lines.append(f"- [{item.get('impact_score', '-')}] {item.get('topic_name', '-')}")
        lines.append("")
    elif ctx.get("policy_note"):
        lines.append("## 政策影响分析")
        lines.append("")
        lines.append(f"⊙ {ctx['policy_note']}")
        lines.append("")

    lines.append("## 行动建议")
    lines.append("")
    actionable = [
        p for p in (confirmed or [])
        if p.get("phone") and p["phone"] not in ("待确认", "")
    ]
    actionable_p = [
        p for p in prospect_list
        if p.get("phone") and p["phone"] not in ("待确认", "")
    ]
    if actionable:
        lines.append(f"### 已购客户可回访（{len(actionable)}家有电话）")
        for p in actionable[:5]:
            lines.append(f"- **{p['name']}** ☎ {p['phone']}（{p.get('total_spend', 0)}万）")
    if actionable_p:
        lines.append(f"### 潜客可联系（{len(actionable_p)}家有电话）")
        for p in actionable_p[:5]:
            lines.append(f"- **{p['name']}** ☎ {p['phone']}（{p.get('score', '-')}分 · {p.get('pool', '')}）")
    if not actionable and not actionable_p:
        lines.append("### 本周可联系")
        lines.append("⊙ 当前数据中无电话信息。建议补充联系方式后跟进。")

    return "\n".join(lines)


if __name__ == "__main__":
    product = sys.argv[1] if len(sys.argv) > 1 else "印控仪"
    region = sys.argv[2] if len(sys.argv) > 2 else "甘肃"
    enable_scene = sys.argv[3] if len(sys.argv) > 3 else "公安系统"

    print(f"=== 运行侦察 v2: {product} / {region} / scene={enable_scene} ===")
    result = run_scout(
        product=product,
        region=region,
        customer_type="政务市场",
        sales_method="渠道商合作+直销",
        enable_policy=False,
        enable_scene=enable_scene,
    )
    out = os.path.join(KG_DIR, "..", "reports", f"{product}_{region}_侦察报告.md")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w") as f:
        f.write(result["markdown"])
    print(f"报告已保存: {out}")
    print(f"QA失败: {result.get('qa_failed')}")
    print(json.dumps(result["data_summary"], ensure_ascii=False, indent=2))
