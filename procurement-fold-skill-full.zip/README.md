# procurement-fold-skill

政府采购 **结构折叠**：商业问答 → 资料 →（自备 Key）采集 / 场景拟合 / 名单 / 电话补全。

一键安装后带 `kg_engine/`，**不只是咨询问答**。API Key 仍须自备（不随包分发）。

## WorkBuddy / CodeBuddy（对话框粘贴）

```text
帮我安装完整版 procurement-fold（含采集/拟合/名单引擎）。请执行：

curl -fsSL https://raw.githubusercontent.com/ysanfeng8320-coder/procurement-fold-skill/main/install-workbuddy.sh | bash

装完确认：
~/.codebuddy/skills/procurement-fold/SKILL.md
~/.codebuddy/skills/procurement-fold/kg_engine/fold/scene_fit.py
若无 codebuddy 目录，则看 ~/.workbuddy/skills/procurement-fold/
然后提醒我配置 ZHILIAO_API_KEY / SHIBO_API_KEY，配好后跑场景拟合与名单。
```

若 curl 404（脚本尚未推上 GitHub），改用：

```text
帮我 git clone --depth 1 https://github.com/ysanfeng8320-coder/procurement-fold-skill
把 skills/procurement-fold/* 和 kg_engine/ 装成 bundled 布局到
~/.codebuddy/skills/procurement-fold/（同时复制一份到 ~/.workbuddy/skills/procurement-fold/）：
- skill 文件在根目录（必须有 SKILL.md）
- kg_engine/ 作为子目录
- 建空目录 scout_data/、fold_runs/
然后跑 python3 ~/.codebuddy/skills/procurement-fold/scripts/doctor.py
```

## Codex / Cursor

```bash
npx -y skills add ysanfeng8320-coder/procurement-fold-skill -g --all
```

说明：`npx skills add` 通常只装 skill 文本；完整引擎请再跑上面的 `install-workbuddy.sh`，或在 monorepo 里用。

## 档位说明

| 档位 | 条件 | 能力 |
|------|------|------|
| A | 无 Key | 问答 + 简易报告 |
| B | 有 `kg_engine/` + 自备 Key | 闸门 / 拟合 / 名单 / 电话 |

```bash
export ZHILIAO_API_KEY=...
export SHIBO_API_KEY=...
pip3 install pyyaml requests
```

## 仓库结构

```text
skills/procurement-fold/   ← Skill（SKILL.md）
kg_engine/                 ← 引擎（fold + collector + phone_enricher…）
install-workbuddy.sh       ← 一键装到 ~/.codebuddy 与 ~/.workbuddy
```

## 许可证

仅供授权对象使用；禁止附带第三方 API Key 分发。
